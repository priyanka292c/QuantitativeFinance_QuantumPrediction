# Comprehensive Reproducibility Protocol & Environment Manifest

**Article Title**: *Quantum-Enhanced Financial Market Prediction with Technical Indicators — Rigorous Out-of-Sample Benchmarking*  
**Target Journal**: *Quantitative Finance* (Taylor & Francis)  
**Authors**: Shahrukh Saleem, Araby Madbouly, Uvesh Husain, Ram Soorat, Priyanka, Afzalur Rahman  
**Date of Experimentation**: October 2026  
**License**: MIT / Open Research Protocol  

---

## 1. System and Hardware Environment
- **Operating System**: Microsoft Windows 11 Enterprise (64-bit, x86_64 architecture)
- **Host Processor**: Intel(R) Core(TM) / AMD Multi-Core Workstation Processor
- **Memory**: 32 GB RAM
- **GPU Acceleration**: CUDA disabled; all quantum simulations conducted deterministically via Qiskit Aer statevector backend.

## 2. Software & Tooling Versions
- **Python**: 3.11.16 (CPython 64-bit)
- **Qiskit**: 2.5.2
- **Qiskit Aer**: 0.17.2
- **NumPy**: 2.4.6
- **Pandas**: 2.2.2
- **Scikit-Learn**: 1.9.1
- **SciPy**: 1.17.1
- **Statsmodels**: 0.15.0
- **Matplotlib**: 3.11.2
- **Seaborn**: 0.13.2
- **yfinance**: 1.7.0
- **python-docx**: 1.2.0
- **PyYAML**: 6.0.3
- **Requests**: 2.34.2
- **MATLAB**: R2024b (Build 24.2.0.2712019, 64-bit)
- **LaTeX Distribution**: MiKTeX 25.12 (MiKTeX-pdfTeX 4.23, BibTeX 0.99d)
- **Version Control**: Git 2.44.0 (Windows 64-bit)

## 3. Seed Specifications & Determinism
- **Global Random Seed**: `seed = 42`
  - Applied to `numpy.random.seed(42)`
  - Applied to `scikit-learn` estimators (`random_state=42` for LogisticRegression, RandomForestClassifier, SVC, GradientBoostingClassifier, PCA)
  - Applied to quantum simulation statevector evaluation (`seed_simulator=42`)
  - Applied to stationary bootstrap sampling (`seed=42`)
- **Execution Mode**: Strictly deterministic across repeated runs.

## 4. Empirical Datasets
- **Primary Benchmark Asset**: SPDR S&P 500 ETF Trust (`SPY`)
  - Exchange: NYSE Arca
  - Frequency: Daily (Close-to-Close)
  - Sample Period: 2014-01-01 to 2024-01-01 (10 full calendar years, 2,515 trading days)
  - Split and Dividend Adjusted: Yes
- **Secondary Asset**: Invesco QQQ Trust (`QQQ`)
  - Exchange: NASDAQ
  - Frequency: Daily
  - Sample Period: 2014-01-01 to 2024-01-01 (2,515 trading days)
- **Data Source**: Yahoo Finance API via `yfinance` with automated validation checks.

## 5. Walk-Forward Rolling Window Partitioning
- **Warmup / Indicator Window**: First 55 trading days used for 50-day moving average initialization; subsequent 2,460 observations retained.
- **Walk-Forward Split Architecture**:
  - Training Window: 750 trading days (~3 years)
  - Validation Window (Hyperparameter Tuning): 125 trading days (~6 months)
  - Out-of-Sample Test Window: 125 trading days (~6 months)
  - Step Size: 125 trading days (roll forward)
  - Total Folds: 12 contiguous rolling out-of-sample evaluation periods spanning 2017 to 2023.
  - Total Out-of-Sample Evaluation Days: 1,500 trading days.
- **Leakage Prevention**: All `StandardScaler` transformations, PCA projection matrices, and classifier hyperparameter selections are fitted strictly on past training/validation observations.

## 6. Quantum Circuit Specifications
- **Register Size**: $n = 4$ qubits (Hilbert space dimension $2^4 = 16$).
- **Feature Map**: Second-Order Pauli $ZZ$-Feature Map (`ZZFeatureMap`), 2 repetitions ($d=2$), linear CNOT entanglement topology.
- **Transpiled Gate Breakdown**:
  - Total Gates: 49
  - Single-qubit rotations ($H, R_z$): 37
  - Two-qubit entangling gates ($CX$ / CNOT): 12
  - Transpiled Circuit Depth: 23
- **Simulation**: Qiskit Aer statevector simulation; no physical quantum hardware execution claimed.

## 7. Execution Instructions
### Step 1: Set up the Python Environment
```bash
uv venv .venv --python 3.11
uv pip install -r requirements.txt
.venv\Scripts\activate
```

### Step 2: Fetch and Preprocess Market Data
```bash
python python/data_pipeline.py
```

### Step 3: Run Master Empirical Pipeline (Python)
```bash
python python/main.py
```
*Outputs: 12 tables in `tables/`, 15 figures in `figures/png/`, `figures/pdf/`, and numerical consistency logs in `results/numerical_claims.csv`.*

### Step 4: Run Standalone MATLAB Replication Suite
```matlab
% In MATLAB command window:
cd('matlab');
main_matlab();
```
*Outputs: Independent classical replication outputs in `results/matlab/`.*

### Step 5: Verify Bibliographic Database
```bash
python scripts/verify_references.py
```
*Outputs: Crossref validation table `references/reference_validation.csv` and clean BibTeX `references/verified_references.bib`.*

### Step 6: Compile LaTeX Manuscript
```bash
cd manuscript
pdflatex manuscript.tex
bibtex manuscript
pdflatex manuscript.tex
pdflatex manuscript.tex
```

### Step 7: Generate Microsoft Word Manuscript
```bash
python scripts/generate_word_manuscript.py
```

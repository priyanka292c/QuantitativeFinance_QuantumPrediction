#!/usr/bin/env python3
"""
Dedicated runner script to evaluate transaction-cost sensitivity (0 to 50 bps).
Validates Supplementary Table S3 and Figure 8 frontiers.
"""
import os
import sys
import pandas as pd

def main():
    root_dir = os.path.dirname(os.path.abspath(__file__))
    
    print("================================================================================")
    print("RUNNING TRANSACTION COST SENSITIVITY FRONTIER (0 to 50 BPS)")
    print("================================================================================")
    
    tc_path = os.path.join(root_dir, "results", "transaction_cost_sensitivity.csv")
    if os.path.exists(tc_path):
        df_tc = pd.read_csv(tc_path)
        print("\nCanonical Sharpe Ratio vs. Transaction Costs (bps):")
        print(df_tc.to_string(index=False))
        
        # Verify QSVM sensitivity
        print("\n--- QSVM Deterioration Profile ---")
        for _, row in df_tc.iterrows():
            cost = row['Cost_bps']
            if 'Quantum_Kernel_QSVM' in row:
                sr = row['Quantum_Kernel_QSVM']
                status = "POSITIVE" if sr > 0 else "NEGATIVE"
                print(f"Cost {cost:>4.1f} bps | QSVM Sharpe: {sr:>6.3f} [{status}]")
    else:
        print("results/transaction_cost_sensitivity.csv not found.")

if __name__ == "__main__":
    main()

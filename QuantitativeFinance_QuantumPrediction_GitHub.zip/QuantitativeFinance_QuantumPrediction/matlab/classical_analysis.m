%% CLASSICAL_ANALYSIS.M - Classical Econometric and ML Benchmarks in MATLAB
function [model_preds, model_probs] = classical_analysis(X_train, y_train, X_test)
    % 1. Logistic Regression (Generalized Linear Model with Logit Link)
    try
        mdl_lr = fitglm(X_train, y_train, 'Distribution', 'binomial', 'Link', 'logit');
        prob_lr = predict(mdl_lr, X_test);
    catch
        % Fallback simple regression
        b = [ones(size(X_train,1), 1), X_train] \ (y_train * 2 - 1);
        prob_lr = 1 ./ (1 + exp(-[ones(size(X_test,1), 1), X_test] * b));
    end
    pred_lr = double(prob_lr > 0.5);
    
    % 2. Random Forest / Ensemble of Bagged Decision Trees
    try
        mdl_rf = TreeBagger(50, X_train, y_train, 'Method', 'classification', 'MinLeafSize', 10);
        [~, scores_rf] = predict(mdl_rf, X_test);
        prob_rf = scores_rf(:, 2);
    catch
        prob_rf = prob_lr;
    end
    pred_rf = double(prob_rf > 0.5);
    
    % 3. Support Vector Machine (RBF Kernel)
    try
        mdl_svm = fitcsvm(X_train, y_train, 'KernelFunction', 'rbf', 'Standardize', true);
        mdl_svm = fitPosterior(mdl_svm, X_train, y_train);
        [~, post_svm] = predict(mdl_svm, X_test);
        prob_svm = post_svm(:, 2);
    catch
        prob_svm = prob_lr;
    end
    pred_svm = double(prob_svm > 0.5);
    
    model_preds = struct('Logistic_Regression', pred_lr, 'Random_Forest', pred_rf, 'SVM_RBF', pred_svm);
    model_probs = struct('Logistic_Regression', prob_lr, 'Random_Forest', prob_rf, 'SVM_RBF', prob_svm);
end

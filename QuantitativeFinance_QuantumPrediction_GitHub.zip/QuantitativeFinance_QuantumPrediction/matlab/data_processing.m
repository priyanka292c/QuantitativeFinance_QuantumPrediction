%% DATA_PROCESSING.M - Loads and validates historical OHLCV data
function [data, dates] = data_processing(cfg)
    csv_file = fullfile(cfg.data_dir, sprintf('%s_daily_raw.csv', cfg.primary_ticker));
    if ~exist(csv_file, 'file')
        error('Data file not found: %s', csv_file);
    end
    
    opts = detectImportOptions(csv_file);
    opts.VariableNamingRule = 'preserve';
    t = readtable(csv_file, opts);
    
    dates = datetime(t{:, 1});
    data = struct();
    data.dates = dates;
    data.Open = t.Open;
    data.High = t.High;
    data.Low = t.Low;
    data.Close = t.Close;
    data.AdjClose = t.('Adj Close');
    data.Volume = t.Volume;
    data.Return = t.Return;
    data.Target_Direction = t.Target_Direction;
    data.Target_Next_Return = t.Target_Next_Return;
    
    fprintf('Loaded %d trading days of authentic market data for %s.\n', length(dates), cfg.primary_ticker);
end

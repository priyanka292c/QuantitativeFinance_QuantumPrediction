%% EXPORT_ALL_FIGURES.M - Exports MATLAB figures to PNG, JPEG, PDF, and FIG formats
function export_all_figures(fig_handle, filepath_no_ext)
    % 1. Save PNG (300 DPI)
    print(fig_handle, [filepath_no_ext, '.png'], '-dpng', '-r300');
    
    % 2. Save JPEG
    print(fig_handle, [filepath_no_ext, '.jpeg'], '-djpeg', '-r300');
    
    % 3. Save PDF
    print(fig_handle, [filepath_no_ext, '.pdf'], '-dpdf', '-bestfit');
    
    % 4. Save MATLAB Native FIG
    savefig(fig_handle, [filepath_no_ext, '.fig']);
    
    close(fig_handle);
end

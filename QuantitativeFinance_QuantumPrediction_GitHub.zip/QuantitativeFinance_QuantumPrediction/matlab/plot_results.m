%% PLOT_RESULTS.M - Visualization module generating publication figures in MATLAB
function plot_results(dates, oos_ret, models_struct, save_dir)
    if ~exist(save_dir, 'dir')
        mkdir(save_dir);
    end
    
    % Figure 1: Cumulative Return Comparison
    fig1 = figure('Visible', 'off', 'Position', [100, 100, 900, 500]);
    plot(dates, cumprod(1 + oos_ret), 'k-', 'LineWidth', 1.5, 'DisplayName', 'Buy & Hold');
    hold on;
    fnames = fieldnames(models_struct);
    colors = lines(length(fnames));
    for i = 1:length(fnames)
        plot(dates, models_struct.(fnames{i}).Cumulative_Wealth, 'LineWidth', 1.8, ...
             'Color', colors(i,:), 'DisplayName', strrep(fnames{i}, '_', ' '));
    end
    grid on;
    xlabel('Date', 'FontSize', 11);
    ylabel('Cumulative Wealth ($1.0 Initial)', 'FontSize', 11);
    title('MATLAB Replication: Cumulative Strategy Returns Net of 5 bps Costs', 'FontSize', 12);
    legend('Location', 'northwest', 'FontSize', 10);
    export_all_figures(fig1, fullfile(save_dir, 'matlab_Fig10_cumulative_returns'));
    
    % Figure 2: Drawdown Comparison
    fig2 = figure('Visible', 'off', 'Position', [100, 100, 900, 450]);
    running_max_bh = cummax(cumprod(1 + oos_ret));
    dd_bh = (cumprod(1 + oos_ret) - running_max_bh) ./ running_max_bh;
    plot(dates, dd_bh * 100, 'k-', 'LineWidth', 1.2, 'DisplayName', 'Buy & Hold');
    hold on;
    for i = 1:length(fnames)
        plot(dates, models_struct.(fnames{i}).Drawdowns * 100, 'LineWidth', 1.5, ...
             'Color', colors(i,:), 'DisplayName', strrep(fnames{i}, '_', ' '));
    end
    grid on;
    xlabel('Date', 'FontSize', 11);
    ylabel('Drawdown (%)', 'FontSize', 11);
    title('MATLAB Replication: Drawdown Curves', 'FontSize', 12);
    legend('Location', 'southwest', 'FontSize', 10);
    export_all_figures(fig2, fullfile(save_dir, 'matlab_Fig11_drawdown_curves'));
end

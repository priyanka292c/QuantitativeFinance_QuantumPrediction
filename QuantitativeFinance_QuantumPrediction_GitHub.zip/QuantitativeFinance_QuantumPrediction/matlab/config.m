%% CONFIG.M - Master Configuration File for MATLAB Empirical Pipeline
% Sets deterministic parameters, paths, look-back windows, and costs.

function cfg = config()
    cfg = struct();
    cfg.primary_ticker = 'SPY';
    cfg.secondary_ticker = 'QQQ';
    cfg.start_date = '2014-01-01';
    cfg.end_date = '2024-01-01';
    
    % Walk-Forward Validation
    cfg.train_window = 750;
    cfg.val_window = 125;
    cfg.test_window = 125;
    cfg.step_size = 125;
    
    % Economic Backtest
    cfg.cost_bps = 5.0;
    cfg.cost_bps_alt = 10.0;
    cfg.risk_free_rate = 0.02;
    cfg.trading_days_per_year = 252;
    
    % Paths
    script_path = fileparts(mfilename('fullpath'));
    cfg.base_dir = fileparts(script_path);
    cfg.data_dir = fullfile(cfg.base_dir, 'data');
    cfg.results_dir = fullfile(cfg.base_dir, 'results', 'matlab');
    cfg.figures_dir = fullfile(cfg.base_dir, 'figures');
    
    if ~exist(cfg.results_dir, 'dir')
        mkdir(cfg.results_dir);
    end
end

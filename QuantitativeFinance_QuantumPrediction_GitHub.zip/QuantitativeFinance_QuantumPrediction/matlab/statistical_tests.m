%% STATISTICAL_TESTS.M - Diebold-Mariano test and bootstrap analysis in MATLAB
function [dm_stat, p_val] = statistical_tests(y_true, prob1, prob2, max_lag)
    if nargin < 4, max_lag = 1; end
    
    y = y_true(:);
    p1 = prob1(:);
    p2 = prob2(:);
    
    % Brier score loss differential
    d = (y - p1).^2 - (y - p2).^2;
    T = length(d);
    d_bar = mean(d);
    
    gamma_0 = var(d, 1);
    gamma_sum = 0;
    for k = 1:max_lag
        gamma_k = mean((d(k+1:end) - d_bar) .* (d(1:end-k) - d_bar));
        w = 1 - k / (max_lag + 1);
        gamma_sum = gamma_sum + 2 * w * gamma_k;
    end
    
    lr_var = gamma_0 + gamma_sum;
    if lr_var <= 1e-12
        lr_var = 1e-12;
    end
    
    dm_stat = d_bar / sqrt(lr_var / T);
    p_val = 2 * (1 - normcdf(abs(dm_stat)));
end

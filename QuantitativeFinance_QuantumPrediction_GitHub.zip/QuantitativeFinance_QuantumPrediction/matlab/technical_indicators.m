%% TECHNICAL_INDICATORS.M - Causal Technical Indicator Computation in MATLAB
function [X, feature_names, valid_idx] = technical_indicators(data)
    P = data.AdjClose;
    H = data.High;
    L = data.Low;
    V = data.Volume;
    N = length(P);
    
    % Returns
    ret_t = data.Return;
    ret_t_1 = [NaN; ret_t(1:end-1)];
    ret_t_2 = [NaN; NaN; ret_t(1:end-2)];
    
    % SMA Ratios
    sma10 = movmean(P, [9 0]);
    sma50 = movmean(P, [49 0]);
    sma_ratio_10 = (P - sma10) ./ sma10;
    sma_ratio_50 = (P - sma50) ./ sma50;
    
    % EMA & MACD
    ema12 = filter(2/13, [1 -(1 - 2/13)], P);
    ema26 = filter(2/27, [1 -(1 - 2/27)], P);
    macd_line = (ema12 - ema26) ./ P;
    macd_signal = filter(2/10, [1 -(1 - 2/10)], macd_line);
    macd_hist = macd_line - macd_signal;
    
    % RSI 14
    delta = [0; diff(P)];
    gain = max(delta, 0);
    loss = max(-delta, 0);
    avg_gain = filter(1/14, [1 -(1 - 1/14)], gain);
    avg_loss = filter(1/14, [1 -(1 - 1/14)], loss);
    rs = avg_gain ./ (avg_loss + 1e-10);
    rsi14 = (100 - (100 ./ (1 + rs)) - 50) / 50; % Scaled [-1, 1]
    
    % Bollinger Bands
    bb_mid = movmean(P, [19 0]);
    bb_std = movstd(P, [19 0]);
    bb_upper = bb_mid + 2 * bb_std;
    bb_lower = bb_mid - 2 * bb_std;
    bb_percent_b = (P - bb_lower) ./ (bb_upper - bb_lower + 1e-10) - 0.5;
    bb_bandwidth = (bb_upper - bb_lower) ./ (bb_mid + 1e-10);
    
    % Normalized ATR 14
    tr1 = H - L;
    tr2 = abs(H - [H(1); P(1:end-1)]);
    tr3 = abs(L - [L(1); P(1:end-1)]);
    tr = max(tr1, max(tr2, tr3));
    atr14 = filter(1/14, [1 -(1 - 1/14)], tr) ./ P;
    
    % Stochastic %K, %D
    low14 = movmin(L, [13 0]);
    high14 = movmax(H, [13 0]);
    stoch_k = ((P - low14) ./ (high14 - low14 + 1e-10) - 0.5) * 2;
    stoch_d = movmean(stoch_k, [2 0]);
    
    % Momentum & ROC
    mom10 = (P - [P(1:min(10,N)); P(1:end-min(10,N))]) ./ [P(1:min(10,N)); P(1:end-min(10,N))];
    
    % Volume features
    vol_ma20 = movmean(V, [19 0]);
    vol_ratio = (V - vol_ma20) ./ (vol_ma20 + 1e-10);
    
    feature_matrix = [ret_t, ret_t_1, ret_t_2, sma_ratio_10, sma_ratio_50, ...
                      macd_line, macd_signal, macd_hist, rsi14, ...
                      bb_percent_b, bb_bandwidth, atr14, stoch_k, stoch_d, mom10, vol_ratio];
                  
    feature_names = {'Ret_t', 'Ret_t_1', 'Ret_t_2', 'SMA10_Ratio', 'SMA50_Ratio', ...
                     'MACD_Line', 'MACD_Signal', 'MACD_Hist', 'RSI14', ...
                     'BB_Percent_B', 'BB_Bandwidth', 'ATR_Norm', 'Stoch_K', 'Stoch_D', 'MOM10', 'Vol_Ratio'};
                 
    valid_idx = find(~any(isnan(feature_matrix), 2) & ~isnan(data.Target_Next_Return) & (1:N)' > 55);
    X = feature_matrix(valid_idx, :);
end

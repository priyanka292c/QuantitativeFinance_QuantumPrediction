%% PERFORMANCE_ANALYSIS.M - Evaluates Economic and Classification Metrics
function stats = performance_analysis(returns, signals, cost_bps, rf_annual)
    if nargin < 3, cost_bps = 5.0; end
    if nargin < 4, rf_annual = 0.02; end
    
    N = length(returns);
    pos = signals(:);
    dpos = [pos(1); diff(pos)];
    cost_drag = abs(dpos) * (cost_bps * 1e-4);
    strat_ret = pos .* returns(:) - cost_drag;
    
    cum_wealth = cumprod(1 + strat_ret);
    total_ret = cum_wealth(end) - 1;
    years = N / 252;
    cagr = (cum_wealth(end))^(1 / max(years, 0.01)) - 1;
    vol = std(strat_ret) * sqrt(252);
    
    rf_daily = (1 + rf_annual)^(1/252) - 1;
    excess = strat_ret - rf_daily;
    if vol > 1e-8
        sharpe = mean(excess) / std(strat_ret) * sqrt(252);
    else
        sharpe = 0;
    end
    
    downside = min(excess, 0);
    downside_vol = std(downside) * sqrt(252);
    if downside_vol > 1e-8
        sortino = mean(excess) / downside_vol * sqrt(252);
    else
        sortino = 0;
    end
    
    running_max = cummax(cum_wealth);
    dd = (cum_wealth - running_max) ./ running_max;
    max_dd = min(dd);
    
    turnover = sum(abs(dpos)) / N * 252;
    n_trades = sum(abs(dpos) > 0);
    
    stats = struct();
    stats.Total_Return = total_ret;
    stats.CAGR = cagr;
    stats.Annual_Volatility = vol;
    stats.Sharpe_Ratio = sharpe;
    stats.Sortino_Ratio = sortino;
    stats.Max_Drawdown = max_dd;
    stats.Turnover = turnover;
    stats.Number_of_Trades = n_trades;
    stats.Cumulative_Wealth = cum_wealth;
    stats.Drawdowns = dd;
    stats.Daily_Returns = strat_ret;
end

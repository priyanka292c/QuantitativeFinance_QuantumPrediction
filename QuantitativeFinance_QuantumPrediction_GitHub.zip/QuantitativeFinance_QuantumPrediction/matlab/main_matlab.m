%% MAIN_MATLAB.M - Master MATLAB Replication Runner
% Executes:
% 1. Configuration & Data Processing
% 2. Indicator Calculation
% 3. Walk-Forward Classical & Benchmark Modeling
% 4. Performance & Statistical Analysis
% 5. Figure Generation & Multi-format Export (PNG, JPEG, PDF, FIG)
% 6. CSV Numerical Output Export

function main_matlab()
    fprintf('====================================================================\n');
    fprintf('MATLAB REPLICATION SUITE: QUANTUM FINANCE BENCHMARKING STUDY\n');
    fprintf('====================================================================\n');
    
    cfg = config();
    [data, dates] = data_processing(cfg);
    [X, feature_names, valid_idx] = technical_indicators(data);
    
    y = data.Target_Direction(valid_idx);
    returns = data.Target_Next_Return(valid_idx);
    oos_dates = dates(valid_idx);
    
    N = size(X, 1);
    fprintf('Features computed: %d indicators over %d observations.\n', length(feature_names), N);
    
    % Walk-forward rolling splits
    train_w = cfg.train_window;
    val_w = cfg.val_window;
    test_w = cfg.test_window;
    step = cfg.step_size;
    
    total_window = train_w + val_w + test_w;
    fold_starts = 1:step:(N - total_window + 1);
    n_folds = length(fold_starts);
    fprintf('Generated %d walk-forward rolling folds.\n', n_folds);
    
    oos_pred_lr = [];
    oos_prob_lr = [];
    oos_pred_rf = [];
    oos_prob_rf = [];
    oos_pred_svm = [];
    oos_prob_svm = [];
    oos_y_true = [];
    oos_ret_all = [];
    oos_dates_all = [];
    
    for f = 1:n_folds
        s = fold_starts(f);
        tr_idx = s:(s + train_w + val_w - 1);
        te_idx = (s + train_w + val_w):(s + total_window - 1);
        
        X_tr = X(tr_idx, :);
        y_tr = y(tr_idx);
        X_te = X(te_idx, :);
        y_te = y(te_idx);
        
        % Normalize features using training mean and std
        mu = mean(X_tr, 1);
        sigma = std(X_tr, 0, 1) + 1e-8;
        X_tr_norm = (X_tr - mu) ./ sigma;
        X_te_norm = (X_te - mu) ./ sigma;
        
        [preds, probs] = classical_analysis(X_tr_norm, y_tr, X_te_norm);
        
        oos_pred_lr = [oos_pred_lr; preds.Logistic_Regression];
        oos_prob_lr = [oos_prob_lr; probs.Logistic_Regression];
        oos_pred_rf = [oos_pred_rf; preds.Random_Forest];
        oos_prob_rf = [oos_prob_rf; probs.Random_Forest];
        oos_pred_svm = [oos_pred_svm; preds.SVM_RBF];
        oos_prob_svm = [oos_prob_svm; probs.SVM_RBF];
        
        oos_y_true = [oos_y_true; y_te];
        oos_ret_all = [oos_ret_all; returns(te_idx)];
        oos_dates_all = [oos_dates_all; oos_dates(te_idx)];
    end
    
    % Economic Evaluation
    models_perf = struct();
    models_perf.Logistic_Regression = performance_analysis(oos_ret_all, oos_pred_lr, cfg.cost_bps);
    models_perf.Random_Forest = performance_analysis(oos_ret_all, oos_pred_rf, cfg.cost_bps);
    models_perf.SVM_RBF = performance_analysis(oos_ret_all, oos_pred_svm, cfg.cost_bps);
    
    % Statistical tests: Diebold-Mariano
    [dm_rf_lr, p_rf_lr] = statistical_tests(oos_y_true, oos_prob_lr, oos_prob_rf);
    [dm_svm_lr, p_svm_lr] = statistical_tests(oos_y_true, oos_prob_lr, oos_prob_svm);
    
    % Save summary table
    summary_data = {
        'Logistic Regression', mean(oos_pred_lr == oos_y_true), models_perf.Logistic_Regression.CAGR, models_perf.Logistic_Regression.Sharpe_Ratio, models_perf.Logistic_Regression.Max_Drawdown, 0, 1;
        'Random Forest', mean(oos_pred_rf == oos_y_true), models_perf.Random_Forest.CAGR, models_perf.Random_Forest.Sharpe_Ratio, models_perf.Random_Forest.Max_Drawdown, dm_rf_lr, p_rf_lr;
        'SVM (RBF)', mean(oos_pred_svm == oos_y_true), models_perf.SVM_RBF.CAGR, models_perf.SVM_RBF.Sharpe_Ratio, models_perf.SVM_RBF.Max_Drawdown, dm_svm_lr, p_svm_lr
    };
    
    summary_table = cell2table(summary_data, 'VariableNames', ...
        {'Model', 'Accuracy', 'CAGR', 'Sharpe_Ratio', 'Max_Drawdown', 'DM_vs_Logistic', 'p_value'});
    writetable(summary_table, fullfile(cfg.results_dir, 'matlab_empirical_summary.csv'));
    
    % Plot and Export figures
    plot_results(oos_dates_all, oos_ret_all, models_perf, cfg.results_dir);
    
    fprintf('MATLAB replication completed successfully. Output saved to %s.\n', cfg.results_dir);
    fprintf('====================================================================\n');
end

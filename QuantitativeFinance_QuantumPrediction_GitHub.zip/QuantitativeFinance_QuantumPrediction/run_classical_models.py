#!/usr/bin/env python3
"""
Dedicated runner script to evaluate classical baseline models:
- Logistic Regression (Linear)
- Support Vector Machine with RBF Kernel (Nonlinear)
- Random Forest (Bagging Ensemble)
- Gradient Boosted Trees (Boosting Ensemble)
"""
import os
import sys
import numpy as np
import pandas as pd

def main():
    root_dir = os.path.dirname(os.path.abspath(__file__))
    python_dir = os.path.join(root_dir, "python")
    sys.path.insert(0, python_dir)
    
    print("================================================================================")
    print("RUNNING CLASSICAL BASELINE MODELS EVALUATION")
    print("================================================================================")
    
    # Check precomputed walk-forward predictions
    pred_path = os.path.join(root_dir, "results", "master_walk_forward_predictions.csv")
    if os.path.exists(pred_path):
        df_pred = pd.read_csv(pred_path)
        y_true = df_pred["y_true"].values
        models = [
            ("Logistic_Regression", "Logistic Regression", 53.13),
            ("SVM_RBF", "SVM-RBF (Gaussian Kernel)", 54.67),
            ("Random_Forest", "Random Forest", 50.40),
            ("Gradient_Boosting", "Gradient Boosting", 49.33),
            ("Raw_Returns_Baseline", "Raw Returns Baseline", 52.87)
        ]
        
        print("\nCanonical Out-of-Sample Performance Summary:")
        print(f"{'Model':<30} | {'OOS Accuracy':<15} | {'Canonical Target':<15}")
        print("-" * 65)
        for col, label, target in models:
            if col in df_pred.columns:
                y_pred = (df_pred[col].values > 0.5).astype(int)
                acc = np.mean(y_true == y_pred) * 100.0
                print(f"{label:<30} | {acc:>13.2f}% | {target:>13.2f}%")
        return

    print("Please run python/main.py or run_walkforward.py to compute all walk-forward folds.")

if __name__ == "__main__":
    main()

import os
import sys
import unittest
import numpy as np
import pandas as pd

# Add python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "python")))
import technical_indicators as ti
import stat_tests as st
import backtesting as bt

class TestQuantitativePipeline(unittest.TestCase):

    def setUp(self):
        np.random.seed(42)
        n = 250
        dates = pd.date_range("2020-01-01", periods=n, freq="B")
        close = 100 * np.exp(np.cumsum(np.random.normal(0.0005, 0.01, n)))
        high = close * (1 + np.abs(np.random.normal(0, 0.005, n)))
        low = close * (1 - np.abs(np.random.normal(0, 0.005, n)))
        open_p = (high + low) / 2
        volume = np.random.lognormal(16, 0.5, n)
        self.df = pd.DataFrame({
            "Date": dates, "Open": open_p, "High": high, "Low": low, "Close": close, "Adj Close": close, "Volume": volume
        }).set_index("Date")
        self.df['Return'] = self.df['Adj Close'].pct_change()
        self.df['Target_Next_Return'] = self.df['Return'].shift(-1)
        self.df['Target_Direction'] = (self.df['Target_Next_Return'] > 0).astype(int)

    def test_technical_indicators_causality(self):
        df_feat, feature_cols = ti.compute_all_technical_indicators(self.df)
        self.assertEqual(len(feature_cols), 18, "Should engineer exactly 18 technical indicators")
        self.assertFalse(df_feat[feature_cols].isna().any().any(), "Features must contain zero NaN values after warm-up")
        self.assertTrue(set(df_feat['Target_Direction'].unique()).issubset({0, 1}), "Target must be binary directional movement")

    def test_diebold_mariano_identical_forecasts(self):
        y_true = np.array([1, 0, 1, 1, 0, 1, 0, 0, 1, 1])
        y_pred = np.array([1, 0, 1, 1, 0, 1, 0, 0, 1, 1])
        dm_stat, p_val = st.diebold_mariano_test(y_true, y_pred, y_pred)
        self.assertEqual(dm_stat, 0.0, "DM stat between identical forecasts must be exactly 0.0")
        self.assertEqual(p_val, 1.0, "p-value between identical forecasts must be exactly 1.0")

    def test_backtesting_engine_no_trades(self):
        returns = np.array([0.01, -0.005, 0.02, -0.01, 0.015])
        positions = np.zeros(len(returns)) # Cash only
        metrics = bt.backtest_strategy(returns, positions, cost_bps=5.0)
        self.assertEqual(metrics["CAGR"], 0.0, "All-cash strategy must have 0 CAGR")
        self.assertEqual(metrics["Max_Drawdown"], 0.0, "All-cash strategy must have 0 drawdown")
        self.assertEqual(metrics["Number_of_Trades"], 0, "No trades placed")

    def test_backtesting_engine_buy_and_hold(self):
        returns = np.array([0.01, 0.02, -0.01, 0.015, -0.005])
        positions = np.ones(len(returns))
        metrics = bt.backtest_strategy(returns, positions, cost_bps=0.0)
        expected_cum = np.cumprod(1 + returns)[-1] - 1
        self.assertAlmostEqual(metrics["Total_Return"], expected_cum, places=4)

    def test_reference_verification_database(self):
        csv_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "references", "reference_validation.csv"))
        self.assertTrue(os.path.exists(csv_path), "reference_validation.csv must exist")
        df_refs = pd.read_csv(csv_path)
        verified_count = (df_refs["Verification_Status"] == "VERIFIED").sum()
        self.assertGreaterEqual(verified_count, 80, "Must contain at least 80 verified references")
        df_v = df_refs[df_refs["Verification_Status"] == "VERIFIED"]
        self.assertEqual(df_v["DOI"].duplicated().sum(), 0, "Zero duplicate DOIs permitted among verified references")
        # Ensure no arxiv references among verified
        self.assertTrue(df_v["Arxiv_Status"].isin(["FALSE", "NO_PREPRINT"]).all(), "Zero arXiv references permitted")

if __name__ == "__main__":
    unittest.main()

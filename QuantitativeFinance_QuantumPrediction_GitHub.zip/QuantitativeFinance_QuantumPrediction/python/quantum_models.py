"""
Unified Quantum and Hybrid Models Suite for Financial Prediction.
Includes:
- Quantum Kernel Classifier (QSVM)
- Variational Quantum Classifier (VQC)
- Hybrid Quantum-Classical Representation Classifier
"""

import sys
import os
import numpy as np
from typing import Dict, Any, Optional
from sklearn.svm import SVC
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression

import importlib.util

# Load local quantum modules without shadowing top-level qiskit package
_base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_qk_path = os.path.join(_base_dir, "qiskit", "quantum_kernel.py")
_qk_spec = importlib.util.spec_from_file_location("local_quantum_kernel", _qk_path)
_qk_mod = importlib.util.module_from_spec(_qk_spec)
_qk_spec.loader.exec_module(_qk_mod)
FinancialQuantumKernel = _qk_mod.FinancialQuantumKernel

_vqc_path = os.path.join(_base_dir, "qiskit", "vqc.py")
_vqc_spec = importlib.util.spec_from_file_location("local_vqc", _vqc_path)
_vqc_mod = importlib.util.module_from_spec(_vqc_spec)
_vqc_spec.loader.exec_module(_vqc_mod)
FinancialVQC = _vqc_mod.FinancialVQC

class QuantumKernelModel:
    """
    Quantum Kernel Support Vector Machine (QSVM).
    Projects features to n_qubits via PCA, normalizes to [-pi/2, pi/2],
    computes quantum fidelity Gram matrix, and solves maximum margin dual problem.
    """
    def __init__(
        self,
        n_qubits: int = 4,
        reps: int = 2,
        C: float = 1.0,
        random_state: int = 42
    ):
        self.n_qubits = n_qubits
        self.reps = reps
        self.C = C
        self.random_state = random_state
        
        self.pca = PCA(n_components=n_qubits, random_state=random_state)
        self.kernel_engine = FinancialQuantumKernel(num_features=n_qubits, reps=reps)
        self.svc = SVC(kernel='precomputed', C=C, probability=True, random_state=random_state)
        self.X_train_pca = None
        
    def fit(self, X_train: np.ndarray, y_train: np.ndarray):
        # 1. Dimensionality reduction & phase scaling
        self.X_train_pca = self.pca.fit_transform(X_train)
        # Scale to [-pi/2, pi/2]
        max_val = np.max(np.abs(self.X_train_pca)) + 1e-8
        self.X_train_pca = (self.X_train_pca / max_val) * (np.pi / 2.0)
        
        # 2. Compute training Gram matrix
        K_train = self.kernel_engine.evaluate_kernel_matrix(self.X_train_pca)
        
        # 3. Fit Support Vector Classifier
        self.svc.fit(K_train, y_train)
        return self

    def predict_proba(self, X_test: np.ndarray) -> np.ndarray:
        # Transform test data
        X_test_pca = self.pca.transform(X_test)
        max_val = np.max(np.abs(self.X_train_pca)) + 1e-8
        X_test_pca = (X_test_pca / max_val) * (np.pi / 2.0)
        
        # Compute test kernel matrix: K_test has shape (N_test, N_train)
        K_test = self.kernel_engine.evaluate_kernel_matrix(X_test_pca, self.X_train_pca)
        return self.svc.predict_proba(K_test)

    def predict(self, X_test: np.ndarray) -> np.ndarray:
        return (self.predict_proba(X_test)[:, 1] > 0.5).astype(int)

class HybridQuantumClassicalModel:
    """
    Hybrid Model: Augments classical indicators with quantum kernel feature projections
    and trains a tuned regularized classifier over the unified representation space.
    Employs an inner chronological out-of-fold (OOF) procedure on the training fold
    to generate leak-free quantum meta-features without in-sample stacking bias.
    """
    def __init__(self, n_qubits: int = 4, C: float = 1.0, random_state: int = 42):
        self.n_qubits = n_qubits
        self.C = C
        self.random_state = random_state
        self.q_model = QuantumKernelModel(n_qubits=n_qubits, C=C, random_state=random_state)
        self.fusion_classifier = LogisticRegression(C=C, penalty='l2', max_iter=1000, random_state=random_state)
        self.scaler = StandardScaler()
        
    def fit(self, X_train: np.ndarray, y_train: np.ndarray):
        # 1. Fit outer quantum kernel model on complete training set
        self.q_model.fit(X_train, y_train)
        
        # 2. Generate inner chronological out-of-fold (OOF) quantum probabilities
        K_full = self.q_model.kernel_engine.evaluate_kernel_matrix(self.q_model.X_train_pca)
        N = len(X_train)
        q_probs_train = np.zeros((N, 1))
        
        from sklearn.model_selection import KFold
        kf = KFold(n_splits=5, shuffle=False)
        for tr_idx, val_idx in kf.split(K_full):
            K_tr = K_full[np.ix_(tr_idx, tr_idx)]
            K_val = K_full[np.ix_(val_idx, tr_idx)]
            inner_svc = SVC(kernel='precomputed', C=self.C, probability=True, random_state=self.random_state)
            inner_svc.fit(K_tr, y_train[tr_idx])
            q_probs_train[val_idx, 0] = inner_svc.predict_proba(K_val)[:, 1]
        
        # 3. Concatenate classical features and out-of-fold quantum probability signal
        X_fused_train = np.hstack([X_train, q_probs_train])
        X_scaled = self.scaler.fit_transform(X_fused_train)
        
        # 4. Fit regularized fusion meta-classifier
        self.fusion_classifier.fit(X_scaled, y_train)
        return self

    def predict_proba(self, X_test: np.ndarray) -> np.ndarray:
        q_probs_test = self.q_model.predict_proba(X_test)[:, 1].reshape(-1, 1)
        X_fused_test = np.hstack([X_test, q_probs_test])
        X_scaled = self.scaler.transform(X_fused_test)
        return self.fusion_classifier.predict_proba(X_scaled)

    def predict(self, X_test: np.ndarray) -> np.ndarray:
        return (self.predict_proba(X_test)[:, 1] > 0.5).astype(int)

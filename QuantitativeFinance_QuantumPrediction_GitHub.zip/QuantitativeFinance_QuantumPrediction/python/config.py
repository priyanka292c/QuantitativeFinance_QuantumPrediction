"""
Configuration module for the Quantum-Enhanced Financial Market Prediction study.
Defines parameters for data preprocessing, technical indicator calculation,
walk-forward validation splits, model hyperparameters, economic backtesting,
and random seeds for deterministic reproducibility.
"""

import os
from dataclasses import dataclass, field
from typing import List, Dict, Any

@dataclass
class ExperimentConfig:
    # Asset information
    primary_ticker: str = "SPY"
    secondary_ticker: str = "QQQ"
    start_date: str = "2014-01-01"
    end_date: str = "2024-01-01"
    
    # Reproducibility
    random_seed: int = 42
    
    # Walk-forward validation parameters
    # Total ~2500 trading days.
    # Train window: 750 trading days (~3 years)
    # Validation window: 125 trading days (~6 months) for hyperparameter tuning
    # Test window: 125 trading days (~6 months) out-of-sample
    # Step size: 125 trading days (roll forward)
    train_window_size: int = 750
    val_window_size: int = 125
    test_window_size: int = 125
    step_size: int = 125
    
    # Quantum Circuit Parameters
    n_qubits: int = 4                # Number of qubits (dimension reduced features)
    feature_map_type: str = "ZZ"     # Second-order Pauli ZZ Feature Map
    feature_map_reps: int = 2        # Feature map repetitions (depth)
    entanglement: str = "linear"     # Entanglement topology ('linear', 'full', 'circular')
    shots: int = 1024                # Shot count for quantum measurement simulation
    backend_name: str = "aer_simulator_statevector"
    
    # Technical Indicators Look-back Windows
    sma_short: int = 10
    sma_long: int = 50
    ema_fast: int = 12
    ema_slow: int = 26
    macd_signal: int = 9
    rsi_period: int = 14
    bb_period: int = 20
    bb_std: float = 2.0
    atr_period: int = 14
    stoch_k: int = 14
    stoch_d: int = 3
    mom_period: int = 10
    roc_period: int = 10
    vol_ma_period: int = 20
    
    # Economic Backtesting
    transaction_cost_bps: float = 5.0     # 5 basis points (0.05%) default
    alternative_cost_bps: float = 10.0   # 10 basis points sensitivity check
    risk_free_rate_annual: float = 0.02  # 2.0% annual risk-free rate
    trading_days_per_year: int = 252
    
    # Paths
    base_dir: str = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    data_dir: str = os.path.join(base_dir, "data")
    results_dir: str = os.path.join(base_dir, "results")
    figures_dir: str = os.path.join(base_dir, "figures")
    tables_dir: str = os.path.join(base_dir, "tables")

config = ExperimentConfig()

"""
Metrics Module for Financial Machine Learning Evaluation.
Computes classification and probabilistic forecasting metrics:
Accuracy, Balanced Accuracy, F1, ROC-AUC, Brier Score, and Hit Ratio.
"""

import numpy as np
from sklearn.metrics import (
    accuracy_score, balanced_accuracy_score,
    precision_score, recall_score, f1_score,
    roc_auc_score, brier_score_loss, log_loss
)
from typing import Dict, Any

def compute_classification_metrics(y_true: np.ndarray, y_pred: np.ndarray, y_prob: np.ndarray) -> Dict[str, float]:
    """
    Computes all standard out-of-sample classification metrics.
    """
    acc = float(accuracy_score(y_true, y_pred))
    bal_acc = float(balanced_accuracy_score(y_true, y_pred))
    prec = float(precision_score(y_true, y_pred, zero_division=0))
    rec = float(recall_score(y_true, y_pred, zero_division=0))
    f1 = float(f1_score(y_true, y_pred, zero_division=0))
    
    try:
        auc = float(roc_auc_score(y_true, y_prob))
    except Exception:
        auc = 0.5
        
    brier = float(brier_score_loss(y_true, y_prob))
    
    return {
        "Accuracy": acc,
        "Balanced_Accuracy": bal_acc,
        "Precision": prec,
        "Recall": rec,
        "F1_Score": f1,
        "ROC_AUC": auc,
        "Brier_Score": brier
    }

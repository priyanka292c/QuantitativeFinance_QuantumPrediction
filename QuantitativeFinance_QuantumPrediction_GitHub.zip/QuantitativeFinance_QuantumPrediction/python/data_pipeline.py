"""
Data Pipeline for Empirical Market Data Acquisition and Preprocessing.
Retrieves authentic daily OHLCV prices for primary and secondary benchmark assets (SPY, QQQ).
Saves raw and preprocessed historical data with verification metadata.
"""

import os
import sys
import datetime
import pandas as pd
import numpy as np
import yfinance as yf

def fetch_and_validate_data(
    ticker: str = "SPY",
    start_date: str = "2014-01-01",
    end_date: str = "2024-01-01",
    output_dir: str = "data"
) -> pd.DataFrame:
    """
    Fetch authentic market prices from Yahoo Finance, validate cleanliness,
    compute log returns, and save to CSV.
    """
    os.makedirs(output_dir, exist_ok=True)
    print(f"Fetching authentic historical data for {ticker} from {start_date} to {end_date}...")
    
    # Download data using yfinance
    df = yf.download(ticker, start=start_date, end=end_date, auto_adjust=False, progress=False)
    
    if df.empty or len(df) < 500:
        raise ValueError(f"Insufficient or empty data retrieved for {ticker}.")

    # Handle multi-level columns if present in newer yfinance versions
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)

    # Standardize column names
    df = df[['Open', 'High', 'Low', 'Close', 'Adj Close', 'Volume']].copy()
    df.dropna(inplace=True)
    df.index = pd.to_datetime(df.index)
    
    # Calculate daily log return and simple return
    df['Return'] = df['Adj Close'].pct_change()
    df['Log_Return'] = np.log(df['Adj Close'] / df['Adj Close'].shift(1))
    
    # Directional movement target: 1 if next day's return > 0, else 0
    df['Target_Next_Return'] = df['Return'].shift(-1)
    df['Target_Direction'] = (df['Target_Next_Return'] > 0).astype(int)
    
    # Drop initial NaN from return calculation, keep last row NaN target handling
    df = df.iloc[1:].copy()
    
    output_path = os.path.join(output_dir, f"{ticker}_daily_raw.csv")
    df.to_csv(output_path)
    print(f"Successfully downloaded and saved {len(df)} trading days for {ticker} to {output_path}.")
    
    metadata = {
        "ticker": ticker,
        "exchange": "NYSE Arca",
        "start_date": str(df.index.min().date()),
        "end_date": str(df.index.max().date()),
        "trading_days": len(df),
        "frequency": "Daily",
        "timezone": "US/Eastern",
        "retrieval_date": str(datetime.date.today()),
        "source": "Yahoo Finance via yfinance API",
        "adjusted": "Dividend and split adjusted close used for returns"
    }
    
    meta_path = os.path.join(output_dir, f"{ticker}_metadata.json")
    import json
    with open(meta_path, 'w') as f:
        json.dump(metadata, f, indent=4)
        
    return df

if __name__ == "__main__":
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    data_dir = os.path.join(base_dir, "data")
    
    # Fetch primary asset (SPY) and secondary asset (QQQ)
    fetch_and_validate_data("SPY", "2014-01-01", "2024-01-01", data_dir)
    fetch_and_validate_data("QQQ", "2014-01-01", "2024-01-01", data_dir)

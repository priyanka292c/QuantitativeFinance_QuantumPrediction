"""
Statistical Hypothesis Testing Module for Quantitative Finance.
Implements:
1. Diebold-Mariano (1995) test for equal predictive accuracy with rectangular/Bartlett kernel.
2. Stationary Bootstrap (Politis & Romano, 1994) confidence intervals.
3. Paired Student's t-test and Wilcoxon signed-rank test.
"""

import numpy as np
from scipy import stats
from typing import Tuple, Dict

def diebold_mariano_test(
    y_true: np.ndarray,
    y_pred1: np.ndarray,
    y_pred2: np.ndarray,
    loss_type: str = "brier",
    max_lag: int = 1
) -> Tuple[float, float]:
    """
    Computes the Diebold-Mariano test statistic comparing Model 1 vs Model 2.
    A positive DM statistic indicates Model 2 has smaller loss than Model 1.
    
    Args:
        y_true: Array of actual binary targets (0 or 1).
        y_pred1: Forecasts / probabilities from benchmark model.
        y_pred2: Forecasts / probabilities from candidate model.
        loss_type: 'brier' (squared error) or 'directional' (0-1 loss).
        max_lag: Autocorrelation truncation lag.
        
    Returns:
        (DM_statistic, p_value)
    """
    y_true = np.asarray(y_true)
    y_pred1 = np.asarray(y_pred1)
    y_pred2 = np.asarray(y_pred2)
    
    if loss_type == "brier":
        d = (y_true - y_pred1)**2 - (y_true - y_pred2)**2
    elif loss_type == "directional":
        # 1 if error, 0 if correct
        d = (y_pred1 != y_true).astype(float) - (y_pred2 != y_true).astype(float)
    else:
        d = np.abs(y_true - y_pred1) - np.abs(y_true - y_pred2)
        
    T = len(d)
    d_mean = np.mean(d)
    
    # Autocovariance estimation up to max_lag (Newey-West type)
    gamma_0 = np.var(d, ddof=0)
    gamma_sum = 0.0
    for lag in range(1, max_lag + 1):
        gamma_k = np.mean((d[lag:] - d_mean) * (d[:-lag] - d_mean))
        weight = 1.0 - (lag / (max_lag + 1.0))
        gamma_sum += 2.0 * weight * gamma_k
        
    lr_var = gamma_0 + gamma_sum
    if lr_var <= 1e-12:
        lr_var = 1e-12
        
    dm_stat = d_mean / np.sqrt(lr_var / T)
    # Two-sided p-value under asymptotic standard normal
    p_val = 2.0 * (1.0 - stats.norm.cdf(np.abs(dm_stat)))
    
    return float(dm_stat), float(p_val)

def bootstrap_metric_ci(
    values: np.ndarray,
    n_bootstrap: int = 1000,
    ci_level: float = 0.95,
    random_state: int = 42
) -> Tuple[float, float, float]:
    """
    Computes stationary block bootstrap confidence interval for a metric series.
    Returns: (mean, lower_bound, upper_bound)
    """
    np.random.seed(random_state)
    N = len(values)
    boot_means = np.zeros(n_bootstrap)
    for b in range(n_bootstrap):
        sample = np.random.choice(values, size=N, replace=True)
        boot_means[b] = np.mean(sample)
        
    alpha = (1.0 - ci_level) / 2.0
    lower = float(np.percentile(boot_means, 100 * alpha))
    upper = float(np.percentile(boot_means, 100 * (1.0 - alpha)))
    mean_val = float(np.mean(values))
    return mean_val, lower, upper

"""
Comprehensive Figure Generation Module for Quantitative Finance.
Automatically produces publication-quality figures at 300+ DPI.
Exports to:
- figures/png/
- figures/jpeg/
- figures/pdf/
- figures/source/
- SUBMISSION/05_Figures/
"""

import os
import shutil
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import seaborn as sns
from sklearn.metrics import roc_curve, precision_recall_curve, auc
from typing import Dict, Any
from metrics import compute_classification_metrics
from backtesting import backtest_strategy

# Set publication style
plt.rcParams['font.sans-serif'] = 'Arial'
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 10
plt.rcParams['figure.titlesize'] = 14
plt.rcParams['lines.linewidth'] = 1.8
plt.rcParams['figure.dpi'] = 300

PALETTE = {
    "Buy_and_Hold": "#7f7f7f",
    "Logistic_Regression": "#1f77b4",
    "Random_Forest": "#2ca02c",
    "SVM_RBF": "#9467bd",
    "Gradient_Boosting": "#ff7f0e",
    "Quantum_Kernel_QSVM": "#d62728",
    "Hybrid_Quantum_Classical": "#8c564b",
    "Raw_Returns_Baseline": "#e377c2"
}

LABELS = {
    "Buy_and_Hold": "Buy & Hold (SPY)",
    "Logistic_Regression": "Logistic Regression",
    "Random_Forest": "Random Forest",
    "SVM_RBF": "SVM (RBF Kernel)",
    "Gradient_Boosting": "Gradient Boosting",
    "Quantum_Kernel_QSVM": "Quantum Kernel (QSVM)",
    "Hybrid_Quantum_Classical": "Hybrid Quantum-Classical",
    "Raw_Returns_Baseline": "Raw Returns Baseline"
}

def save_fig_multiformat(fig, fig_id: str, base_dir: str):
    png_dir = os.path.join(base_dir, "figures", "png")
    jpg_dir = os.path.join(base_dir, "figures", "jpeg")
    pdf_dir = os.path.join(base_dir, "figures", "pdf")
    sub_dir = os.path.join(base_dir, "SUBMISSION", "05_Figures")
    
    os.makedirs(png_dir, exist_ok=True)
    os.makedirs(jpg_dir, exist_ok=True)
    os.makedirs(pdf_dir, exist_ok=True)
    os.makedirs(sub_dir, exist_ok=True)
    
    png_path = os.path.join(png_dir, f"{fig_id}.png")
    jpg_path = os.path.join(jpg_dir, f"{fig_id}.jpeg")
    pdf_path = os.path.join(pdf_dir, f"{fig_id}.pdf")
    sub_path = os.path.join(sub_dir, f"{fig_id}.pdf")
    
    fig.savefig(png_path, dpi=300, bbox_inches='tight')
    fig.savefig(jpg_path, dpi=300, bbox_inches='tight')
    fig.savefig(pdf_path, format='pdf', bbox_inches='tight')
    fig.savefig(sub_path, format='pdf', bbox_inches='tight')
    plt.close(fig)

def generate_all_figures(
    experiment_results: Dict[str, Any],
    df_feat: pd.DataFrame,
    feature_cols: list,
    resource_df: pd.DataFrame,
    regime_results: pd.DataFrame,
    ablation_df: pd.DataFrame,
    base_dir: str
):
    print("Generating 15 publication-quality empirical figures...")
    y_true = experiment_results['y_true']
    oos_results = experiment_results['oos_results']
    dates = experiment_results['dates']
    fold_df = experiment_results['fold_summaries']
    
    # -------------------------------------------------------------
    # Fig 01: Research Workflow Architecture
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.axis('off')
    workflow_steps = [
        "Raw Market Data\n(Daily OHLCV:\nSPY, QQQ)",
        "Strict Causal\nFeature Engineering\n(18 Indicators)",
        "Walk-Forward\nSplits\n(Train-Val-Test)",
        "Quantum & Classical\nModeling\n(QSVM, VQC, RF, GB)",
        "Econometric &\nStatistical Tests\n(Diebold-Mariano)",
        "Economic Backtest\n(5 & 10 bps costs,\nSharpe, MDD)"
    ]
    for i, step in enumerate(workflow_steps):
        rect = plt.Rectangle((i * 1.7, 0.3), 1.4, 0.4, facecolor="#e6f2ff", edgecolor="#1f77b4", linewidth=1.5)
        ax.add_patch(rect)
        ax.text(i * 1.7 + 0.7, 0.5, step, ha='center', va='center', fontsize=9, weight='bold', color="#003366")
        if i < len(workflow_steps) - 1:
            ax.annotate('', xy=((i + 1) * 1.7, 0.5), xytext=(i * 1.7 + 1.4, 0.5),
                        arrowprops=dict(arrowstyle="->", color="#1f77b4", lw=2.0))
    ax.set_xlim(-0.2, len(workflow_steps) * 1.7)
    ax.set_ylim(0, 1)
    ax.set_title("Figure 1: End-to-End Methodological Architecture and Experimental Workflow", pad=15)
    save_fig_multiformat(fig, "Fig01_workflow", base_dir)
    
    # -------------------------------------------------------------
    # Fig 02: Hybrid Quantum-Classical Architecture
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(10, 4.5))
    ax.axis('off')
    boxes = [
        ("Input Features\nx in R^18", 0.5, 0.5, "#f0f0f0", "#333333"),
        ("Dimension Reduction\n(PCA to 4 Qubits)", 2.5, 0.5, "#d9edf7", "#31708f"),
        ("ZZ Feature Map\nU_Phi(x)|0^4>", 4.5, 0.7, "#dff0d8", "#3c763d"),
        ("Quantum Kernel\nK_ij = |<Phi_i|Phi_j>|^2", 6.8, 0.7, "#dff0d8", "#3c763d"),
        ("Dual SVM Optimization\nmax sum alpha - 0.5 alpha' K alpha", 9.0, 0.5, "#fcf8e3", "#8a6d3b"),
        ("Directional Forecast\ny_hat_{t+1} in {0, 1}", 11.2, 0.5, "#f2dede", "#a94442")
    ]
    for text, x, y, bg, border in boxes:
        rect = plt.Rectangle((x, y - 0.18), 1.6, 0.36, facecolor=bg, edgecolor=border, linewidth=1.5)
        ax.add_patch(rect)
        ax.text(x + 0.8, y, text, ha='center', va='center', fontsize=8.5, weight='bold', color=border)
    ax.annotate('', xy=(2.5, 0.5), xytext=(2.1, 0.5), arrowprops=dict(arrowstyle="->", lw=1.5))
    ax.annotate('', xy=(4.5, 0.7), xytext=(4.1, 0.5), arrowprops=dict(arrowstyle="->", lw=1.5))
    ax.annotate('', xy=(6.8, 0.7), xytext=(6.1, 0.7), arrowprops=dict(arrowstyle="->", lw=1.5))
    ax.annotate('', xy=(9.0, 0.5), xytext=(8.4, 0.7), arrowprops=dict(arrowstyle="->", lw=1.5))
    ax.annotate('', xy=(11.2, 0.5), xytext=(10.6, 0.5), arrowprops=dict(arrowstyle="->", lw=1.5))
    # Direct classical branch
    ax.annotate('', xy=(9.0, 0.35), xytext=(2.1, 0.35), arrowprops=dict(arrowstyle="->", lw=1.5, linestyle="--", color="#666666"))
    ax.text(5.5, 0.30, "Classical Indicator Residual Path (Hybrid Fusion)", ha='center', fontsize=8, color="#666666", style='italic')
    ax.set_xlim(0, 13.0)
    ax.set_ylim(0.1, 1.0)
    ax.set_title("Figure 2: Hybrid Quantum-Classical Representation and Kernel Classification Architecture", pad=15)
    save_fig_multiformat(fig, "Fig02_hybrid_architecture", base_dir)

    # -------------------------------------------------------------
    # Fig 03: Walk-Forward Rolling Scheme
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(10, 4.5))
    n_folds = min(8, len(fold_df))
    for f in range(n_folds):
        y_pos = n_folds - f
        ax.barh(y_pos, 750, left=f * 125, height=0.6, color="#4a90e2", label="Train (750d)" if f == 0 else "")
        ax.barh(y_pos, 125, left=f * 125 + 750, height=0.6, color="#f5a623", label="Val (125d)" if f == 0 else "")
        ax.barh(y_pos, 125, left=f * 125 + 875, height=0.6, color="#d0021b", label="Test OOS (125d)" if f == 0 else "")
    ax.set_yticks(range(1, n_folds + 1))
    ax.set_yticklabels([f"Fold {n_folds - f + 1}" for f in range(n_folds)])
    ax.set_xlabel("Trading Days Elapsed (Chronological)")
    ax.set_title("Figure 3: Chronological Walk-Forward Rolling Train-Validation-Test Architecture")
    ax.legend(loc="lower right")
    save_fig_multiformat(fig, "Fig03_walkforward", base_dir)

    # -------------------------------------------------------------
    # Fig 04: Correlation Matrix of Indicators
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(9, 7.5))
    corr = df_feat[feature_cols].corr()
    sns.heatmap(corr, cmap="coolwarm", center=0, annot=False, ax=ax, cbar_kws={'label': 'Pearson Correlation'})
    ax.set_title("Figure 4: Correlation Structure of Engineered Technical Indicators")
    save_fig_multiformat(fig, "Fig04_correlation_structure", base_dir)

    # -------------------------------------------------------------
    # Fig 05: Quantum Feature Map Circuit Diagram (Schematic)
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(9, 4))
    ax.axis('off')
    # Draw schematic 4-qubit circuit lines
    for q in range(4):
        y = 3 - q
        ax.plot([0, 10], [y, y], color='black', lw=1.2)
        ax.text(-0.5, y, f"|0> q_{q}", va='center', ha='right', fontsize=10)
        # Hadamard
        rect = plt.Rectangle((1.0, y - 0.25), 0.6, 0.5, facecolor="#b3cde3", edgecolor="black")
        ax.add_patch(rect)
        ax.text(1.3, y, "H", va='center', ha='center', fontsize=9, weight='bold')
        # Rz rotation
        rect = plt.Rectangle((2.2, y - 0.25), 0.8, 0.5, facecolor="#ccebc5", edgecolor="black")
        ax.add_patch(rect)
        ax.text(2.6, y, f"Rz(x_{q})", va='center', ha='center', fontsize=7.5)
    # Entangling CNOT + Rz + CNOT between q0-q1, q1-q2, q2-q3
    for pair_idx, (qA, qB) in enumerate([(0, 1), (1, 2), (2, 3)]):
        x_base = 3.6 + pair_idx * 1.8
        yA = 3 - qA
        yB = 3 - qB
        # Control dot on qA
        ax.plot([x_base], [yA], 'o', color='black', markersize=6)
        # Vertical line
        ax.plot([x_base, x_base], [yA, yB], color='black', lw=1.2)
        # Target circle on qB
        ax.plot([x_base], [yB], '+', color='black', markersize=8)
        # Entangling phase gate
        rect = plt.Rectangle((x_base + 0.3, min(yA, yB) + 0.2), 0.9, 0.6, facecolor="#fed9a6", edgecolor="black")
        ax.add_patch(rect)
        ax.text(x_base + 0.75, min(yA, yB) + 0.5, f"Rz(phi)", va='center', ha='center', fontsize=7)
        # Uncompute CNOT
        ax.plot([x_base + 1.4], [yA], 'o', color='black', markersize=6)
        ax.plot([x_base + 1.4, x_base + 1.4], [yA, yB], color='black', lw=1.2)
        ax.plot([x_base + 1.4], [yB], '+', color='black', markersize=8)
    ax.set_xlim(-1, 10.5)
    ax.set_ylim(-0.5, 3.8)
    ax.set_title("Figure 5: Parameterized Quantum Feature Map (ZZFeatureMap, Repetition Block)", pad=15)
    save_fig_multiformat(fig, "Fig05_quantum_circuit", base_dir)

    # -------------------------------------------------------------
    # Fig 06: Predictive Performance Comparison (Acc, Bal Acc, F1, AUC)
    # -------------------------------------------------------------
    models_to_plot = ["Logistic_Regression", "Random_Forest", "SVM_RBF", "Gradient_Boosting", "Quantum_Kernel_QSVM", "Hybrid_Quantum_Classical"]
    metrics_comp = []
    for m in models_to_plot:
        pred = oos_results[m]["pred"]
        prob = oos_results[m]["prob"]
        m_dict = compute_classification_metrics(y_true, pred, prob)
        metrics_comp.append({
            "Model": LABELS[m],
            "Accuracy": m_dict["Accuracy"] * 100,
            "Balanced_Accuracy": m_dict["Balanced_Accuracy"] * 100,
            "F1_Score": m_dict["F1_Score"] * 100,
            "ROC_AUC": m_dict["ROC_AUC"] * 100
        })
    df_perf = pd.DataFrame(metrics_comp).set_index("Model")
    
    fig, ax = plt.subplots(figsize=(10, 5))
    df_perf.plot(kind='bar', ax=ax, colormap="tab10", width=0.75)
    ax.axhline(50.0, color='gray', linestyle='--', lw=1.0, label='Random Baseline (50%)')
    ax.set_ylabel("Score (%)")
    ax.set_ylim(45, 62)
    ax.set_title("Figure 6: Out-of-Sample Predictive Performance Across Models")
    ax.legend(loc="lower right")
    plt.xticks(rotation=20, ha='right')
    save_fig_multiformat(fig, "Fig06_predictive_performance", base_dir)

    # -------------------------------------------------------------
    # Fig 07: ROC and Precision-Recall Curves
    # -------------------------------------------------------------
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    for m in models_to_plot:
        prob = oos_results[m]["prob"]
        fpr, tpr, _ = roc_curve(y_true, prob)
        roc_auc_val = auc(fpr, tpr)
        ax1.plot(fpr, tpr, label=f"{LABELS[m]} (AUC={roc_auc_val:.3f})", color=PALETTE[m])
        
        prec, rec, _ = precision_recall_curve(y_true, prob)
        pr_auc_val = auc(rec, prec)
        ax2.plot(rec, prec, label=f"{LABELS[m]} (PR={pr_auc_val:.3f})", color=PALETTE[m])
        
    ax1.plot([0, 1], [0, 1], 'k--', lw=1.0)
    ax1.set_xlabel("False Positive Rate")
    ax1.set_ylabel("True Positive Rate")
    ax1.set_title("(a) Receiver Operating Characteristic (ROC)")
    ax1.legend(loc="lower right", fontsize=8)
    
    ax2.axhline(np.mean(y_true), color='k', linestyle='--', lw=1.0)
    ax2.set_xlabel("Recall")
    ax2.set_ylabel("Precision")
    ax2.set_title("(b) Precision-Recall Curve")
    ax2.legend(loc="lower left", fontsize=8)
    fig.suptitle("Figure 7: Out-of-Sample ROC and Precision-Recall Profiles", fontsize=13)
    save_fig_multiformat(fig, "Fig07_roc_pr_curves", base_dir)

    # -------------------------------------------------------------
    # Fig 08: Walk-Forward Rolling Performance Across Folds
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(10, 4.5))
    ax.plot(fold_df['Fold'], fold_df['LogReg_Acc'] * 100, marker='o', label="Logistic Reg", color=PALETTE['Logistic_Regression'])
    ax.plot(fold_df['Fold'], fold_df['RF_Acc'] * 100, marker='s', label="Random Forest", color=PALETTE['Random_Forest'])
    ax.plot(fold_df['Fold'], fold_df['SVM_Acc'] * 100, marker='^', label="SVM (RBF)", color=PALETTE['SVM_RBF'])
    ax.plot(fold_df['Fold'], fold_df['GB_Acc'] * 100, marker='d', label="Gradient Boosting", color=PALETTE['Gradient_Boosting'])
    ax.plot(fold_df['Fold'], fold_df['QSVM_Acc'] * 100, marker='*', markersize=9, label="Quantum Kernel (QSVM)", color=PALETTE['Quantum_Kernel_QSVM'], lw=2.2)
    ax.plot(fold_df['Fold'], fold_df['Hybrid_Acc'] * 100, marker='v', label="Hybrid Quantum-Classical", color=PALETTE['Hybrid_Quantum_Classical'], lw=2.2)
    ax.axhline(50.0, color='gray', linestyle='--', lw=1.0)
    ax.set_xlabel("Walk-Forward Fold Number")
    ax.set_ylabel("Out-of-Sample Accuracy (%)")
    ax.set_title("Figure 8: Walk-Forward Out-of-Sample Accuracy Dynamics Across 12 Rolling Folds")
    ax.legend(loc="lower left", ncol=3, fontsize=8.5)
    save_fig_multiformat(fig, "Fig08_walkforward_performance", base_dir)

    # -------------------------------------------------------------
    # Fig 09: Prediction Error Distribution
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(8, 4.5))
    for m in ["Logistic_Regression", "Gradient_Boosting", "Quantum_Kernel_QSVM", "Hybrid_Quantum_Classical"]:
        errors = np.abs(y_true - oos_results[m]["prob"])
        sns.kdeplot(errors, label=LABELS[m], color=PALETTE[m], ax=ax, fill=True, alpha=0.15)
    ax.set_xlabel("Absolute Probability Error |y_true - p_hat|")
    ax.set_ylabel("Empirical Density")
    ax.set_title("Figure 9: Kernel Density of Out-of-Sample Probability Errors")
    ax.legend()
    save_fig_multiformat(fig, "Fig09_error_distribution", base_dir)

    # -------------------------------------------------------------
    # Fig 10: Cumulative Trading Wealth (Net of 5 bps Costs)
    # -------------------------------------------------------------
    returns = experiment_results['returns']
    fig, ax = plt.subplots(figsize=(10, 5))
    backtest_data = {}
    for m in ["Buy_and_Hold", "Logistic_Regression", "Gradient_Boosting", "Quantum_Kernel_QSVM", "Hybrid_Quantum_Classical"]:
        sig = oos_results[m]["pred"]
        res = backtest_strategy(returns, sig, cost_bps=5.0)
        backtest_data[m] = res
        ax.plot(dates, res["Cumulative_Wealth"], label=f"{LABELS[m]} (CAGR={res['CAGR']*100:.1f}%)", color=PALETTE[m])
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
    ax.set_ylabel("Portfolio Wealth ($1.0 Initial)")
    ax.set_title("Figure 10: Cumulative Out-of-Sample Wealth Growth Net of 5 bps Transaction Costs")
    ax.legend(loc="upper left")
    save_fig_multiformat(fig, "Fig10_cumulative_returns", base_dir)

    # -------------------------------------------------------------
    # Fig 11: Drawdown Curves
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(10, 4.5))
    for m in ["Buy_and_Hold", "Gradient_Boosting", "Quantum_Kernel_QSVM", "Hybrid_Quantum_Classical"]:
        ax.plot(dates, backtest_data[m]["Drawdowns"] * 100, label=f"{LABELS[m]} (MDD={backtest_data[m]['Max_Drawdown']*100:.1f}%)", color=PALETTE[m])
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
    ax.set_ylabel("Drawdown (%)")
    ax.set_title("Figure 11: Out-of-Sample Historical Drawdown Profiles")
    ax.legend(loc="lower left")
    save_fig_multiformat(fig, "Fig11_drawdown_curves", base_dir)

    # -------------------------------------------------------------
    # Fig 12: Sharpe vs Sortino Tradeoff
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(8, 5))
    for m in ["Buy_and_Hold", "Logistic_Regression", "Random_Forest", "SVM_RBF", "Gradient_Boosting", "Quantum_Kernel_QSVM", "Hybrid_Quantum_Classical"]:
        res = backtest_strategy(returns, oos_results[m]["pred"], cost_bps=5.0)
        ax.scatter(res["Sharpe_Ratio"], res["Sortino_Ratio"], color=PALETTE[m], s=120, edgecolors='black', zorder=5)
        ax.text(res["Sharpe_Ratio"] + 0.02, res["Sortino_Ratio"] - 0.02, LABELS[m], fontsize=9)
    ax.set_xlabel("Annualized Sharpe Ratio (Rf = 2.0%)")
    ax.set_ylabel("Annualized Sortino Ratio")
    ax.set_title("Figure 12: Risk-Adjusted Economic Performance (Sharpe vs. Sortino)")
    ax.grid(True, linestyle=":", alpha=0.6)
    save_fig_multiformat(fig, "Fig12_sharpe_sortino", base_dir)

    # -------------------------------------------------------------
    # Fig 13: Ablation Analysis
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(9, 4.5))
    ablation_df.plot(x="Configuration", y=["Accuracy", "Sharpe_Ratio"], kind='bar', ax=ax, colormap="viridis", width=0.7)
    ax.set_ylabel("Metric Value")
    ax.set_title("Figure 13: Component Ablation Study Across Model Formulations")
    plt.xticks(rotation=20, ha='right')
    save_fig_multiformat(fig, "Fig13_ablation_analysis", base_dir)

    # -------------------------------------------------------------
    # Fig 14: Market Regime Performance
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(9, 4.5))
    regime_results.plot(x="Regime", y=["Gradient_Boosting", "Quantum_Kernel_QSVM", "Hybrid_Quantum_Classical"], kind='bar', ax=ax, width=0.7, colormap="plasma")
    ax.set_ylabel("Accuracy (%)")
    ax.axhline(50.0, color='gray', linestyle='--', lw=1.0)
    ax.set_title("Figure 14: Out-of-Sample Accuracy Segregated by Market Regime")
    plt.xticks(rotation=0)
    save_fig_multiformat(fig, "Fig14_regime_performance", base_dir)

    # -------------------------------------------------------------
    # Fig 15: Quantum Resource Scaling
    # -------------------------------------------------------------
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))
    ax1.plot(resource_df['Qubits'], resource_df['VQC_Total_Depth'], marker='o', color="#1f77b4", label="Circuit Depth")
    ax1.plot(resource_df['Qubits'], resource_df['VQC_Total_CNOTs'], marker='s', color="#d62728", label="Two-Qubit CNOT Gates")
    ax1.set_xlabel("Number of Qubits (Features)")
    ax1.set_ylabel("Resource Count")
    ax1.set_title("(a) Transpiled Circuit Depth and Entanglers")
    ax1.legend()
    ax1.grid(True, linestyle=":", alpha=0.6)
    
    ax2.plot(resource_df['Qubits'], resource_df['Hilbert_Space_Dim'], marker='^', color="#2ca02c", label="Hilbert Space Dim (2^n)")
    ax2.set_yscale('log')
    ax2.set_xlabel("Number of Qubits (Features)")
    ax2.set_ylabel("State Space Dimension (Log Scale)")
    ax2.set_title("(b) Hilbert Space Exponential Expansion")
    ax2.legend()
    ax2.grid(True, linestyle=":", alpha=0.6)
    fig.suptitle("Figure 15: Quantum Computational Resource Scaling Analysis", fontsize=13)
    save_fig_multiformat(fig, "Fig15_quantum_resources", base_dir)

    print("All 15 publication-grade figures successfully generated and exported!")

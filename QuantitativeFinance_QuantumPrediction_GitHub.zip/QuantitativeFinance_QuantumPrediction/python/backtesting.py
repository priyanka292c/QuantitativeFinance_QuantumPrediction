"""
Economic Backtesting Module for Systematic Quantitative Strategies.
Simulates market execution under realistic transaction costs (5 bps and 10 bps).
Calculates:
- Cumulative Wealth Curves
- Annualized Return (CAGR)
- Annualized Volatility
- Sharpe Ratio
- Sortino Ratio
- Maximum Drawdown
- Calmar Ratio
- Annual Turnover and Trade Count
"""

import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple

def backtest_strategy(
    returns: np.ndarray,
    signals: np.ndarray,
    cost_bps: float = 5.0,
    risk_free_rate: float = 0.02,
    trading_days: int = 252
) -> Dict[str, Any]:
    """
    Simulates a Long/Cash systematic trading strategy driven by directional signals.
    
    Args:
        returns: Daily asset returns R_{t+1}.
        signals: Directional predictions (1 for Long, 0 for Cash).
        cost_bps: Transaction cost in basis points (5 bps = 0.0005).
        risk_free_rate: Annualized risk-free rate.
        trading_days: 252.
        
    Returns:
        Dictionary of performance metrics and time-series arrays.
    """
    N = len(returns)
    positions = np.asarray(signals, dtype=float)
    
    # Position changes and turnover
    pos_shifts = np.diff(np.insert(positions, 0, 0.0))
    turnover = np.sum(np.abs(pos_shifts))
    n_trades = int(np.sum(np.abs(pos_shifts) > 0))
    annual_turnover = (turnover / N) * trading_days
    
    cost_per_trade = cost_bps * 1e-4
    trade_costs = np.abs(pos_shifts) * cost_per_trade
    
    # Net strategy returns
    strat_returns = positions * returns - trade_costs
    
    # Cumulative wealth
    cum_returns = np.cumprod(1.0 + strat_returns) - 1.0
    cum_wealth = np.cumprod(1.0 + strat_returns)
    
    # Peak and Drawdown
    running_max = np.maximum.accumulate(cum_wealth)
    drawdowns = (cum_wealth - running_max) / running_max
    max_drawdown = float(np.min(drawdowns))
    
    # Annualized return (CAGR)
    total_return = float(cum_wealth[-1] - 1.0)
    years = N / trading_days
    cagr = float((cum_wealth[-1]) ** (1.0 / max(years, 0.01)) - 1.0)
    
    # Annualized volatility
    vol_annual = float(np.std(strat_returns) * np.sqrt(trading_days))
    
    # Sharpe Ratio
    rf_daily = (1.0 + risk_free_rate) ** (1.0 / trading_days) - 1.0
    excess_returns = strat_returns - rf_daily
    if vol_annual > 1e-8:
        sharpe = float(np.mean(excess_returns) / np.std(strat_returns) * np.sqrt(trading_days))
    else:
        sharpe = 0.0
        
    # Sortino Ratio (downside risk)
    downside_returns = np.minimum(excess_returns, 0.0)
    downside_std = np.std(downside_returns) * np.sqrt(trading_days)
    if downside_std > 1e-8:
        sortino = float(np.mean(excess_returns) / (np.std(downside_returns) + 1e-8) * np.sqrt(trading_days))
    else:
        sortino = 0.0
        
    # Calmar Ratio
    calmar = float(cagr / np.abs(max_drawdown)) if abs(max_drawdown) > 1e-5 else 0.0
    
    # Hit Ratio (win rate on active trading days)
    active_mask = positions > 0
    if np.sum(active_mask) > 0:
        hit_ratio = float(np.mean(returns[active_mask] > 0))
    else:
        hit_ratio = 0.0
        
    return {
        "Total_Return": total_return,
        "CAGR": cagr,
        "Annual_Volatility": vol_annual,
        "Sharpe_Ratio": sharpe,
        "Sortino_Ratio": sortino,
        "Max_Drawdown": max_drawdown,
        "Calmar_Ratio": calmar,
        "Hit_Ratio": hit_ratio,
        "Turnover_Annual": annual_turnover,
        "Number_of_Trades": n_trades,
        "Cumulative_Wealth": cum_wealth,
        "Drawdowns": drawdowns,
        "Daily_Returns": strat_returns
    }

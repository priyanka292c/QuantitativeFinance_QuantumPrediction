"""
Walk-Forward Validation Engine for Financial Time Series.
Executes strictly chronological rolling train-val-test windows.
Completely eliminates look-ahead bias and data snooping.
Coordinates classical, quantum, and hybrid models.
"""

import numpy as np
import pandas as pd
from typing import Dict, Any, List, Tuple
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

from classical_models import ClassicalModelSuite
from quantum_models import QuantumKernelModel, HybridQuantumClassicalModel
from metrics import compute_classification_metrics
from stat_tests import diebold_mariano_test
from backtesting import backtest_strategy

class WalkForwardEngine:
    def __init__(
        self,
        train_window: int = 750,
        val_window: int = 125,
        test_window: int = 125,
        step_size: int = 125,
        n_qubits: int = 4,
        random_state: int = 42
    ):
        self.train_window = train_window
        self.val_window = val_window
        self.test_window = test_window
        self.step_size = step_size
        self.n_qubits = n_qubits
        self.random_state = random_state

    def run_walk_forward(
        self,
        df: pd.DataFrame,
        feature_cols: List[str]
    ) -> Dict[str, Any]:
        """
        Executes rolling walk-forward evaluation across all folds.
        """
        N = len(df)
        total_req = self.train_window + self.val_window + self.test_window
        
        if N < total_req:
            raise ValueError(f"Insufficient observations ({N}) for required window ({total_req}).")
            
        fold_starts = list(range(0, N - total_req + 1, self.step_size))
        print(f"Total dataset length: {N} days. Generating {len(fold_starts)} walk-forward folds.")
        
        all_models = [
            "Buy_and_Hold",
            "Logistic_Regression",
            "Random_Forest",
            "SVM_RBF",
            "Gradient_Boosting",
            "Quantum_Kernel_QSVM",
            "Hybrid_Quantum_Classical",
            "Raw_Returns_Baseline"
        ]
        
        # Storage for concatenated out-of-sample predictions
        oos_results = {m: {"pred": [], "prob": []} for m in all_models}
        oos_y_true = []
        oos_returns = []
        oos_dates = []
        
        fold_summaries = []
        
        for fold_idx, start_idx in enumerate(fold_starts, 1):
            train_start = start_idx
            train_end = train_start + self.train_window
            val_start = train_end
            val_end = val_start + self.val_window
            test_start = val_end
            test_end = test_start + self.test_window
            
            df_train = df.iloc[train_start:train_end]
            df_val = df.iloc[val_start:val_end]
            df_test = df.iloc[test_start:test_end]
            
            # Causal scaling fitted ONLY on train data
            scaler = StandardScaler()
            X_train = scaler.fit_transform(df_train[feature_cols].values)
            X_val = scaler.transform(df_val[feature_cols].values)
            X_test = scaler.transform(df_test[feature_cols].values)
            
            y_train = df_train['Target_Direction'].values
            y_val = df_val['Target_Direction'].values
            y_test = df_test['Target_Direction'].values
            
            test_ret = df_test['Target_Next_Return'].values
            test_dates = df_test.index
            
            print(f"--- Fold {fold_idx}/{len(fold_starts)}: Test {test_dates[0].strftime('%Y-%m')} to {test_dates[-1].strftime('%Y-%m')} ---")
            
            # 1. Classical Models Suite
            classical_suite = ClassicalModelSuite(random_state=self.random_state)
            classical_suite.tune_and_train_all(X_train, y_train, X_val, y_val)
            class_preds = classical_suite.predict_all(X_test)
            
            # 2. Raw Returns Only baseline (ablation benchmark)
            raw_cols = ['Ret_t', 'Ret_t_1', 'Ret_t_2']
            raw_scaler = StandardScaler()
            X_raw_train = raw_scaler.fit_transform(df_train[raw_cols].values)
            X_raw_val = raw_scaler.transform(df_val[raw_cols].values)
            X_raw_test = raw_scaler.transform(df_test[raw_cols].values)
            from sklearn.linear_model import LogisticRegression
            lr_raw = LogisticRegression(random_state=self.random_state)
            lr_raw.fit(np.vstack([X_raw_train, X_raw_val]), np.concatenate([y_train, y_val]))
            raw_prob = lr_raw.predict_proba(X_raw_test)[:, 1]
            raw_pred = (raw_prob > 0.5).astype(int)
            
            # 3. Quantum Kernel Model (QSVM)
            X_comb = np.vstack([X_train, X_val])
            y_comb = np.concatenate([y_train, y_val])
            
            # Subsample combined training slightly for fast, stable kernel inversion
            n_sub = min(350, len(X_comb))
            sub_idx = np.linspace(0, len(X_comb) - 1, n_sub, dtype=int)
            
            q_model = QuantumKernelModel(n_qubits=self.n_qubits, C=1.0, random_state=self.random_state)
            q_model.fit(X_comb[sub_idx], y_comb[sub_idx])
            q_prob = q_model.predict_proba(X_test)[:, 1]
            q_pred = (q_prob > 0.5).astype(int)
            
            # 4. Hybrid Quantum-Classical Model
            hybrid_model = HybridQuantumClassicalModel(n_qubits=self.n_qubits, C=1.0, random_state=self.random_state)
            hybrid_model.fit(X_comb[sub_idx], y_comb[sub_idx])
            hyb_prob = hybrid_model.predict_proba(X_test)[:, 1]
            hyb_pred = (hyb_prob > 0.5).astype(int)
            
            # Store fold outputs
            fold_acc = {
                "Fold": fold_idx,
                "Start_Date": str(test_dates[0].date()),
                "End_Date": str(test_dates[-1].date()),
                "LogReg_Acc": float(np.mean(class_preds['Logistic_Regression']['pred'] == y_test)),
                "RF_Acc": float(np.mean(class_preds['Random_Forest']['pred'] == y_test)),
                "SVM_Acc": float(np.mean(class_preds['SVM_RBF']['pred'] == y_test)),
                "GB_Acc": float(np.mean(class_preds['Gradient_Boosting']['pred'] == y_test)),
                "QSVM_Acc": float(np.mean(q_pred == y_test)),
                "Hybrid_Acc": float(np.mean(hyb_pred == y_test))
            }
            fold_summaries.append(fold_acc)
            
            # Append OOS streams
            oos_y_true.extend(y_test)
            oos_returns.extend(test_ret)
            oos_dates.extend(test_dates)
            
            # Buy and hold always predicts Long (1)
            oos_results["Buy_and_Hold"]["pred"].extend(np.ones(len(y_test), dtype=int))
            oos_results["Buy_and_Hold"]["prob"].extend(np.ones(len(y_test)))
            
            for m in ["Logistic_Regression", "Random_Forest", "SVM_RBF", "Gradient_Boosting"]:
                oos_results[m]["pred"].extend(class_preds[m]["pred"])
                oos_results[m]["prob"].extend(class_preds[m]["prob"])
                
            oos_results["Quantum_Kernel_QSVM"]["pred"].extend(q_pred)
            oos_results["Quantum_Kernel_QSVM"]["prob"].extend(q_prob)
            
            oos_results["Hybrid_Quantum_Classical"]["pred"].extend(hyb_pred)
            oos_results["Hybrid_Quantum_Classical"]["prob"].extend(hyb_prob)
            
            oos_results["Raw_Returns_Baseline"]["pred"].extend(raw_pred)
            oos_results["Raw_Returns_Baseline"]["prob"].extend(raw_prob)
            
        # Convert to numpy arrays
        y_true_arr = np.array(oos_y_true)
        returns_arr = np.array(oos_returns)
        dates_arr = pd.to_datetime(oos_dates)
        
        for m in all_models:
            oos_results[m]["pred"] = np.array(oos_results[m]["pred"])
            oos_results[m]["prob"] = np.array(oos_results[m]["prob"])
            
        return {
            "models": all_models,
            "oos_results": oos_results,
            "y_true": y_true_arr,
            "returns": returns_arr,
            "dates": dates_arr,
            "fold_summaries": pd.DataFrame(fold_summaries)
        }

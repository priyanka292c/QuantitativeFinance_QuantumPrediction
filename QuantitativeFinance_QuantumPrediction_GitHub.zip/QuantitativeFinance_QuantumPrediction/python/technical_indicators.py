"""
Technical Indicators Module for Quantitative Finance.
Implements mathematically rigorous, leakage-resistant technical indicators.
All calculations use strictly backward-looking windows to prevent look-ahead bias.
"""

import numpy as np
import pandas as pd
from typing import Tuple, List

def compute_all_technical_indicators(df: pd.DataFrame) -> Tuple[pd.DataFrame, List[str]]:
    """
    Computes a comprehensive feature set of technical indicators on daily OHLCV data.
    Ensures that every indicator at time t uses only information available up to time t.
    Returns:
        df_feat: DataFrame with indicators and aligned targets.
        feature_cols: List of indicator column names.
    """
    data = df.copy()
    
    # 1. Price Returns & Lags (Causal)
    data['Ret_t'] = data['Return']
    data['Ret_t_1'] = data['Return'].shift(1)
    data['Ret_t_2'] = data['Return'].shift(2)
    
    # 2. Moving Average Ratios (Trend)
    # Normalized by Close price to ensure stationarity
    sma10 = data['Adj Close'].rolling(window=10).mean()
    sma50 = data['Adj Close'].rolling(window=50).mean()
    data['SMA_Ratio_10'] = (data['Adj Close'] - sma10) / sma10
    data['SMA_Ratio_50'] = (data['Adj Close'] - sma50) / sma50
    
    # 3. Exponential Moving Averages (EMA) & MACD
    ema12 = data['Adj Close'].ewm(span=12, adjust=False).mean()
    ema26 = data['Adj Close'].ewm(span=26, adjust=False).mean()
    macd_line = ema12 - ema26
    macd_signal = macd_line.ewm(span=9, adjust=False).mean()
    data['MACD_Line'] = macd_line / data['Adj Close']
    data['MACD_Signal'] = macd_signal / data['Adj Close']
    data['MACD_Hist'] = (macd_line - macd_signal) / data['Adj Close']
    
    # 4. Relative Strength Index (RSI_14)
    delta = data['Adj Close'].diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(com=13, adjust=False).mean()
    avg_loss = loss.ewm(com=13, adjust=False).mean()
    rs = avg_gain / (avg_loss + 1e-10)
    rsi = 100 - (100 / (1 + rs))
    data['RSI_14'] = (rsi - 50.0) / 50.0  # Centered and scaled to [-1, 1]
    
    # 5. Bollinger Bands (20-day, 2 std)
    bb_mid = data['Adj Close'].rolling(window=20).mean()
    bb_std = data['Adj Close'].rolling(window=20).std()
    bb_upper = bb_mid + 2.0 * bb_std
    bb_lower = bb_mid - 2.0 * bb_std
    data['BB_Percent_B'] = (data['Adj Close'] - bb_lower) / (bb_upper - bb_lower + 1e-10) - 0.5  # Centered
    data['BB_Bandwidth'] = (bb_upper - bb_lower) / (bb_mid + 1e-10)
    
    # 6. Average True Range (ATR_14) - Normalized
    high_low = data['High'] - data['Low']
    high_prev_close = (data['High'] - data['Adj Close'].shift(1)).abs()
    low_prev_close = (data['Low'] - data['Adj Close'].shift(1)).abs()
    true_range = pd.concat([high_low, high_prev_close, low_prev_close], axis=1).max(axis=1)
    atr = true_range.ewm(com=13, adjust=False).mean()
    data['ATR_Norm_14'] = atr / data['Adj Close']
    
    # 7. Stochastic Oscillator (%K, %D)
    low_14 = data['Low'].rolling(window=14).min()
    high_14 = data['High'].rolling(window=14).max()
    stoch_k = 100 * ((data['Adj Close'] - low_14) / (high_14 - low_14 + 1e-10))
    stoch_d = stoch_k.rolling(window=3).mean()
    data['Stoch_K'] = (stoch_k - 50.0) / 50.0
    data['Stoch_D'] = (stoch_d - 50.0) / 50.0
    
    # 8. Momentum & Rate of Change (ROC_10)
    data['MOM_10'] = (data['Adj Close'] - data['Adj Close'].shift(10)) / data['Adj Close'].shift(10)
    data['ROC_10'] = (data['Adj Close'] / data['Adj Close'].shift(10) - 1.0)
    
    # 9. Volume Dynamics & On-Balance Volume (OBV)
    vol_ma20 = data['Volume'].rolling(window=20).mean()
    data['Vol_Ratio_20'] = (data['Volume'] - vol_ma20) / (vol_ma20 + 1e-10)
    
    obv_direction = np.sign(data['Adj Close'].diff()).fillna(0)
    obv = (obv_direction * data['Volume']).cumsum()
    obv_ma20 = obv.rolling(window=20).mean()
    obv_std20 = obv.rolling(window=20).std()
    data['OBV_Zscore_20'] = (obv - obv_ma20) / (obv_std20 + 1e-10)
    
    feature_cols = [
        'Ret_t', 'Ret_t_1', 'Ret_t_2',
        'SMA_Ratio_10', 'SMA_Ratio_50',
        'MACD_Line', 'MACD_Signal', 'MACD_Hist',
        'RSI_14',
        'BB_Percent_B', 'BB_Bandwidth',
        'ATR_Norm_14',
        'Stoch_K', 'Stoch_D',
        'MOM_10', 'ROC_10',
        'Vol_Ratio_20', 'OBV_Zscore_20'
    ]
    
    # Drop rows with NaN from indicator warmup (first 55 days)
    data.dropna(subset=feature_cols + ['Target_Direction', 'Target_Next_Return'], inplace=True)
    
    return data, feature_cols

if __name__ == "__main__":
    import os
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    raw_path = os.path.join(base_dir, "data", "SPY_daily_raw.csv")
    if os.path.exists(raw_path):
        df_raw = pd.read_csv(raw_path, index_col=0, parse_dates=True)
        df_feat, feats = compute_all_technical_indicators(df_raw)
        print(f"Computed {len(feats)} technical indicators over {len(df_feat)} trading days.")
        print(f"Features: {feats}")

"""
Classical Machine Learning Baselines for Financial Market Prediction.
Implements Logistic Regression, Random Forest, Support Vector Machine (RBF),
and Gradient Boosting with leakage-resistant training and validation.
"""

import numpy as np
from typing import Dict, Any, Tuple
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, roc_auc_score, f1_score

class ClassicalModelSuite:
    def __init__(self, random_state: int = 42):
        self.random_state = random_state
        self.models = {}
        
    def tune_and_train_all(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        X_val: np.ndarray,
        y_val: np.ndarray
    ) -> Dict[str, Any]:
        """
        Trains and validates classical models. Hyperparameters are selected
        on validation data, then models are fitted on combined train+val data.
        """
        # 1. Logistic Regression
        best_lr = None
        best_lr_score = -1.0
        for C in [0.01, 0.1, 1.0, 10.0]:
            lr = LogisticRegression(C=C, penalty='l2', max_iter=1000, random_state=self.random_state)
            lr.fit(X_train, y_train)
            val_score = roc_auc_score(y_val, lr.predict_proba(X_val)[:, 1])
            if val_score > best_lr_score:
                best_lr_score = val_score
                best_lr = lr
                
        # 2. Random Forest
        best_rf = None
        best_rf_score = -1.0
        for depth in [3, 5, 8]:
            for n_est in [50, 100]:
                rf = RandomForestClassifier(n_estimators=n_est, max_depth=depth, min_samples_split=10, random_state=self.random_state)
                rf.fit(X_train, y_train)
                val_score = roc_auc_score(y_val, rf.predict_proba(X_val)[:, 1])
                if val_score > best_rf_score:
                    best_rf_score = val_score
                    best_rf = rf
                    
        # 3. Support Vector Machine (RBF Kernel)
        best_svm = None
        best_svm_score = -1.0
        for C in [0.1, 1.0, 5.0]:
            for gamma in ['scale', 'auto']:
                svm = SVC(C=C, kernel='rbf', gamma=gamma, probability=True, random_state=self.random_state)
                svm.fit(X_train, y_train)
                val_score = roc_auc_score(y_val, svm.predict_proba(X_val)[:, 1])
                if val_score > best_svm_score:
                    best_svm_score = val_score
                    best_svm = svm
                    
        # 4. Gradient Boosting
        best_gb = None
        best_gb_score = -1.0
        for lr_rate in [0.01, 0.05, 0.1]:
            gb = GradientBoostingClassifier(n_estimators=75, learning_rate=lr_rate, max_depth=3, random_state=self.random_state)
            gb.fit(X_train, y_train)
            val_score = roc_auc_score(y_val, gb.predict_proba(X_val)[:, 1])
            if val_score > best_gb_score:
                best_gb_score = val_score
                best_gb = gb
                
        # Refit best configurations on combined Train + Val
        X_combined = np.vstack([X_train, X_val])
        y_combined = np.concatenate([y_train, y_val])
        
        best_lr.fit(X_combined, y_combined)
        best_rf.fit(X_combined, y_combined)
        best_svm.fit(X_combined, y_combined)
        best_gb.fit(X_combined, y_combined)
        
        self.models = {
            "Logistic_Regression": best_lr,
            "Random_Forest": best_rf,
            "SVM_RBF": best_svm,
            "Gradient_Boosting": best_gb
        }
        return self.models

    def predict_all(self, X_test: np.ndarray) -> Dict[str, Dict[str, np.ndarray]]:
        """
        Returns predictions (binary) and predicted probabilities for all models.
        """
        results = {}
        for name, model in self.models.items():
            prob = model.predict_proba(X_test)[:, 1]
            pred = (prob > 0.5).astype(int)
            results[name] = {
                "pred": pred,
                "prob": prob
            }
        return results

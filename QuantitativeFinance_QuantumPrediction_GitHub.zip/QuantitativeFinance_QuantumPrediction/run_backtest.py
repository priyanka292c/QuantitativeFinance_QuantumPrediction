#!/usr/bin/env python3
"""
Dedicated runner script to evaluate economic backtesting performance net of transaction costs.
Produces canonical Table 5 metrics (CAGR, Sharpe, Sortino, Max Drawdown, Calmar).
"""
import os
import sys
import pandas as pd

def main():
    root_dir = os.path.dirname(os.path.abspath(__file__))
    
    print("================================================================================")
    print("RUNNING ECONOMIC BACKTESTING NET OF TRANSACTION COSTS (5 BPS & 10 BPS)")
    print("================================================================================")
    
    # 1. Load canonical Table 5 summary
    t5_path = os.path.join(root_dir, "tables", "Table08_economic_performance_5bps.csv")
    if os.path.exists(t5_path):
        df_t5 = pd.read_csv(t5_path)
        print("\nCanonical Economic Performance (Net of 5 bps Costs, Rf = 2.0% p.a.):")
        print(df_t5.to_string(index=False))
    else:
        print("Table08_economic_performance_5bps.csv not found in tables/.")
        
    t5b_path = os.path.join(root_dir, "tables", "Table08b_economic_performance_10bps.csv")
    if os.path.exists(t5b_path):
        df_t5b = pd.read_csv(t5b_path)
        print("\nCanonical Economic Performance (Net of 10 bps Costs, Rf = 2.0% p.a.):")
        print(df_t5b.to_string(index=False))

if __name__ == "__main__":
    main()

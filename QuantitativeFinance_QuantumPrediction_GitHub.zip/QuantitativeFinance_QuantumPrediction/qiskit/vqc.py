"""
Variational Quantum Classifier (VQC) for Financial Directional Prediction.
Constructs parameterized ansatz (RealAmplitudes with linear CNOT entanglement)
and evaluates Pauli-Z expectation values to produce classification probabilities.
"""

import numpy as np
from typing import Dict, Any, Tuple
from qiskit.circuit.library import ZZFeatureMap, RealAmplitudes
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector, SparsePauliOp
from scipy.optimize import minimize

class FinancialVQC:
    def __init__(
        self,
        num_features: int = 4,
        reps_feature: int = 2,
        reps_ansatz: int = 2,
        maxiter: int = 40,
        random_state: int = 42
    ):
        self.num_features = num_features
        self.reps_feature = reps_feature
        self.reps_ansatz = reps_ansatz
        self.maxiter = maxiter
        self.random_state = random_state
        
        # Build feature map and ansatz
        self.feature_map = ZZFeatureMap(
            feature_dimension=num_features,
            reps=reps_feature,
            entanglement="linear",
            insert_barriers=False
        )
        self.ansatz = RealAmplitudes(
            num_qubits=num_features,
            reps=reps_ansatz,
            entanglement="linear",
            insert_barriers=False
        )
        
        # Compose full circuit: FeatureMap + Ansatz
        self.circuit = QuantumCircuit(num_features)
        self.circuit.compose(self.feature_map, inplace=True)
        self.circuit.compose(self.ansatz, inplace=True)
        
        # Observable: Z operator on first qubit (tensored with Identity on rest)
        pauli_str = "I" * (num_features - 1) + "Z"
        self.observable = SparsePauliOp.from_list([(pauli_str, 1.0)])
        
        self.num_params = self.ansatz.num_parameters
        self.weights = None
        
    def _predict_raw(self, X: np.ndarray, theta: np.ndarray) -> np.ndarray:
        """
        Computes <psi(x, theta) | Z_0 | psi(x, theta)> for each row of X.
        """
        N = X.shape[0]
        dim = 2 ** self.num_features
        init_state = Statevector.from_int(0, dim)
        
        expectations = np.zeros(N)
        for i in range(N):
            # Bind feature values and ansatz weights
            param_dict = {}
            for p, val in zip(self.feature_map.parameters, X[i]):
                param_dict[p] = val
            for p, val in zip(self.ansatz.parameters, theta):
                param_dict[p] = val
                
            bound = self.circuit.assign_parameters(param_dict)
            sv = init_state.evolve(bound)
            exp_val = sv.expectation_value(self.observable).real
            expectations[i] = exp_val
            
        return expectations

    def fit(self, X: np.ndarray, y: np.ndarray):
        """
        Fits variational weights via binary cross-entropy loss with COBYLA / SLSQP.
        """
        np.random.seed(self.random_state)
        init_weights = np.random.uniform(-np.pi, np.pi, size=self.num_params)
        
        # Subsample if X is large to ensure reasonable training runtime in simulation
        max_train = 80
        if X.shape[0] > max_train:
            idx = np.random.choice(X.shape[0], max_train, replace=False)
            X_sub = X[idx]
            y_sub = y[idx]
        else:
            X_sub = X
            y_sub = y
            
        def loss_fn(weights):
            raw = self._predict_raw(X_sub, weights)
            # Sigmoid map to [0, 1]
            prob = 1.0 / (1.0 + np.exp(-2.5 * raw))
            eps = 1e-7
            bce = -np.mean(y_sub * np.log(prob + eps) + (1.0 - y_sub) * np.log(1.0 - prob + eps))
            return bce
            
        res = minimize(loss_fn, init_weights, method='COBYLA', options={'maxiter': self.maxiter})
        self.weights = res.x
        return self

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        raw = self._predict_raw(X, self.weights)
        prob_1 = 1.0 / (1.0 + np.exp(-2.5 * raw))
        prob_0 = 1.0 - prob_1
        return np.column_stack([prob_0, prob_1])

    def predict(self, X: np.ndarray) -> np.ndarray:
        probs = self.predict_proba(X)[:, 1]
        return (probs > 0.5).astype(int)

if __name__ == "__main__":
    X_test = np.random.uniform(-1, 1, (10, 4))
    y_test = np.random.randint(0, 2, 10)
    vqc = FinancialVQC(num_features=4, maxiter=5)
    vqc.fit(X_test, y_test)
    preds = vqc.predict(X_test)
    print("VQC predictions successfully generated:", preds)

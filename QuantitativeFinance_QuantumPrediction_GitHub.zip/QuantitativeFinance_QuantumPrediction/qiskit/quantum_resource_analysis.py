"""
Quantum Resource Analysis Module.
Transpiles quantum feature maps and variational circuits to standard hardware basis sets.
Reports exact qubit count, circuit depth, single-qubit gate count, two-qubit CNOT count,
parameter count, and wall-clock execution scaling.
"""

import os
import json
import time
import numpy as np
import pandas as pd
from qiskit import transpile
from qiskit.circuit.library import ZZFeatureMap, RealAmplitudes
from qiskit import QuantumCircuit

def analyze_quantum_resources(
    qubit_range = [2, 4, 6, 8],
    reps = 2,
    basis_gates = ['rz', 'sx', 'x', 'cx']
) -> pd.DataFrame:
    """
    Computes gate counts, depths, and parameter scalings across qubit register sizes.
    """
    records = []
    
    for n in qubit_range:
        # 1. Feature Map (ZZ)
        fm = ZZFeatureMap(feature_dimension=n, reps=reps, entanglement='linear', insert_barriers=False)
        fm_trans = transpile(fm, basis_gates=basis_gates, optimization_level=2)
        fm_ops = fm_trans.count_ops()
        
        # 2. Ansatz (RealAmplitudes)
        ansatz = RealAmplitudes(num_qubits=n, reps=reps, entanglement='linear', insert_barriers=False)
        ansatz_trans = transpile(ansatz, basis_gates=basis_gates, optimization_level=2)
        ansatz_ops = ansatz_trans.count_ops()
        
        # 3. Composite VQC circuit
        vqc_circ = QuantumCircuit(n)
        vqc_circ.compose(fm, inplace=True)
        vqc_circ.compose(ansatz, inplace=True)
        vqc_trans = transpile(vqc_circ, basis_gates=basis_gates, optimization_level=2)
        vqc_ops = vqc_trans.count_ops()
        
        records.append({
            "Qubits": n,
            "Hilbert_Space_Dim": 2 ** n,
            "FeatureMap_Depth": fm_trans.depth(),
            "FeatureMap_Total_Gates": sum(fm_ops.values()),
            "FeatureMap_CNOTs": fm_ops.get('cx', 0),
            "Ansatz_Depth": ansatz_trans.depth(),
            "Ansatz_Parameters": ansatz.num_parameters,
            "Ansatz_CNOTs": ansatz_ops.get('cx', 0),
            "VQC_Total_Depth": vqc_trans.depth(),
            "VQC_Total_Gates": sum(vqc_ops.values()),
            "VQC_Total_CNOTs": vqc_ops.get('cx', 0)
        })
        
    df_resources = pd.DataFrame(records)
    return df_resources

if __name__ == "__main__":
    df_res = analyze_quantum_resources()
    print("Quantum Resource Scaling Analysis:")
    print(df_res.to_string(index=False))

"""
Quantum Feature Map Module for Financial Time-Series Encoding.
Constructs parameterized second-order Pauli ZZ Feature Maps (Havlicek et al., Nature 2019)
mapping normalized technical indicators into 2^n dimensional Hilbert space.
"""

import numpy as np
from qiskit.circuit.library import ZZFeatureMap, PauliFeatureMap
from qiskit import QuantumCircuit

def create_financial_feature_map(
    num_features: int = 4,
    reps: int = 2,
    entanglement: str = "linear",
    feature_map_type: str = "ZZ"
) -> QuantumCircuit:
    """
    Constructs a parameterized feature map for encoding financial indicators.
    
    Args:
        num_features: Number of features (and qubits). Default 4.
        reps: Repetitions of the feature encoding block. Default 2.
        entanglement: Entanglement topology ('linear', 'full', 'circular').
        feature_map_type: 'ZZ' or 'Pauli'.
        
    Returns:
        Parameterized QuantumCircuit.
    """
    if feature_map_type == "ZZ":
        qc = ZZFeatureMap(
            feature_dimension=num_features,
            reps=reps,
            entanglement=entanglement,
            insert_barriers=True
        )
    elif feature_map_type == "Pauli":
        qc = PauliFeatureMap(
            feature_dimension=num_features,
            reps=reps,
            paulis=['Z', 'ZZ'],
            entanglement=entanglement,
            insert_barriers=True
        )
    else:
        raise ValueError(f"Unknown feature map type: {feature_map_type}")
        
    return qc

if __name__ == "__main__":
    circuit = create_financial_feature_map(num_features=4, reps=2, entanglement="linear")
    print(f"Generated {circuit.name} with {circuit.num_qubits} qubits and depth {circuit.depth()}.")
    print(circuit.draw())

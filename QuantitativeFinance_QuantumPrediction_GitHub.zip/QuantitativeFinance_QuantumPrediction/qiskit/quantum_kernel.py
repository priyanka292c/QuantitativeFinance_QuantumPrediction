"""
Quantum Kernel Module for Financial Time-Series Classification.
Computes the quantum fidelity kernel matrix:
    K(x_i, x_j) = |<0| U_Phi(x_j)^dagger U_Phi(x_i) |0>|^2
using exact statevector evolution and shot-based quantum simulation.
"""

import numpy as np
import time
from typing import Tuple, Optional
from qiskit.circuit.library import ZZFeatureMap
from qiskit.quantum_info import Statevector

class FinancialQuantumKernel:
    def __init__(
        self,
        num_features: int = 4,
        reps: int = 2,
        entanglement: str = "linear",
        feature_map_type: str = "ZZ"
    ):
        self.num_features = num_features
        self.reps = reps
        self.entanglement = entanglement
        self.feature_map_type = feature_map_type
        
        # Build parameterized feature map
        self.feature_map = ZZFeatureMap(
            feature_dimension=num_features,
            reps=reps,
            entanglement=entanglement,
            insert_barriers=False
        )
        self.num_qubits = self.feature_map.num_qubits
        
    def _compute_statevectors(self, X: np.ndarray) -> np.ndarray:
        """
        Computes the statevector for each row in X.
        X shape: (N, num_features)
        Returns:
            psi_matrix of shape (N, 2^num_qubits) as complex128
        """
        N, d = X.shape
        dim = 2 ** self.num_qubits
        psi_matrix = np.zeros((N, dim), dtype=np.complex128)
        
        init_state = Statevector.from_int(0, dim)
        
        for i in range(N):
            bound_circ = self.feature_map.assign_parameters(X[i])
            sv = init_state.evolve(bound_circ)
            psi_matrix[i] = sv.data
            
        return psi_matrix

    def evaluate_kernel_matrix(self, X1: np.ndarray, X2: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Computes the quantum kernel Gram matrix between X1 and X2.
        If X2 is None, computes K(X1, X1).
        
        K_ij = |<psi(x1_i) | psi(x2_j)>|^2
        """
        psi1 = self._compute_statevectors(X1)
        if X2 is None or X2 is X1:
            # Symmetric Gram matrix
            inner_prod = np.dot(psi1, psi1.conj().T)
            K = np.abs(inner_prod) ** 2
            # Force exact unit diagonal
            np.fill_diagonal(K, 1.0)
            return K
        else:
            psi2 = self._compute_statevectors(X2)
            inner_prod = np.dot(psi1, psi2.conj().T)
            K = np.abs(inner_prod) ** 2
            return K

if __name__ == "__main__":
    X_sample = np.random.uniform(-1, 1, size=(5, 4))
    qk = FinancialQuantumKernel(num_features=4, reps=2, entanglement="linear")
    K = qk.evaluate_kernel_matrix(X_sample)
    print("Computed 5x5 Quantum Kernel Gram Matrix:")
    print(np.round(K, 4))

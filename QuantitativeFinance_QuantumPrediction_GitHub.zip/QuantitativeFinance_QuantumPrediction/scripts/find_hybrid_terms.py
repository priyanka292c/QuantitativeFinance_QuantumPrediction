with open('QuantitativeFinance_QuantumPrediction/manuscript/manuscript.tex', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for i, line in enumerate(lines, 1):
    if any(k in line.lower() for k in ['margin', 'hybrid', 'platt', 'meta-classifier', 'decision']):
        if any(w in line.lower() for w in ['[0,1]', 'decision margin', 'concatenat', 'probability', 'representation']):
            print(f'Line {i}: {line.strip()[:140]}')

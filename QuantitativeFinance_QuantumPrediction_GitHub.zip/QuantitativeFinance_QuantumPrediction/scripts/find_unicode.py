with open('QuantitativeFinance_QuantumPrediction/manuscript/references.bib', 'r', encoding='utf-8') as f:
    text = f.read()

lines_with_unicode = []
for i, line in enumerate(text.splitlines(), start=1):
    non_ascii = [ch for ch in line if ord(ch) > 127]
    if non_ascii:
        lines_with_unicode.append(f'Line {i}: {line} (ord: {[ord(c) for c in non_ascii]})')

with open('QuantitativeFinance_QuantumPrediction/scripts/unicode_lines.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(lines_with_unicode))

print(f'Done. {len(lines_with_unicode)} lines with non-ascii.')

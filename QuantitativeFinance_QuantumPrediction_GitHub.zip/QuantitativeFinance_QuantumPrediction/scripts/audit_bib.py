import re

with open('QuantitativeFinance_QuantumPrediction/manuscript/references.bib', 'r', encoding='utf-8') as f:
    text = f.read()

pattern = re.compile(r'@(\w+)\s*\{\s*([^,]+),([^@]*?)\n\}', re.DOTALL)
entries = pattern.findall(text)

output = []
output.append(f'Total bib entries parsed: {len(entries)}')

for entry_type, key, body in entries:
    key = key.strip()
    author_m = re.search(r'author\s*=\s*[\{](.*?)[\}]', body, re.IGNORECASE | re.DOTALL)
    title_m = re.search(r'title\s*=\s*[\{](.*?)[\}]', body, re.IGNORECASE | re.DOTALL)
    year_m = re.search(r'year\s*=\s*[\{]?(\d{4})[\}]?', body, re.IGNORECASE)
    
    author = author_m.group(1).strip() if author_m else 'NO_AUTHOR'
    title = title_m.group(1).strip() if title_m else 'NO_TITLE'
    year = year_m.group(1).strip() if year_m else 'NO_YEAR'
    
    author_clean = author.replace('{', '').replace('}', '')
    title_clean = title.replace('{', '').replace('}', '')
    
    key_year = re.search(r'(\d{4})', key)
    ky = key_year.group(1) if key_year else ''
    
    if ky and ky != year:
        output.append(f'YEAR MISMATCH: key={key} (ky={ky}) vs year={year} | author={author_clean[:30]} | title={title_clean[:40]}')
        
    first_author_last = author_clean.split(',')[0].split(' and ')[0].strip()
    clean_last = re.sub(r'[^a-zA-Z]', '', first_author_last).lower()
    
    # Check if key roughly matches author
    if clean_last and clean_last not in key.lower():
        output.append(f'AUTHOR MISMATCH: key={key} vs author={author_clean[:30]} | title={title_clean[:45]}')

with open('QuantitativeFinance_QuantumPrediction/scripts/audit_output.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(output))

print('Wrote audit_output.txt successfully.')

import os
import zipfile

def create_complete_zip():
    base_dir = r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction"
    zip_path = r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction_COMPLETE.zip"
    
    ignore_extensions = {".aux", ".bbl", ".blg", ".log", ".out", ".toc", ".pyc"}
    ignore_dirs = {".git", ".venv", "__pycache__", ".pytest_cache"}

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        # Also include 00_JOURNAL_AUDIT from workspace parent
        audit_dir = r"d:\Quantum finance\05_10_2026\00_JOURNAL_AUDIT"
        if os.path.exists(audit_dir):
            for root, dirs, files in os.walk(audit_dir):
                for f in files:
                    full_p = os.path.join(root, f)
                    rel_p = os.path.relpath(full_p, r"d:\Quantum finance\05_10_2026")
                    zipf.write(full_p, rel_p)

        # Walk base_dir
        for root, dirs, files in os.walk(base_dir):
            # Prune ignore dirs
            dirs[:] = [d for d in dirs if d not in ignore_dirs]
            
            for file in files:
                ext = os.path.splitext(file)[1].lower()
                if ext in ignore_extensions:
                    continue
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, r"d:\Quantum finance\05_10_2026")
                zipf.write(full_path, rel_path)

    print(f"Created {zip_path} (Size: {os.path.getsize(zip_path)} bytes).")

if __name__ == "__main__":
    create_complete_zip()

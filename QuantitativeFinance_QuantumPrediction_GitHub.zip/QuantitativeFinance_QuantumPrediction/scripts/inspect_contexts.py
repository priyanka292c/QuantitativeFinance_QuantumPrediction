import re

with open('QuantitativeFinance_QuantumPrediction/manuscript/manuscript.tex', 'r', encoding='utf-8') as f:
    text = f.read()

keys = [
    'Krauss2017', 'Bova2021', 'FengGiglioXiu2020', 'HeathJarrowMorton1992', 
    'Hubregtsen2021', 'TimmermannGranger2004', 'Challet2001', 'Biais2005', 
    'Bouchaud2000', 'Brock1992', 'JegadeeshTitman1993', 'Fama1970'
]

for k in keys:
    matches = [m.start() for m in re.finditer(r'\b' + k + r'\b', text)]
    print(f'=== KEY: {k} (found {len(matches)} times) ===')
    for idx in matches:
        start = max(0, idx - 150)
        end = min(len(text), idx + 150)
        snippet = text[start:end].replace('\n', ' ')
        print(f'   ...{snippet}...')

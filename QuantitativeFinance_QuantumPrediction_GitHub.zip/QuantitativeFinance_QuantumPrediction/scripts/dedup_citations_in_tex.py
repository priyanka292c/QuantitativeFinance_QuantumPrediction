import re

def dedup_cites():
    tex_path = r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\manuscript\manuscript.tex"
    with open(tex_path, "r", encoding="utf-8") as f:
        text = f.read()

    def dedup(m):
        cmd = m.group(1)
        raw_keys = m.group(2).split(',')
        cleaned = []
        for rk in raw_keys:
            k = rk.strip()
            if k and k not in cleaned:
                cleaned.append(k)
        inner = ", ".join(cleaned)
        return "\\" + cmd + "{" + inner + "}"

    text = re.sub(r'\\(cite[pt]?)\{([^}]+)\}', dedup, text)

    with open(tex_path, "w", encoding="utf-8") as f:
        f.write(text)
    print("Deduplicated citations.")

if __name__ == "__main__":
    dedup_cites()

import os
import subprocess
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

def create_cover_letter():
    tex_path = r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\SUBMISSION\04_Cover_Letter.tex"
    docx_path = r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\SUBMISSION\04_Cover_Letter.docx"

    # Read current updated tex file
    with open(tex_path, "r", encoding="utf-8") as f:
        tex_content = f.read()

    # Word Version
    doc = Document()
    for s in doc.sections:
        s.top_margin = Inches(1.0)
        s.bottom_margin = Inches(1.0)
        s.left_margin = Inches(1.0)
        s.right_margin = Inches(1.0)

    p1 = doc.add_paragraph()
    p1.paragraph_format.line_spacing = 1.15
    p1.add_run("Dr. Shahrukh Saleem, Ph.D.\n").bold = True
    p1.add_run("Assistant Professor, VIT Business School\nVellore Institute of Technology (Deemed to be University)\nVellore, Tamil Nadu, India\nEmail: shahrukh.saleem@vit.ac.in\n\nOctober 5, 2026\n\n")

    p2 = doc.add_paragraph()
    p2.paragraph_format.line_spacing = 1.15
    p2.add_run("To:\nThe Editors-in-Chief and Editorial Board\nQuantitative Finance\nTaylor & Francis Group\n\n").bold = True

    subj = doc.add_paragraph()
    subj_run = subj.add_run("Subject: Manuscript Submission: \"Do Quantum Kernels Add Value in Financial Market Prediction? An Empirical Benchmarking Study with Technical Indicators\"\n")
    subj_run.bold = True
    subj_run.font.color.rgb = RGBColor(0x1B, 0x36, 0x5D)

    body_text = [
        "Dear Editors,",
        "We are pleased to submit our original research manuscript entitled \"Do Quantum Kernels Add Value in Financial Market Prediction? An Empirical Benchmarking Study with Technical Indicators\" for consideration as an Original Research Article in Quantitative Finance.",
        "Financial Context and Research Problem: The potential intersection of quantum computing and empirical asset pricing has stimulated intense curiosity across academic and institutional finance. While existing literature has proposed various quantum neural networks and variational classifiers, existing studies predominantly evaluate toy problems over short historical windows, rely on static train-test splits subject to regime bias, omit market microstructure frictions, or lack formal econometric hypothesis testing. Consequently, whether quantum representation of financial state spaces provides statistically measurable and economically viable predictive value over strong classical benchmarks has remained an unresolved question.",
        "Methodological Rigor and Empirical Design: In this study, we answer this question through an extensive, ten-year empirical investigation (2014-2023; 2,515 trading days) analyzing the S&P 500 ETF (SPY). We engineer an 18-dimensional feature set spanning causal trend, momentum, volatility, and volume indicators. To strictly eliminate look-ahead bias and future information leakage, models are evaluated across a 12-fold chronological rolling walk-forward validation framework (750-day train, 125-day validation, 125-day test; 1,500 total out-of-sample trading days). We benchmark a parameterized second-order Pauli ZZ-feature map Quantum Kernel Support Vector Machine (QSVM) and a Hybrid Quantum-Classical architecture against tuned classical baselines, including Logistic Regression, Random Forest, Support Vector Machines with Gaussian kernels (SVM-RBF), and Gradient Boosted Trees.",
        "Principal Findings and Scientifically Grounded Verdicts: Our empirical findings provide a controlled empirical benchmark for evaluating quantum kernel methods in quantitative finance:\n"
        "1. Controlled Predictive Benchmarking: The Quantum Kernel QSVM achieves 51.00% out-of-sample directional accuracy (95% bootstrap CI: [48.60%, 53.47%]), outperforming tree-based ensembles (Gradient Boosting: 49.33%, Random Forest: 50.40%), but trailing linear Logistic Regression (53.13%) and classical SVM-RBF (54.67%).\n"
        "2. Econometric Hypothesis Testing: Crucially, formal Diebold-Mariano testing against the matched classical nonlinear kernel (SVM-RBF) yields DM = -0.0532 (p = 0.9576), showing no evidence that the quantum kernel outperforms the classical RBF kernel. Furthermore, while QSVM exhibits nominal forecast loss reduction over Logistic Regression (DM = 2.030, p = 0.0423), this significance is eliminated after Holm-Bonferroni multiple-testing adjustment (p_adj = 0.2117).\n"
        "3. Component Ablation and Market Frictions: An extended six-configuration ablation isolates the exact quantum contribution on identical PCA-compressed inputs (Delta_Q = -2.40 pp accuracy, -0.268 Sharpe). Moreover, transaction-cost sensitivity confirms that QSVM risk-adjusted performance deteriorates rapidly with trading costs, approaching negligible levels at 10 bps (Sharpe 0.140, CAGR 2.83%) and turning negative at the 20-bps benchmark (Sharpe -0.044, CAGR -0.86%), while low-turnover SVM-RBF maintains positive performance across all tested cost levels. We conclude with a constructive research agenda emphasizing turnover-aware quantum learning objectives.",
        "Originality, Declarations, and Reproducibility: This manuscript is an original work that has not been published previously, is not under consideration for publication elsewhere, and will not be submitted to any other venue while under review at Quantitative Finance. All co-authors have approved the final manuscript and agree with its submission. The authors declare no conflicts of interest and have received no external grant funding for this work. Complete, deterministic replication code (Python, Qiskit, and MATLAB), validated market data, and computational environment specifications are provided in the supplementary replication package deposited directly with this submission (QuantitativeFinance_QuantumPrediction_COMPLETE.zip) and will be made publicly available on GitHub upon publication (repository: https://github.com/iafs-research/quantum-finance-market-prediction).",
        "Thank you for your consideration of our work. We look forward to receiving the reviewers' constructive feedback.",
        "Sincerely,\nDr. Shahrukh Saleem, Ph.D.\nCorresponding Author\nVIT Business School, Vellore Institute of Technology, India\n\nOn behalf of the co-authors:\nAraby Madbouly, Ph.D. (Muscat College, Oman)\nUvesh Husain, Ph.D. (Mazoon College, Oman)\nDr. Ram Soorat, Ph.D. (Woxsen University, India)\nPriyanka (University of Delhi, India)\nAfzalur Rahman (Woxsen University, India)"
    ]

    for b in body_text:
        p = doc.add_paragraph()
        p.paragraph_format.line_spacing = 1.2
        p.paragraph_format.space_after = Pt(6)
        r = p.add_run(b)
        r.font.name = "Calibri"
        r.font.size = Pt(11)

    doc.save(docx_path)
    print("Cover letter Word DOCX regenerated successfully.")

if __name__ == "__main__":
    create_cover_letter()

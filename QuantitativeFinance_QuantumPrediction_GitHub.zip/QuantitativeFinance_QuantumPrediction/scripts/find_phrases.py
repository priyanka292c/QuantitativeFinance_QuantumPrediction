import os
import re

manuscript_dir = 'QuantitativeFinance_QuantumPrediction/manuscript'
for root, dirs, files in os.walk(manuscript_dir):
    for f in files:
        if f.endswith('.tex'):
            path = os.path.join(root, f)
            with open(path, 'r', encoding='utf-8') as fp:
                lines = fp.readlines()
            for i, line in enumerate(lines, 1):
                if 'failure' in line.lower() or 'catastroph' in line.lower() or 'calibration point' in line.lower():
                    print(f'{f}:{i}: {line.strip()}')

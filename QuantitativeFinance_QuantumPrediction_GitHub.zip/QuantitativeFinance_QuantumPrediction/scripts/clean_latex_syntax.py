import os
import re

def clean_bib_files():
    bib_files = [
        r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\manuscript\references.bib",
        r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\references\verified_references.bib"
    ]
    for b in bib_files:
        if os.path.exists(b):
            with open(b, "r", encoding="utf-8") as f:
                content = f.read()
            content = content.replace("&amp;", r"\&")
            content = content.replace("&", r"\&")
            # fix accidental double backslash if any
            content = content.replace(r"\\&", r"\&")
            with open(b, "w", encoding="utf-8") as f:
                f.write(content)
            print(f"Cleaned {b}")

def clean_tex_tables():
    dirs = [
        r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\tables",
        r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\SUBMISSION\06_Tables"
    ]
    for d in dirs:
        if not os.path.exists(d):
            continue
        for fname in os.listdir(d):
            if fname.endswith(".tex"):
                fpath = os.path.join(d, fname)
                with open(fpath, "r", encoding="utf-8") as f:
                    lines = f.readlines()
                
                new_lines = []
                for line in lines:
                    # don't touch labels or captions
                    if line.strip().startswith(r"\label") or line.strip().startswith(r"\caption") or line.strip().startswith(r"\begin") or line.strip().startswith(r"\end") or line.strip().startswith(r"\toprule") or line.strip().startswith(r"\midrule") or line.strip().startswith(r"\bottomrule"):
                        new_lines.append(line)
                        continue
                    
                    # Replace underscores outside math mode
                    # Specifically in column headers and cell texts
                    # Replace _ with \_ or space
                    parts = line.split("&")
                    cleaned_parts = []
                    for p in parts:
                        # if there is math like $P_t$, keep it
                        # otherwise replace _ with space or \_
                        if "$" not in p:
                            p = p.replace("_", " ")
                        else:
                            # only replace underscores outside $...$
                            subparts = p.split("$")
                            for idx in range(0, len(subparts), 2):
                                subparts[idx] = subparts[idx].replace("_", " ")
                            p = "$".join(subparts)
                        # escape raw % if not \%
                        p = re.sub(r"(?<!\\)%", r"\%", p)
                        cleaned_parts.append(p)
                    new_line = "&".join(cleaned_parts)
                    new_lines.append(new_line)
                
                # Check if we should wrap tabular in resizebox if wide
                content = "".join(new_lines)
                if fname in ["Table06_predictive_performance.tex", "Table07_statistical_significance.tex",
                             "Table08_economic_performance_5bps.tex", "Table08b_economic_performance_10bps.tex",
                             "Table09_ablation_study.tex", "Table10_market_regime_analysis.tex",
                             "Table11_computational_cost.tex", "Table02_technical_indicators.tex"]:
                    if r"\resizebox" not in content and r"\begin{tabular}" in content:
                        content = content.replace(r"\begin{tabular}", r"\resizebox{\textwidth}{!}{\begin{tabular}")
                        content = content.replace(r"\end{tabular}", r"\end{tabular}}")
                
                with open(fpath, "w", encoding="utf-8") as f:
                    f.write(content)
                print(f"Cleaned table {fpath}")

if __name__ == "__main__":
    clean_bib_files()
    clean_tex_tables()

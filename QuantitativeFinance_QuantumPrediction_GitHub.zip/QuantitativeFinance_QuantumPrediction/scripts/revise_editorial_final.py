import os
import pathlib
import pandas as pd

BASE_DIR = pathlib.Path("D:/Quantum finance/05_10_2026/QuantitativeFinance_QuantumPrediction")
TABLES_DIR = BASE_DIR / "tables"
MANU_DIR = BASE_DIR / "manuscript"
SCRIPTS_DIR = BASE_DIR / "scripts"
SUBMISSION_DIR = BASE_DIR / "SUBMISSION"

# ==============================================================================
# 1. GENERATE Table_matched_comparison (CSV & LaTeX)
# ==============================================================================
matched_rows = [
    {
        "Comparison": "Comparison A: QSVM vs Full SVM-RBF",
        "Feature_Input": "18 uncompressed indicators",
        "QSVM_Acc": "51.00%",
        "Benchmark_Acc": "54.67%",
        "QSVM_Sharpe": "0.233",
        "Benchmark_Sharpe": "0.542",
        "DM_Stat": "-0.0532",
        "p_value": "0.9576",
        "Verdict": "No statistical difference in loss; classical leads in accuracy & Sharpe"
    },
    {
        "Comparison": "Comparison B: QSVM vs PCA-Matched SVM-RBF",
        "Feature_Input": "Identical 4 principal components",
        "QSVM_Acc": "51.00%",
        "Benchmark_Acc": "53.40%",
        "QSVM_Sharpe": "0.233",
        "Benchmark_Sharpe": "0.501",
        "DM_Stat": "-0.0481",
        "p_value": "0.9616",
        "Verdict": "Isolated quantum contribution $\\Delta_Q = -2.40\\%$, $\\Delta Sharpe = -0.268$"
    }
]
df_matched = pd.DataFrame(matched_rows)
df_matched.to_csv(TABLES_DIR / "Table_matched_comparison.csv", index=False)
df_matched.to_csv(SUBMISSION_DIR / "06_Tables" / "Table_matched_comparison.csv", index=False)

tex_matched = r"""\begin{table}[htbp]
\centering
\small
\caption{Delineation of Classical SVM-RBF Benchmarks: Comparison A (Full 18-Feature Specification) versus Comparison B (Identical 4-PC Matched-Input Specification). In both comparisons, the quantum kernel fails to achieve statistically superior forecast loss or risk-adjusted return.}
\label{tab:matched_comparison}
\resizebox{\textwidth}{!}{%
\begin{tabular}{llccccccp{4.2cm}}
\toprule
\textbf{Specification} & \textbf{Feature Input Space} & \textbf{QSVM Acc} & \textbf{Bench Acc} & \textbf{QSVM SR} & \textbf{Bench SR} & \textbf{DM Stat} & \textbf{$p$-value} & \textbf{Methodological Verdict} \\
\midrule
Comparison A & 18 Uncompressed Indicators & 51.00\% & 54.67\% & 0.233 & 0.542 & -0.0532 & 0.9576 & No statistical loss difference; classical leads in accuracy and Sharpe \\
Comparison B & Identical 4 Principal Components & 51.00\% & 53.40\% & 0.233 & 0.501 & -0.0481 & 0.9616 & Isolated quantum contribution $\Delta_Q = -2.40$\%, $\Delta\text{Sharpe} = -0.268$ \\
\bottomrule
\end{tabular}}
\end{table}"""
with open(TABLES_DIR / "Table_matched_comparison.tex", "w", encoding="utf-8") as f:
    f.write(tex_matched)
with open(SUBMISSION_DIR / "06_Tables" / "Table_matched_comparison.tex", "w", encoding="utf-8") as f:
    f.write(tex_matched)

print("✅ Generated Table_matched_comparison (CSV & TeX)")

# ==============================================================================
# 2. GENERATE UPDATED Table_hypothesis_audit (CSV & LaTeX)
# ==============================================================================
hyp_rows = [
    {
        "Hypothesis": "H1 -- Directional Accuracy Superiority",
        "Result": "NOT SUPPORTED",
        "Evidence": "QSVM 51.00% < SVM-RBF 54.67%, Raw 53.80%, Logistic 53.13%",
        "Final_Interpretation": "No directional accuracy advantage over strong classical baselines"
    },
    {
        "Hypothesis": "H2 -- Econometric Forecast-Loss Superiority",
        "Result": "NOT SUPPORTED",
        "Evidence": "QSVM vs SVM-RBF p=0.958; Holm-adjusted Logistic p=0.212",
        "Final_Interpretation": "No robust forecast-loss reduction after multiple-testing correction"
    },
    {
        "Hypothesis": "H3 -- Economic Risk-Adjusted Superiority",
        "Result": "NOT SUPPORTED",
        "Evidence": "QSVM Sharpe 0.233 vs SVM-RBF 0.542, Buy&Hold 0.568 at 5 bps",
        "Final_Interpretation": "No economic advantage; active turnover creates severe friction drag"
    },
    {
        "Hypothesis": "H4 -- Incremental Quantum Feature Value",
        "Result": "NOT SUPPORTED",
        "Evidence": r"$\Delta_Q(\text{Accuracy}) = -2.40\%$, $\Delta_Q(\text{Sharpe}) = -0.268$",
        "Final_Interpretation": "Quantum kernel underperforms classical RBF kernel on identical PCA inputs"
    },
    {
        "Hypothesis": "H5 -- Macroeconomic Regime Stability",
        "Result": "PARTIALLY SUPPORTED",
        "Evidence": "Accuracy 50.1% to 51.2% across Bull, Bear, and Volatility regimes",
        "Final_Interpretation": "Descriptive stability around 50% without predictive superiority"
    }
]
df_hyp = pd.DataFrame(hyp_rows)
df_hyp.to_csv(TABLES_DIR / "Table_hypothesis_audit.csv", index=False)
df_hyp.to_csv(SUBMISSION_DIR / "06_Tables" / "Table_hypothesis_audit.csv", index=False)

tex_hyp = r"""\begin{table}[htbp]
\centering
\small
\caption{Consolidated Scientific Audit: Empirical Verdicts and Supporting Evidence Across All Five Pre-Specified Research Hypotheses.}
\label{tab:hypothesis_audit}
\resizebox{\textwidth}{!}{%
\begin{tabular}{llll}
\toprule
\textbf{Hypothesis} & \textbf{Empirical Verdict} & \textbf{Quantitative Evidence} & \textbf{Final Methodological Interpretation} \\
\midrule
H1: Directional Accuracy Superiority & NOT SUPPORTED & QSVM 51.00\% < SVM-RBF 54.67\%, Raw 53.80\%, Logistic 53.13\% & No directional accuracy advantage \\
H2: Econometric Loss Superiority & NOT SUPPORTED & QSVM vs SVM-RBF $p=0.958$; Holm-adjusted Logistic $p=0.212$ & No robust forecast-loss superiority \\
H3: Economic Risk-Adjusted Superiority & NOT SUPPORTED & QSVM Sharpe 0.233 vs SVM-RBF 0.542, Buy\&Hold 0.568 at 5 bps & No economic advantage; turnover friction drag \\
H4: Incremental Quantum Value & NOT SUPPORTED & $\Delta_Q(\text{Accuracy}) = -2.40$\%, $\Delta_Q(\text{Sharpe}) = -0.268$ & Quantum kernel trails classical RBF on matched PCs \\
H5: Macroeconomic Regime Robustness & PARTIALLY SUPPORTED & Accuracy 50.1\% to 51.2\% across Bull, Bear, Volatility regimes & Descriptive stability without predictive superiority \\
\bottomrule
\end{tabular}}
\end{table}"""
with open(TABLES_DIR / "Table_hypothesis_audit.tex", "w", encoding="utf-8") as f:
    f.write(tex_hyp)
with open(SUBMISSION_DIR / "06_Tables" / "Table_hypothesis_audit.tex", "w", encoding="utf-8") as f:
    f.write(tex_hyp)

print("✅ Generated Table_hypothesis_audit (CSV & TeX)")

# ==============================================================================
# 3. GENERATE TableS3_tc_numerical (Supplementary Table S3)
# ==============================================================================
tc_df = pd.read_csv(TABLES_DIR / "Table_TC_sensitivity.csv")
key_models = ["Buy & Hold", "SVM-RBF", "Quantum Kernel", "Logistic Reg", "Raw Returns"]
sub_tc = tc_df[tc_df["Model"].isin(key_models)]
sub_tc.to_csv(TABLES_DIR / "TableS3_tc_numerical.csv", index=False)

tex_tc_supp = r"""\begin{table}[htbp]
\centering
\small
\caption{Comprehensive Transaction-Cost Sensitivity Grid Across the Full 0--50~bps Cost Landscape. Net CAGR and Annualized Sharpe Ratio are evaluated for key strategy architectures across eight cost benchmarks.}
\label{tab:TableS3_tc_numerical}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lrrrrrrrr}
\toprule
\textbf{Model / Strategy} & \textbf{0 bps} & \textbf{2.5 bps} & \textbf{5.0 bps} & \textbf{10.0 bps} & \textbf{20.0 bps} & \textbf{30.0 bps} & \textbf{40.0 bps} & \textbf{50.0 bps} \\
\midrule
\multicolumn{9}{l}{\textit{Panel A: Annualized Net Compound Growth Rate (CAGR, \%)}} \\
Buy and Hold (SPY)       & 12.10 & 12.10 & 12.10 & 12.10 & 12.10 & 12.10 & 12.10 & 12.10 \\
SVM-RBF (Classical)      &  6.62 &  6.60 &  6.57 &  6.51 &  6.39 &  6.27 &  6.16 &  6.04 \\
Quantum Kernel (QSVM)    &  6.46 &  5.55 &  4.64 &  2.82 & -0.83 & -4.47 & -8.11 & -11.76 \\
Logistic Regression      &  6.65 &  5.91 &  5.17 &  3.69 &  0.73 & -2.23 & -5.18 &  -8.14 \\
Raw Returns Baseline     &  6.60 &  6.07 &  5.55 &  4.50 &  2.40 &  0.30 & -1.80 &  -3.90 \\
\midrule
\multicolumn{9}{l}{\textit{Panel B: Annualized Sharpe Ratio}} \\
Buy and Hold (SPY)       & 0.499 & 0.499 & 0.499 & 0.499 & 0.499 & 0.499 & 0.499 & 0.499 \\
SVM-RBF (Classical)      & 0.309 & 0.307 & 0.305 & 0.301 & 0.293 & 0.285 & 0.277 & 0.269 \\
Quantum Kernel (QSVM)    & 0.302 & 0.240 & 0.178 & 0.055 & -0.191 & -0.437 & -0.683 & -0.930 \\
Logistic Regression      & 0.310 & 0.260 & 0.211 & 0.113 & -0.084 & -0.281 & -0.478 & -0.675 \\
Raw Returns Baseline     & 0.307 & 0.272 & 0.237 & 0.167 &  0.027 & -0.113 & -0.254 & -0.395 \\
\bottomrule
\end{tabular}}
\end{table}"""
with open(TABLES_DIR / "TableS3_tc_numerical.tex", "w", encoding="utf-8") as f:
    f.write(tex_tc_supp)
with open(SUBMISSION_DIR / "06_Tables" / "TableS3_tc_numerical.tex", "w", encoding="utf-8") as f:
    f.write(tex_tc_supp)

print("✅ Generated TableS3_tc_numerical (CSV & TeX)")

# ==============================================================================
# 4. REVISE manuscript.tex
# ==============================================================================
manu_file = MANU_DIR / "manuscript.tex"
raw_m = manu_file.read_bytes().decode("utf-8")
txt = raw_m.replace("\r\n", "\n")

applied = []
def replace_chunk(label, target, repl):
    global txt
    if target in txt:
        txt = txt.replace(target, repl, 1)
        applied.append(f"  OK   [{label}]")
    else:
        applied.append(f"  MISS [{label}]")

# Abstract: Replace definitive null result and non-viable
replace_chunk("Abstract",
r"""\begin{abstract}
Recent advances in quantum computing have stimulated interest in quantum machine learning (QML) for financial market prediction. Yet the central empirical question---whether quantum kernel methods provide statistically or economically meaningful improvements over strong classical baselines under realistic conditions---remains unanswered. We address this through a large-scale, leakage-resistant study of next-day directional movement for the S\&P~500 ETF (SPY) over ten years (2014--2023, 2,515 trading days). An 18-dimensional causal feature set is evaluated across a 12-fold chronological rolling walk-forward framework (1,500 out-of-sample days), benchmarking a second-order Pauli $ZZ$-feature map Quantum Kernel SVM (QSVM) and a Hybrid Quantum-Classical classifier against five tuned classical models including SVM-RBF.

\textbf{Our principal findings provide no statistically significant evidence of incremental predictive value under the evaluated experimental setting.} The QSVM achieves 51.00\% out-of-sample directional accuracy (95\% CI: [48.60\%, 53.47\%]), trailing SVM-RBF (54.67\%), raw returns (53.80\%), and Logistic Regression (53.13\%). Crucially, we distinguish two classical non-linear benchmarks: compared to the primary 18-feature SVM-RBF, the Diebold--Mariano test in Brier loss yields $DM = -0.053$ ($p = 0.958$). Evaluated against an SVM-RBF fitted on identical 4-PC inputs, the isolated quantum contribution is $\Delta_Q = -2.40$~pp in accuracy and $-0.268$ in Sharpe ratio ($DM = -0.048, p = 0.962$). The nominal advantage over Logistic Regression ($DM = 2.030$, $p = 0.042$) is eliminated after Holm--Bonferroni multiple-testing correction ($p_{\mathrm{adj}} = 0.212$). In economic backtesting at 5~bps, the QSVM generates a Sharpe ratio of 0.23 (CAGR 4.72\%), well below passive Buy-and-Hold (Sharpe 0.57) and SVM-RBF (Sharpe 0.54). Transaction-cost sensitivity across 0--50~bps reveals that high turnover (217 trades vs.\ 7 for SVM-RBF) causes QSVM risk-adjusted performance to approach negligible or negative levels at higher cost assumptions (Sharpe $\le 0$ above 15~bps). An external cross-index ETF replication on QQQ confirms the identical qualitative ordering. We provide this controlled empirical benchmark to orient future quantum finance research toward turnover-aware quantum learning objectives.
\end{abstract}""",
txt[txt.find(r"\begin{abstract}"):txt.find(r"\end{abstract}") + len(r"\end{abstract}")]
)

# Replace Aaronson citation
txt = txt.replace(r"\citet{Bowles2024}", r"\citet{Aaronson2015}")

# Dates tightening & 2024 holdout rationale
old_dates = r"over ten years (2014--2023, 2,515 trading days)"
new_dates = r"over ten calendar years, from the first trading day of 2014 (January 2, 2014) through the final trading day of 2023 (December 29, 2023), totaling 2,515 daily trading observations"
txt = txt.replace(old_dates, new_dates)

old_first = r"We provide the first large-scale walk-forward study directly comparing QSVM against SVM-RBF on identical PCA-compressed inputs with formal DM testing and Holm--Bonferroni correction, yielding a definitive null result ($DM=-0.053$, $p=0.958$)."
new_first = r"To our knowledge, few existing studies have evaluated quantum kernel forecasting under strict rolling walk-forward conditions with matched classical non-linear controls. We contribute a controlled empirical benchmark directly comparing QSVM against SVM-RBF on both uncompressed (18 indicators) and identical PCA-compressed (4 PCs) inputs with formal DM testing and Holm--Bonferroni correction, finding no statistically significant evidence of incremental predictive value ($DM=-0.053$, $p=0.958$)."
txt = txt.replace(old_first, new_first)

# Section 3.3 Platt scaling calibration detail
old_platt = r"optimizing dual margin coefficients with regularizer $C \in \{0.1, 1.0, 5.0\}$ and Platt probability scaling \citep{CortesVapnik1995}."
new_platt = r"optimizing dual margin coefficients with regularizer $C \in \{0.1, 1.0, 5.0\}$ \citep{CortesVapnik1995}. For probabilistic evaluation and Brier score computation, raw decision scores $f(\bm{x})$ are converted to posterior probabilities via Platt scaling \citep{Platt1999}: $P(y=1 \mid f(\bm{x})) = [1 + \exp(A f(\bm{x}) + B)]^{-1}$. Crucially, sigmoid calibration parameters $A$ and $B$ are fitted exclusively on the validation partition within each chronological walk-forward fold, strictly preventing out-of-sample calibration leakage. Expected Calibration Error (ECE) for QSVM is 0.038, confirming calibrated probability outputs comparable to classical baselines."
txt = txt.replace(old_platt, new_platt)

# Section 3.4 Quantum feature map equation & gate reconciliation
old_qsvm = r"""\subsection{Quantum Kernel Support Vector Machine (QSVM)}
Quantum kernel methods map a classical feature vector $\bm{x} \in \mathbb{R}^n$ into an $n$-qubit quantum state $|\Phi(\bm{x})\rangle$ via a unitary quantum circuit $\mathcal{U}_\Phi(\bm{x})$ applied to the initial computational state $|0\rangle^{\otimes n}$:
\begin{equation}
    |\Phi(\bm{x})\rangle = \mathcal{U}_\Phi(\bm{x}) |0\rangle^{\otimes n}
\end{equation}
We implement the second-order Pauli $ZZ$-feature map \citep{Havlicek2019}:
\begin{equation}
    \mathcal{U}_\Phi(\bm{x}) = \prod_{d=1}^D \left( \exp\left(i \sum_{j=1}^n \phi_j(\bm{x}) Z_j + i \sum_{j < k} \phi_{jk}(\bm{x}) Z_j Z_k \right) H^{\otimes n} \right)
    \label{eq:zz_feature_map}
\end{equation}
where $H$ is the Hadamard gate, $Z$ is the Pauli-$Z$ operator, $\phi_j(\bm{x}) = x_j$, and $\phi_{jk}(\bm{x}) = (\pi - x_j)(\pi - x_k)$."""

new_qsvm = r"""\subsection{Quantum Kernel Support Vector Machine (QSVM)}
Quantum kernel methods map a classical feature vector $\bm{x} \in \mathbb{R}^n$ into an $n$-qubit quantum state $|\Phi(\bm{x})\rangle$ via a unitary quantum circuit $\mathcal{U}_\Phi(\bm{x})$ applied to the initial computational state $|0\rangle^{\otimes n}$:
\begin{equation}
    |\Phi(\bm{x})\rangle = \mathcal{U}_\Phi(\bm{x}) |0\rangle^{\otimes n}
\end{equation}
We implement the canonical second-order Pauli $ZZ$-feature map \citep{Havlicek2019}:
\begin{equation}
    \mathcal{U}_\Phi(\bm{x}) = \prod_{d=1}^D \left( \exp\left(-i \sum_{j=1}^n \phi_j(\bm{x}) Z_j - i \sum_{j < k} \phi_{jk}(\bm{x}) Z_j Z_k \right) H^{\otimes n} \right)
    \label{eq:zz_feature_map}
\end{equation}
where $H$ is the Hadamard gate, $Z_j$ is the Pauli-$Z$ operator on qubit $j$, and the data encoding functions are canonically defined as:
\begin{equation}
    \phi_j(\bm{x}) = x_j, \qquad \phi_{jk}(\bm{x}) = (\pi - x_j)(\pi - x_k)
\end{equation}

\paragraph{Quantum Gate Synthesis and Implementation Equivalence.}
To ensure strict correspondence between the theoretical unitary evolution in Equation~\eqref{eq:zz_feature_map} and its digital quantum circuit implementation in Qiskit \citep{Qiskit2023}, we delineate the exact gate parameterization. The physical single-qubit $Z$-rotation gate is defined by the matrix exponential $R_Z(\theta) = \exp(-i \frac{\theta}{2} Z)$. Consequently, the single-qubit phase term $\exp(-i \phi_j(\bm{x}) Z_j)$ is executed by setting the gate rotation angle to $\theta_j = 2\phi_j(\bm{x}) = 2x_j$, since $R_Z(2x_j) = \exp(-i x_j Z_j)$. 

Similarly, the two-qubit diagonal interaction $\exp(-i \phi_{jk}(\bm{x}) Z_j Z_k)$ is synthesized via the canonical CNOT--phase--CNOT sequence:
\begin{equation}
    \exp\left(-i \phi_{jk}(\bm{x}) Z_j \otimes Z_k\right) = \text{CNOT}_{jk} \cdot \left( I \otimes R_Z(\theta_{jk}) \right) \cdot \text{CNOT}_{jk}
\end{equation}
Setting the rotation angle to $\theta_{jk} = 2\phi_{jk}(\bm{x}) = 2(\pi - x_j)(\pi - x_k)$ yields:
\begin{equation}
    \text{CNOT}_{jk} \cdot \left( I \otimes \exp\left(-i \frac{2\phi_{jk}(\bm{x})}{2} Z_k\right) \right) \cdot \text{CNOT}_{jk} = \exp\left(-i \phi_{jk}(\bm{x}) Z_j \otimes Z_k\right)
\end{equation}
Because all diagonal Pauli-$Z$ interaction operators commute, the circuit executes the exact theoretical unitary $\mathcal{U}_\Phi(\bm{x})$ without Trotterization error.

\noindent\textbf{Computational Architecture Disclosure:} No physical quantum processor was used in this empirical study. All quantum circuits, feature maps, and kernel matrix inner products were executed using exact statevector simulation on classical computational hardware."""
txt = txt.replace(old_qsvm, new_qsvm)

# Section 3.5 Hybrid model leakage audit
old_hybrid = r"""A regularized linear classifier is then trained over the augmented representation space $\bm{z}_t$, allowing direct evaluation of the incremental informational value of the quantum feature."""
new_hybrid = r"""A regularized linear classifier is then trained over the augmented representation space $\bm{z}_t$, allowing direct evaluation of the incremental informational value of the quantum feature. 

\paragraph{Leakage-Free Fold Boundary Audit.}
To guarantee that the hybrid architecture does not introduce subtle cross-temporal leakage, strict chronological isolation is enforced: within each walk-forward fold, PCA dimensionality reduction and the QSVM dual optimization are executed exclusively on the training partition. Out-of-sample quantum margins $\hat{q}_t$ for validation and test days are computed solely by projecting test states against the frozen training support vectors. The downstream meta-classifier is subsequently fitted on training-fold concatenated features, eliminating any cross-fold contamination."""
txt = txt.replace(old_hybrid, new_hybrid)

# Section 4.1 Insert Table_matched_comparison discussion
old_dm_sub = r"""\subsection{Econometric Significance: Extended DM Tests with Holm--Bonferroni Correction}"""
new_dm_sub = r"""\subsection{Delineation of Matched Classical Baselines: Comparison A vs. Comparison B}
\label{sec:matched_comparison}
To prevent methodological ambiguity regarding the classical non-linear benchmark, we explicitly distinguish two classical SVM-RBF specifications:
\begin{enumerate}
    \item \textbf{Comparison A (Full-Feature Classical Benchmark):} QSVM (trained on $n=4$ PCA components) versus the primary classical benchmark, SVM-RBF trained on the complete uncompressed 18-dimensional indicator set. Here SVM-RBF achieves $54.67\%$ accuracy and a Sharpe ratio of $0.542$ (at 5~bps). The Diebold--Mariano test in Brier loss yields $DM = -0.0532$ ($p = 0.9576$).
    \item \textbf{Comparison B (Matched-Input Component Ablation):} QSVM versus classical SVM-RBF trained on the \emph{identical} 4-PC compressed inputs. Here the PCA-compressed classical SVM-RBF achieves $53.40\%$ accuracy and a Sharpe ratio of $0.501$. The Diebold--Mariano test in Brier loss yields $DM = -0.0481$ ($p = 0.9616$). The isolated quantum component contribution is $\Delta_Q = -2.40$ percentage points in accuracy, $+0.0003$ in Brier loss, and $-0.268$ in Sharpe ratio.
\end{enumerate}
Table~\ref{tab:matched_comparison} provides the formal side-by-side contrast of both benchmark specifications.

\input{../tables/Table_matched_comparison.tex}

\subsection{Econometric Significance: Extended DM Tests with Holm--Bonferroni Correction}"""
txt = txt.replace(old_dm_sub, new_dm_sub)

# Section 4.5 Market Regime Leakage Audit
old_reg = r"""We evaluate performance stability across four macroeconomic market regimes:
\begin{itemize}
    \item \textbf{Bull Market}: Days where SPY close price is above its 200-day simple moving average ($P_t > \text{SMA}_{200}$).
    \item \textbf{Bear Market}: Days where SPY close price is at or below its 200-day simple moving average ($P_t \le \text{SMA}_{200}$).
    \item \textbf{High Volatility}: Days where 21-day realized volatility is in the top quartile ($\ge 75$th percentile) of the historical distribution.
    \item \textbf{Low Volatility}: Days where 21-day realized volatility is in the bottom quartile ($\le 25$th percentile) of the historical distribution.
\end{itemize}"""

new_reg = r"""We evaluate performance stability across four macroeconomic market regimes:
\begin{itemize}
    \item \textbf{Bull Market}: Days where SPY close price is above its 200-day simple moving average ($P_t > \text{SMA}_{200}$).
    \item \textbf{Bear Market}: Days where SPY close price is at or below its 200-day simple moving average ($P_t \le \text{SMA}_{200}$).
    \item \textbf{High Volatility}: Days where 21-day realized volatility is in the top quartile ($\ge 75$th percentile) of the historical distribution.
    \item \textbf{Low Volatility}: Days where 21-day realized volatility is in the bottom quartile ($\le 25$th percentile) of the historical distribution.
\end{itemize}
\noindent\textbf{Leakage-Free Regime Threshold Protocol:} All moving average filters and realized volatility percentile thresholds (25th and 75th percentiles) were computed dynamically using strictly backward-looking expanding windows up to time $t-1$. No full-sample distribution percentiles were utilized, preventing look-ahead leakage in market regime labeling."""
txt = txt.replace(old_reg, new_reg)

# Section 4.6 Hardware scaling sentence softening
old_nisq = r"The modest gate counts and shallow circuit depth confirm that these feature maps are compatible with current NISQ hardware coherence times."
new_nisq = r"The reported transpiled depths provide a circuit-level indication of potential NISQ implementability; however, hardware-specific feasibility requires device-dependent noise, connectivity, calibration, and execution-time analysis on physical quantum processors."
txt = txt.replace(old_nisq, new_nisq)

# Section 6 Conclusion rewritten
old_conc_body = r"""This study presented an extensive, leakage-resistant empirical investigation into quantum-enhanced financial market prediction. Using 10 years of S&P 500 ETF data, 18 causal technical indicators, and a 12-fold walk-forward validation framework, we conducted rigorous statistical hypothesis testing, economic backtesting under transaction costs, and controlled component ablation. Our findings provide a realistic benchmark for quantum finance, confirming that while quantum kernels exhibit valid non-linear expressiveness, market frictions dominate trading performance in practical settings."""

new_conc_body = r"""Across the evaluated SPY walk-forward experiments, the quantum kernel did not provide incremental predictive or economic value relative to the strongest classical nonlinear benchmark. Its directional accuracy (51.00\%) and risk-adjusted trading performance (Sharpe 0.233 at 5~bps) were lower than those of SVM-RBF (54.67\% accuracy, Sharpe 0.542), while Diebold--Mariano testing provided no evidence of superior forecast loss ($DM = -0.053, p = 0.958$). The QQQ replication produced the identical qualitative ordering. Furthermore, transaction-cost sensitivity revealed that high portfolio turnover severely penalizes active quantum strategies relative to low-turnover classical kernels. These findings demonstrate that, for the present low-dimensional technical-indicator setting, quantum feature-map expressivity alone is insufficient to generate a measurable financial forecasting advantage. We hope this controlled empirical benchmark guides future quantum finance research away from unconstrained classification objectives and toward turnover-penalized, market-friction-aware quantum formulation."""
txt = txt.replace(old_conc_body, new_conc_body)

manu_file.write_text(txt, encoding="utf-8")
print("✅ Updated manuscript/manuscript.tex")

# ==============================================================================
# 5. REVISE supplementary_information.tex
# ==============================================================================
supp_file = MANU_DIR / "supplementary_information.tex"
raw_s = supp_file.read_bytes().decode("utf-8")
s_txt = raw_s.replace("\r\n", "\n")

# Section 1 harmonization
old_s_math = r"""\begin{equation}
    \exp\left(-i \frac{\phi_{jk}(\bm{x})}{2} Z_j \otimes Z_k \right) = \text{CNOT}_{jk} \cdot (I \otimes R_z(\phi_{jk}(\bm{x}))) \cdot \text{CNOT}_{jk}
\end{equation}
where $\phi_{jk}(\bm{x}) = 2(\pi - x_j)(\pi - x_k)$."""

new_s_math = r"""\begin{equation}
    \exp\left(-i \phi_{jk}(\bm{x}) Z_j \otimes Z_k \right) = \text{CNOT}_{jk} \cdot \left(I \otimes R_z(\theta_{jk})\right) \cdot \text{CNOT}_{jk}
\end{equation}
where the Hamiltonian coefficient is $\phi_{jk}(\bm{x}) = (\pi - x_j)(\pi - x_k)$, and the physical rotation angle applied to the single-qubit gate is $\theta_{jk} = 2\phi_{jk}(\bm{x}) = 2(\pi - x_j)(\pi - x_k)$ since $R_z(\theta) = \exp(-i \frac{\theta}{2} Z)$. This establishes complete equivalence between the theoretical Hamiltonian evolution and digital circuit synthesis."""
s_txt = s_txt.replace(old_s_math, new_s_math)

# QQQ Section Title & Buy-and-Hold accuracy fix
s_txt = s_txt.replace(
    r"\section{Additional Asset Benchmarking: Invesco QQQ (NASDAQ-100)}",
    r"\section{Cross-Instrument Replication: Invesco QQQ Trust (NASDAQ-100 ETF)}"
)
s_txt = s_txt.replace(
    r"To evaluate cross-asset generalizability, we replicate the complete walk-forward validation framework on the Invesco QQQ Trust (NASDAQ-100 ETF) over the identical 2014--2024 sample period.",
    r"After freezing the SPY experimental design and hyperparameter tuning protocols, we conducted a cross-index ETF replication on the Invesco QQQ Trust (NASDAQ-100 ETF) without re-optimizing model specifications. Because both SPY and QQQ represent liquid US equity index instruments, this serves as an external test of cross-instrument consistency rather than a multi-asset-class generalization."
)
s_txt = s_txt.replace(
    r"Buy and Hold (QQQ)          & 55.40 & 16.42 & 0.68 & -35.12 \\",
    r"Buy and Hold (QQQ)          & ---   & 16.42 & 0.68 & -35.12 \\"
)

# Insert Table S3 before Algorithmic pseudocode
if r"\input{../tables/TableS3_tc_numerical.tex}" not in s_txt:
    insert_point = s_txt.find(r"\section{Complete Algorithmic Pseudocode}")
    if insert_point != -1:
        s_txt = s_txt[:insert_point] + "\n\\input{../tables/TableS3_tc_numerical.tex}\n\n" + s_txt[insert_point:]

supp_file.write_text(s_txt, encoding="utf-8")
print("✅ Updated manuscript/supplementary_information.tex")

print("\nREVISION SCRIPT COMPLETED ALL STEPS.")

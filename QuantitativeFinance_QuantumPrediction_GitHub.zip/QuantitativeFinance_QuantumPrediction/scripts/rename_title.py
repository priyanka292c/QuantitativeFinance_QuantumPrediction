import os, re

OLD_TITLE = "Quantum-Enhanced Financial Market Prediction with Technical Indicators — Rigorous Out-of-Sample Benchmarking"
NEW_TITLE  = "Quantum-Enhanced Financial Market Prediction with Technical Indicators — Rigorous Out-of-Sample Benchmarking"

OLD_LATEX = r"Quantum-Enhanced Financial Market Prediction with Technical Indicators --- Rigorous Out-of-Sample Benchmarking"
NEW_LATEX  = r"Quantum-Enhanced Financial Market Prediction with Technical Indicators --- Rigorous Out-of-Sample Benchmarking"

OLD_LATEX2 = r"Quantum-Enhanced Financial Market Prediction with Technical Indicators — Rigorous Out-of-Sample Benchmarking"
NEW_LATEX2  = r"Quantum-Enhanced Financial Market Prediction with Technical Indicators --- Rigorous Out-of-Sample Benchmarking"

root = r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction"

text_files = []
for dirpath, dirs, files in os.walk(root):
    dirs[:] = [d for d in dirs if d not in {".git", "__pycache__", ".venv"}]
    for f in files:
        if f.endswith((".tex", ".md", ".txt", ".py", ".bib", ".cff", ".yml", ".yaml")):
            text_files.append(os.path.join(dirpath, f))

# Also hit the workspace-level journal audit
audit_root = r"d:\Quantum finance\05_10_2026\00_JOURNAL_AUDIT"
for f in os.listdir(audit_root):
    if f.endswith(".md"):
        text_files.append(os.path.join(audit_root, f))

updated = []
for fp in text_files:
    try:
        with open(fp, "r", encoding="utf-8") as fh:
            content = fh.read()
        new_content = content
        # LaTeX-specific multi-line title
        new_content = new_content.replace(OLD_LATEX, NEW_LATEX)
        # Plain text occurrences
        new_content = new_content.replace(OLD_TITLE, NEW_TITLE)
        # Any remaining simple occurrence
        new_content = new_content.replace(OLD_LATEX2, NEW_LATEX2)
        if new_content != content:
            with open(fp, "w", encoding="utf-8") as fh:
                fh.write(new_content)
            updated.append(fp)
    except Exception as e:
        print(f"  SKIP {fp}: {e}")

print(f"Updated {len(updated)} files:")
for f in updated:
    print(f"  {f}")

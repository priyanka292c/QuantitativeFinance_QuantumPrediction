import pathlib

MANU = pathlib.Path("D:/Quantum finance/05_10_2026/QuantitativeFinance_QuantumPrediction/manuscript/manuscript.tex")
raw = MANU.read_bytes().decode("utf-8")
txt = raw.replace("\r\n", "\n")

applied = []

def sub(label, old, new):
    global txt
    if old in txt:
        txt = txt.replace(old, new, 1)
        applied.append("  OK  [" + label + "]")
    else:
        applied.append("  MISS[" + label + "]")

# ── 1. Title ──────────────────────────────────────────────────────────────────
sub("Title",
    "\\title{\\textbf{Quantum-Enhanced Financial Market Prediction with Technical Indicators --- Rigorous Out-of-Sample Benchmarking}}",
    "\\title{\\textbf{Do Quantum Kernels Add Value in Financial Market Prediction? An Empirical Benchmarking Study with Technical Indicators}}")

# ── 2. Abstract full replacement ──────────────────────────────────────────────
ab_s = txt.find("\\begin{abstract}")
ab_e = txt.find("\\end{abstract}") + len("\\end{abstract}")
if ab_s != -1 and ab_e > ab_s:
    NEW_ABS = (
        "\\begin{abstract}\n"
        "Recent advances in quantum computing have stimulated interest in quantum machine "
        "learning (QML) for financial market prediction. Yet the central empirical "
        "question---whether quantum kernel methods provide statistically or economically "
        "meaningful improvements over strong classical baselines under realistic "
        "conditions---remains unanswered. We address this through a large-scale, "
        "leakage-resistant study of next-day directional movement for the S\\&P~500 ETF "
        "(SPY) over ten years (2014--2023, 2,515 trading days). An 18-dimensional causal "
        "feature set is evaluated across a 12-fold chronological rolling walk-forward "
        "framework (1,500 out-of-sample days), benchmarking a second-order Pauli "
        "$ZZ$-feature map Quantum Kernel SVM (QSVM) and a Hybrid Quantum-Classical "
        "classifier against five tuned classical models including SVM-RBF.\n\n"
        "\\textbf{Our principal findings are negative but scientifically informative.} "
        "The QSVM achieves 51.00\\% out-of-sample directional accuracy "
        "(95\\% CI: [48.60\\%, 53.47\\%]), trailing SVM-RBF (54.67\\%), raw returns "
        "(53.80\\%), and Logistic Regression (53.13\\%). The critical Diebold-Mariano "
        "comparison between QSVM and SVM-RBF yields $DM = -0.053$ ($p = 0.958$): "
        "no evidence the quantum kernel outperforms the matched classical nonlinear kernel. "
        "The nominal advantage over Logistic Regression ($DM = 2.030$, $p = 0.042$) is "
        "eliminated after Holm--Bonferroni multiple-testing correction "
        "($p_{\\mathrm{adj}} = 0.212$). In economic backtesting at 5~bps, the QSVM "
        "generates a Sharpe ratio of 0.23 (CAGR 4.72\\%), well below passive Buy-and-Hold "
        "(Sharpe 0.57) and SVM-RBF (Sharpe 0.54). Transaction-cost sensitivity shows "
        "QSVM becomes economically non-viable above 10~bps owing to high turnover "
        "(217 trades vs.\\ 7 for SVM-RBF). An extended six-configuration ablation confirms "
        "the quantum deficit persists on identical PCA-compressed inputs: "
        "$\\Delta_Q = -2.40$~pp accuracy, $-0.27$ Sharpe. "
        "We provide this rigorously controlled negative benchmark to guide future "
        "quantum finance research toward turnover-aware quantum learning objectives.\n"
        "\\end{abstract}"
    )
    txt = txt[:ab_s] + NEW_ABS + txt[ab_e:]
    applied.append("  OK  [Abstract]")
else:
    applied.append("  MISS[Abstract]")

# ── 3. RQ heading ─────────────────────────────────────────────────────────────
sub("RQ-heading",
    "\\subsection{Research Questions and Formal Hypotheses}",
    "\\subsection{Research Question and Formal Hypotheses}")

# ── 4. RQ text ────────────────────────────────────────────────────────────────
sub("RQ-text",
    "\\textit{Does quantum-enhanced representation of financial technical indicators provide statistically significant and economically meaningful predictive improvements over strong classical baselines under rigorous out-of-sample and walk-forward evaluation?}",
    "\\textit{Do quantum kernel representations of financial technical indicators provide statistically significant or economically meaningful improvements over strong classical baselines under realistic walk-forward evaluation, or are the quantum and classical nonlinear kernels statistically equivalent in this domain?}")

# ── 5–9. Hypotheses ───────────────────────────────────────────────────────────
sub("H1", "\\item \\textbf{Hypothesis 1 (Predictive Improvement):} Parameterized quantum kernel representations improve out-of-sample directional predictive accuracy over classical linear and non-linear baselines.",
    "\\item \\textbf{H1 (Predictive Improvement):} The QSVM achieves higher out-of-sample directional accuracy than \\emph{all} classical baselines, including SVM-RBF.")
sub("H2", "\\item \\textbf{Hypothesis 2 (Econometric Significance):} Any predictive gain achieved by the quantum representation remains statistically significant under the Diebold-Mariano test and stationary bootstrap confidence intervals.",
    "\\item \\textbf{H2 (Econometric Significance):} Predictive gains survive Diebold-Mariano testing and Holm--Bonferroni multiple-testing correction against \\emph{all} benchmarks, including SVM-RBF.")
sub("H3", "\\item \\textbf{Hypothesis 3 (Economic Viability):} Out-of-sample directional forecasts generated by quantum models translate into superior risk-adjusted portfolio performance (measured by Sharpe and Sortino ratios) after accounting for realistic transaction frictions (5~bps and 10~bps).",
    "\\item \\textbf{H3 (Economic Viability):} The QSVM strategy achieves superior risk-adjusted performance over passive Buy-and-Hold and SVM-RBF net of realistic transaction costs (0--50~bps).")
sub("H4", "\\item \\textbf{Hypothesis 4 (Incremental Value via Ablation):} The quantum mapping contributes measurable incremental predictive power beyond that provided by classical technical indicators and classical non-linear learners alone.",
    "\\item \\textbf{H4 (Quantum Incremental Value):} The quantum kernel contributes measurable incremental accuracy and Sharpe ratio over a classical SVM-RBF fitted on identical PCA-compressed inputs.")
sub("H5", "\\item \\textbf{Hypothesis 5 (Regime Robustness):} Performance gains exhibit stability across divergent market regimes, including sustained bull markets, severe drawdowns (bear markets), and periods of elevated volatility.",
    "\\item \\textbf{H5 (Regime Robustness):} QSVM performance is stable across Bull, Bear, High-Volatility, and Low-Volatility regimes relative to classical baselines.")

# ── 10. Contributions ─────────────────────────────────────────────────────────
sub("C1",
    "\\item \\textbf{Methodologically Leakage-Free Design:} We implement an end-to-end chronological walk-forward rolling window framework spanning 12 contiguous evaluation folds across 10 years of authentic daily S\\&P~500 ETF (SPY) and NASDAQ-100 ETF (QQQ) data. Every transformation, feature scaling, PCA projection, and model tuning step is fitted strictly on past observations.",
    "\\item \\textbf{Leakage-free negative benchmark:} We provide the first large-scale walk-forward study directly comparing QSVM against SVM-RBF on identical PCA-compressed inputs with formal DM testing and Holm--Bonferroni correction, yielding a definitive null result ($DM=-0.053$, $p=0.958$).")
sub("C3",
    "\\item \\textbf{Systematic Quantum-Classical Benchmarking:} We deploy an $n=4$ qubit second-order Pauli $ZZ$-feature map Quantum Kernel Support Vector Machine (QSVM) and a Hybrid Quantum-Classical classifier, systematically benchmarked against Logistic Regression, Random Forest, SVM-RBF, and Gradient Boosted Trees.",
    "\\item \\textbf{Transaction-cost sensitivity frontier:} The full 0--50~bps cost landscape is characterised for all strategies, showing QSVM becomes economically non-viable above $\\approx$10~bps due to high turnover (217 trades/1,500 days).")
sub("C6",
    "\\item \\textbf{Open Science and Audited Reproducibility:} All empirical claims are traced to raw numerical outputs logged in an automated consistency audit database, supported by full Python, Qiskit, and MATLAB replication suites.",
    "\\item \\textbf{Audited reproducibility:} All numerical claims are logged in \\texttt{results/numerical\\_claims.csv} and verified against Python, Qiskit, and MATLAB outputs in the supplementary replication archive.")

# ── 11. H1 verdict ────────────────────────────────────────────────────────────
sub("H1-verdict",
    "Tree-based classical ensembles exhibit lower out-of-sample accuracy, with Random Forest achieving 50.40\\% and Gradient Boosting recording 49.33\\%.",
    "Tree-based classical ensembles are worst: Random Forest 50.40\\%, Gradient Boosting 49.33\\%.\n\n"
    "\\textbf{H1 Verdict: NOT SUPPORTED.} QSVM does not improve directional accuracy over all baselines. "
    "It trails SVM-RBF by 3.67~pp, raw returns by 2.80~pp, and Logistic Regression by 2.13~pp.")

# ── 12. DM section title ──────────────────────────────────────────────────────
sub("DM-title",
    "\\subsection{Econometric Significance: Diebold-Mariano Tests}",
    "\\subsection{Econometric Significance: Extended DM Tests with Holm--Bonferroni Correction}")

# ── 13. DM input — add extended table ─────────────────────────────────────────
sub("DM-input",
    "\\input{../tables/Table07_statistical_significance.tex}",
    "\\input{../tables/Table07_statistical_significance.tex}\n"
    "\\input{../tables/Table07b_dm_extended_holm.tex}")

# ── 14. DM findings — replace boilerplate with H2 verdict ────────────────────
sub("DM-findings",
    "The Diebold-Mariano test results provide notable empirical findings:\n"
    "\\begin{enumerate}\n"
    "    \\item \\textbf{Quantum Kernel vs. Logistic Regression}: The Quantum Kernel QSVM achieves a $DM$ statistic of $+2.030$ ($p = 0.0423$), rejecting the null hypothesis of equal forecast accuracy at the 5\\% significance level. This confirms that the non-linear quantum kernel mapping produces a statistically significant reduction in forecast loss relative to the linear classical baseline.\n"
    "    \\item \\textbf{Quantum Kernel vs. Gradient Boosting}: The Quantum Kernel achieves a $DM$ statistic of $+5.097$ ($p = 3.44 \\times 10^{-7}$), demonstrating highly significant predictive superiority over gradient-boosted decision trees.\n"
    "    \\item \\textbf{SVM-RBF Performance}: The classical Gaussian SVM demonstrates the strongest statistical superiority, yielding $DM = +3.122$ ($p = 0.0018$) against Logistic Regression.\n"
    "\\end{enumerate}\n\n"
    "These findings support \\textbf{Hypothesis 2} by confirming that quantum kernel representations produce statistically significant forecast loss reductions over standard linear baselines and complex boosted tree ensembles.",
    "The extended DM analysis (Table~\\ref{tab:dm_extended}) reveals a nuanced picture:\n"
    "\\begin{enumerate}\n"
    "    \\item \\textbf{QSVM vs.\\ SVM-RBF (the key omitted comparison):} $DM = -0.053$ ($p = 0.958$). "
    "A negative DM statistic means SVM-RBF has slightly lower Brier loss. The null of equal predictive accuracy "
    "between the quantum and classical nonlinear kernels cannot be rejected. This is the central finding.\n"
    "    \\item \\textbf{QSVM vs.\\ Logistic Regression:} $DM = +2.030$, raw $p = 0.042$---nominally significant. "
    "After Holm--Bonferroni correction over six comparisons, $p_{\\mathrm{adj}} = 0.212$; null is \\emph{not} rejected.\n"
    "    \\item \\textbf{QSVM vs.\\ Gradient Boosting:} $DM = +5.097$ ($p_{\\mathrm{adj}} < 10^{-5}$). "
    "Survives correction; QSVM significantly outperforms Gradient Boosting.\n"
    "    \\item \\textbf{All other comparisons:} All $p_{\\mathrm{adj}} > 0.40$; no significant differences.\n"
    "\\end{enumerate}\n\n"
    "\\textbf{H2 Verdict: PARTIALLY SUPPORTED (with critical caveats).} QSVM beats Gradient Boosting after correction. "
    "However, there is no evidence QSVM outperforms SVM-RBF or the raw-returns baseline. "
    "The claim that quantum kernels produce statistically significant improvements over competitive classical methods is not supported.")

# ── 15. Econ backtesting heading ──────────────────────────────────────────────
sub("Econ-h",
    "\\subsection{Economic Backtesting Under Transaction Costs}",
    "\\subsection{Economic Backtesting and Transaction-Cost Sensitivity}")

sub("Econ-intro",
    "In quantitative finance, statistical accuracy does not guarantee economic profitability. Table~\\ref{tab:Table08_economic_performance_5bps} presents the economic backtesting performance under institutional 5~bps transaction costs.",
    "Statistical accuracy does not guarantee economic profitability. Tables~\\ref{tab:Table08_economic_performance_5bps} and~\\ref{tab:Table08b_economic_performance_10bps} present backtesting performance; Figure~\\ref{fig:tc_sensitivity} extends analysis to the full 0--50~bps range.")

# ── 16. H3 verdict + TC figure ───────────────────────────────────────────────
sub("H3-fail",
    "These results fail to support \\textbf{Hypothesis 3}: although the quantum model generates positive risk-adjusted returns net of costs and outperforms tree-based classical machine learning ensembles, transaction costs and position turnover prevent it from outperforming passive Buy-and-Hold or low-turnover classical SVMs.",
    "Figure~\\ref{fig:tc_sensitivity} extends this to the full 0--50~bps range: QSVM Sharpe degrades "
    "from $\\approx$0.42 at 0~bps to $\\approx$0.23 at 5~bps, near zero above 20~bps, while SVM-RBF "
    "remains nearly constant owing to near-zero turnover.\n\n"
    "\\begin{figure}[htbp]\n"
    "    \\centering\n"
    "    \\includegraphics[width=0.95\\textwidth]{../figures/png/Fig_TC_sensitivity.png}\n"
    "    \\caption{Transaction-cost sensitivity: (a) Net CAGR and (b) approximate Sharpe ratio "
    "vs.\\ transaction cost (0--50~bps, log-linear scale). SVM-RBF is nearly insensitive to "
    "cost (7 trades/1,500 days); QSVM degrades sharply (217 trades). $R_f = 2\\%$ p.a.}\n"
    "    \\label{fig:tc_sensitivity}\n"
    "\\end{figure}\n\n"
    "\\textbf{H3 Verdict: NOT SUPPORTED.} The QSVM strategy does not achieve superior "
    "risk-adjusted returns over passive Buy-and-Hold or SVM-RBF at any tested cost level.")

# ── 17. Ablation heading ──────────────────────────────────────────────────────
sub("Abl-h",
    "\\subsection{Controlled Component Ablation Study}",
    "\\subsection{Extended Component Ablation Study}")

sub("Abl-input",
    "\\input{../tables/Table09_ablation_study.tex}",
    "\\input{../tables/Table09_ablation_study.tex}\n"
    "\\input{../tables/Table09b_ablation_extended.tex}")

sub("Abl-text",
    "The ablation analysis reveals that moving from raw returns (Config 1) to technical indicators (Config 2) preserves comparable accuracy (53.13\\% vs 53.80\\%) while altering the timing and nature of directional signals. Introducing complex tree boosting (Config 3) results in overfitting on financial noise, depressing accuracy to 49.33\\% and Sharpe to 0.06. The Quantum Kernel (Config 4) restores accuracy to 51.00\\% and elevates the Sharpe ratio to 0.23, demonstrating that the quantum feature map provides effective non-linear regularization. The Hybrid Quantum-Classical architecture (Config 5) achieves 52.60\\% accuracy, confirming that quantum features add measurable diversification to classical indicators, supporting \\textbf{Hypothesis 4}.",
    "The critical comparison is Config D vs.\\ Config E: classical SVM-RBF on 4 PCA components "
    "achieves 53.40\\% accuracy and Sharpe 0.501; the quantum kernel on identical inputs achieves "
    "51.00\\% accuracy and Sharpe 0.233. The quantum-induced deficit is "
    "$\\Delta_Q = -2.40$~pp accuracy and $-0.268$ Sharpe---attributable to the quantum encoding "
    "itself, not to PCA compression.\n\n"
    "\\textbf{H4 Verdict: NOT SUPPORTED.} The quantum kernel does not add incremental predictive "
    "value over a matched classical SVM-RBF on identical feature representations.")

# ── 18. H5 verdict ────────────────────────────────────────────────────────────
sub("H5-v",
    "Across regimes, the Hybrid Quantum-Classical model exhibits remarkable stability, achieving 53.28\\% in bull regimes and 50.29\\% in bear markets, while outperforming all classical non-linear models in low volatility regimes (52.02\\% vs 46.09\\% for Gradient Boosting). The Quantum Kernel maintains accuracy above 50.1\\% across all regimes, confirming moderate robustness and partially supporting \\textbf{Hypothesis 5}.",
    "Across regimes, the Hybrid model achieves 53.28\\% in bull regimes and 50.29\\% in bear markets. "
    "The QSVM maintains accuracy above 50.1\\% across all regimes but does not outperform SVM-RBF in any regime.\n\n"
    "\\textbf{H5 Verdict: PARTIALLY SUPPORTED.} QSVM shows moderate regime stability but no "
    "consistent superiority over classical baselines in any regime subgroup.")

# ── 19. Discussion ────────────────────────────────────────────────────────────
sub("Disc-sect",
    "\\section{Discussion, Limitations, and Practical Implications}",
    "\\section{Discussion, Threats to Validity, and Limitations}")
sub("Disc-sub",
    "\\subsection{Quantitative Finance Implications: Does Quantum Add Real Value?}",
    "\\subsection{What the Findings Say}")
sub("Disc-body",
    "Our empirical findings provide nuanced insights into the ongoing debate surrounding quantum computing in finance. First, our results demonstrate that quantum kernel methods are capable of extracting genuine non-linear structure from financial time series, evidenced by a statistically significant Diebold-Mariano test statistic ($DM = 2.030$, $p = 0.0423$) relative to linear logistic baselines and overwhelming superiority over Gradient Boosted trees ($DM = 5.097$, $p < 10^{-6}$). By projecting input indicators into an entangled Hilbert state space, the quantum kernel implicitly evaluates complex trigonometric polynomials that act as a natural regularizer against financial noise.\n\nSecond, our economic backtesting highlights a crucial lesson for quantitative finance: \\textit{statistical loss reduction does not automatically confer economic profitability}. While the quantum kernel achieves positive risk-adjusted returns (Sharpe 0.23, CAGR 4.72\\%) and comfortably outperforms classical tree ensembles under 5~bps transaction costs, it does not surpass passive equity holding or low-turnover Gaussian SVMs. In financial markets, active turnover incurs significant friction drag. Consequently, future research in quantum finance must focus on friction-aware objective functions that optimize portfolio turnover directly within the variational quantum circuit rather than treating prediction and execution as decoupled stages.",
    "Our central finding is a null result: QSVM is statistically indistinguishable from SVM-RBF "
    "($DM = -0.053$, $p = 0.958$). This is not a failure of experimental design; it is a reproducible "
    "calibration point that proponents of quantum kernel methods in finance must account for. "
    "Additionally: (i) QSVM outperforms Gradient Boosting by a margin surviving Holm correction; "
    "and (ii) regardless of kernel choice, high turnover---not kernel expressiveness---drives "
    "economic underperformance relative to passive indexing and SVM-RBF. Future quantum finance "
    "systems must embed turnover-penalizing objectives inside the quantum learning loop.")
sub("Disc-lim-h",
    "\\subsection{Methodological and Technological Limitations}",
    "\\subsection{Threats to Validity and Limitations}")
sub("Disc-sim",
    "\\item \\textbf{Quantum Simulation vs. Physical Hardware}: All quantum kernel evaluations in this paper were performed via statevector simulation on classical hardware. While statevector simulation reproduces exact mathematical quantum state evolution without shot noise or decoherence, physical NISQ execution on superconducting or trapped-ion hardware would incur thermal relaxation ($T_1$), dephasing ($T_2$), and two-qubit gate infidelities ($10^{-2}$ to $10^{-3}$), which could degrade kernel fidelity unless accompanied by quantum error mitigation.",
    "\\item \\textbf{Simulation bias:} Exact statevector simulation was used throughout (no shot noise, decoherence, or gate error). Physical NISQ hardware introduces $T_1$/$T_2$ relaxation and two-qubit gate infidelities ($\\sim\\!10^{-2}$--$10^{-3}$), likely degrading quantum kernel fidelity.\n"
    "    \\item \\textbf{Hybrid boundary:} The hybrid model computes $\\hat{q}_t$ on validation-period data. If per-fold boundary enforcement is incomplete, subtle in-sample leakage may inflate hybrid performance.\n"
    "    \\item \\textbf{Calibration:} QSVM Platt-scaled probabilities were not validated via reliability diagrams or ECE; portfolio use requires verified calibration.\n"
    "    \\item \\textbf{Regime endogeneity:} Regime labels use rolling 252-day statistics from the same return series; near-boundary regime assignments may be noisy.")
sub("Disc-dim",
    "\\item \\textbf{Dimensionality Constraints}: Due to the quadratic scaling of statevector simulation and current NISQ register limits, classical technical indicators were reduced to $n=4$ principal components prior to quantum encoding. While PCA preserves principal variance, it may discard subtle non-linear interactions present in the original 18-dimensional feature space.",
    "\\item \\textbf{Dimensionality bottleneck:} The 18-dimensional feature space was compressed to $n=4$ PCA components. The matched ablation (Config D vs.\\ E) controls for this, but a higher-qubit register might access richer non-linear structure.")
sub("Disc-asset",
    "\\item \\textbf{Asset Universe}: Our empirical benchmark focused on two liquid US equity index ETFs (SPY and QQQ). While these represent the world's most liquid financial contracts, findings may differ across less efficient market segments, such as emerging market equities, cryptocurrencies, or commodities.",
    "\\item \\textbf{Single primary asset:} Results are primarily from SPY. QQQ cross-instrument replication is preliminary; cross-asset generalisation is not warranted.")

# ── 20. Conclusion ────────────────────────────────────────────────────────────
sub("Conc",
    "This paper has presented a comprehensive, out-of-sample benchmarking study evaluating quantum-enhanced financial market prediction with technical indicators. Utilizing ten years of authentic market data and a 12-fold chronological walk-forward validation framework, we subjected quantum kernel and hybrid quantum-classical classifiers to rigorous econometric testing and transaction-cost-aware economic backtesting.\n\nOur findings demonstrate that quantum kernel methods achieve statistically significant forecast loss reductions over classical linear baselines and complex tree ensembles under the Diebold-Mariano test. However, after accounting for institutional transaction frictions, active position turnover substantially attenuates trading returns, resulting in performance that trails passive indexing and low-turnover classical SVMs. These results refute unverified claims of immediate quantum supremacy in financial forecasting while confirming the genuine non-linear expressiveness of quantum feature maps. We conclude that future progress in quantum finance requires embedding transaction costs, liquidity dynamics, and risk-adjusted objectives directly into quantum optimization routines.",
    "We set out to answer a direct question: do quantum kernels add predictive or economic value "
    "in realistic financial market prediction? Based on ten years of S\\&P~500 data, 1,500 "
    "out-of-sample days, and formal testing with multiple-testing correction, our answer is "
    "\\textbf{not in the present experimental setting}.\n\n"
    "The key finding is a null result: DM between QSVM and SVM-RBF is $-0.053$ ($p = 0.958$). "
    "After Holm--Bonferroni correction the nominal QSVM advantage over Logistic Regression also "
    "disappears ($p_{\\mathrm{adj}} = 0.212$). In economic backtesting, high turnover "
    "(217 trades vs.\\ 7 for SVM-RBF) causes the QSVM Sharpe to collapse toward zero above 20~bps. "
    "The extended ablation confirms the gap is attributable to the quantum kernel itself, "
    "not PCA compression.\n\n"
    "These are scientifically valuable findings. This study provides the first Holm-corrected, "
    "leakage-controlled, matched-baseline benchmark in quantum finance. Future research should "
    "explore variational circuits with turnover-penalizing loss functions, alternative encoding "
    "strategies (data re-uploading, amplitude encoding), and post-NISQ hardware capable of "
    "error-corrected kernel computation at scales that may yield genuine quantum advantage.")

# ── 21. Code availability ────────────────────────────────────────────────────
sub("Code-URL",
    "Complete, deterministic replication code for Python, Qiskit, and MATLAB is openly available on GitHub under the MIT License at:\\\\\n\\url{https://github.com/iafs-research/quantum-finance-market-prediction}.",
    "Complete, deterministic replication code for Python, Qiskit, and MATLAB is included in the "
    "supplementary material deposited with this manuscript. All numerical claims are cross-traced "
    "to \\texttt{results/numerical\\_claims.csv} in the replication archive.")

# ── Save ─────────────────────────────────────────────────────────────────────
MANU.write_bytes(txt.replace("\n", "\r\n").encode("utf-8"))

print("\n" + "=" * 62)
print("MANUSCRIPT REVISION REPORT")
print("=" * 62)
for line in applied:
    print(line)
print("=" * 62)
print(f"Saved: {MANU}  [{MANU.stat().st_size:,} bytes]")

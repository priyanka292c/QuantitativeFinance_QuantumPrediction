import os
import glob
import pandas as pd
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn
from docx.opc.constants import RELATIONSHIP_TYPE

def add_docx_hyperlink(paragraph, url, text, color="004B87", underline=True):
    """Add a clickable hyperlink to a python-docx paragraph."""
    part = paragraph.part
    r_id = part.relate_to(url, RELATIONSHIP_TYPE.HYPERLINK, is_external=True)
    hyperlink = parse_xml(
        f'<w:hyperlink xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"'
        f' r:id="{r_id}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        f'<w:r>'
        f'<w:rPr>'
        f'<w:rFonts w:ascii="Calibri" w:hAnsi="Calibri"/>'
        f'<w:sz w:val="19"/>'
        f'<w:color w:val="{color}"/>'
        + ('<w:u w:val="single"/>' if underline else '')
        + f'</w:rPr>'
        f'<w:t>{text}</w:t>'
        f'</w:r>'
        f'</w:hyperlink>'
    )
    paragraph._p.append(hyperlink)
    return hyperlink

def set_cell_background(cell, fill_hex):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = parse_xml(f'<w:tcMar {nsdecls("w")}><w:top w:w="{top}" w:type="dxa"/><w:bottom w:w="{bottom}" w:type="dxa"/><w:left w:w="{left}" w:type="dxa"/><w:right w:w="{right}" w:type="dxa"/></w:tcMar>')
    tcPr.append(tcMar)

def add_styled_heading(doc, text, level):
    h = doc.add_heading(text, level=level)
    h.paragraph_format.space_before = Pt(12 if level == 1 else 8)
    h.paragraph_format.space_after = Pt(4)
    h.paragraph_format.keep_with_next = True
    run = h.runs[0]
    run.font.name = "Calibri"
    if level == 1:
        run.font.size = Pt(16)
        run.font.bold = True
        run.font.color.rgb = RGBColor(0x1B, 0x36, 0x5D) # Navy
    elif level == 2:
        run.font.size = Pt(13)
        run.font.bold = True
        run.font.color.rgb = RGBColor(0x2C, 0x3E, 0x50)
    elif level == 3:
        run.font.size = Pt(11.5)
        run.font.bold = True
        run.font.color.rgb = RGBColor(0x4A, 0x55, 0x68)
    return h

def add_body_paragraph(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = 1.25
    p.paragraph_format.space_after = Pt(6)
    run = p.add_run(text)
    run.font.name = "Calibri"
    run.font.size = Pt(11)
    run.font.color.rgb = RGBColor(0x22, 0x22, 0x22)
    return p

def insert_csv_table(doc, csv_path, caption_text, table_num):
    if not os.path.exists(csv_path):
        return
    df = pd.read_csv(csv_path)
    
    # Caption
    cp = doc.add_paragraph()
    cp.paragraph_format.space_before = Pt(10)
    cp.paragraph_format.space_after = Pt(4)
    cp.paragraph_format.keep_with_next = True
    c_run = cp.add_run(f"Table {table_num}: {caption_text}")
    c_run.font.name = "Calibri"
    c_run.font.size = Pt(10)
    c_run.font.bold = True
    c_run.font.color.rgb = RGBColor(0x1B, 0x36, 0x5D)

    table = doc.add_table(rows=len(df) + 1, cols=len(df.columns))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True

    # Header Row
    hdr_cells = table.rows[0].cells
    for i, col_name in enumerate(df.columns):
        clean_name = str(col_name).replace("_", " ")
        cell = hdr_cells[i]
        set_cell_background(cell, "1B365D")
        set_cell_margins(cell, 120, 120, 150, 150)
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(clean_name)
        run.font.name = "Calibri"
        run.font.size = Pt(9.5)
        run.font.bold = True
        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)

    # Data Rows
    for r_idx, row in df.iterrows():
        row_cells = table.rows[r_idx + 1].cells
        bg_hex = "F8F9FA" if r_idx % 2 == 1 else "FFFFFF"
        for c_idx, val in enumerate(row):
            cell = row_cells[c_idx]
            set_cell_background(cell, bg_hex)
            set_cell_margins(cell, 80, 80, 120, 120)
            p = cell.paragraphs[0]
            val_str = str(val)
            # Try numeric formatting
            try:
                fval = float(val)
                val_str = f"{fval:.4f}" if "." in str(val) and len(str(val).split(".")[1]) > 4 else str(val)
                p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            except (ValueError, TypeError):
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            run = p.add_run(val_str)
            run.font.name = "Calibri"
            run.font.size = Pt(9)
            run.font.color.rgb = RGBColor(0x33, 0x33, 0x33)

    doc.add_paragraph().paragraph_format.space_after = Pt(8)

def insert_figure(doc, img_path, caption_text, fig_num):
    if not os.path.exists(img_path):
        return
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(4)
    run = p.add_run()
    run.add_picture(img_path, width=Inches(6.0))

    cp = doc.add_paragraph()
    cp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cp.paragraph_format.space_after = Pt(10)
    c_run = cp.add_run(f"Figure {fig_num}: {caption_text}")
    c_run.font.name = "Calibri"
    c_run.font.size = Pt(9.5)
    c_run.font.italic = True
    c_run.font.color.rgb = RGBColor(0x4A, 0x55, 0x68)

def build_word_document():
    doc = Document()

    # Page Margins 1 inch
    for s in doc.sections:
        s.top_margin = Inches(1.0)
        s.bottom_margin = Inches(1.0)
        s.left_margin = Inches(1.0)
        s.right_margin = Inches(1.0)

    # Title
    tp = doc.add_paragraph()
    tp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    tp.paragraph_format.space_before = Pt(18)
    tp.paragraph_format.space_after = Pt(12)
    t_run = tp.add_run("Do Quantum Kernels Add Value in Financial Market Prediction? An Empirical Benchmarking Study with Technical Indicators")
    t_run.font.name = "Calibri"
    t_run.font.size = Pt(18)
    t_run.font.bold = True
    t_run.font.color.rgb = RGBColor(0x1B, 0x36, 0x5D)

    # Authors
    ap = doc.add_paragraph()
    ap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    ap.paragraph_format.space_after = Pt(4)
    authors_data = [
        ("Shahrukh Saleem", "1,*"),
        ("Araby Madbouly", "2"),
        ("Uvesh Husain", "3"),
        ("Ram Soorat", "4"),
        ("Priyanka", "5"),
        ("Afzalur Rahman", "6"),
    ]
    for i, (name, aff) in enumerate(authors_data):
        r_name = ap.add_run(name)
        r_name.bold = True
        r_aff = ap.add_run(aff)
        r_aff.font.superscript = True
        if i < len(authors_data) - 1:
            ap.add_run(", ")

    # Affiliations
    aff_p = doc.add_paragraph()
    aff_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    aff_p.paragraph_format.space_after = Pt(14)
    aff_text = (
        "1 VIT Business School, Vellore Institute of Technology (Deemed to be University), Vellore, Tamil Nadu, India\n"
        "2 Business and Accounting Department, Muscat College, Muscat, Sultanate of Oman\n"
        "3 Economics and Business Studies Department, Mazoon College, Muscat, Oman\n"
        "4 School of Technology, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India\n"
        "5 Department of Physics and Astrophysics, University of Delhi, New Delhi, Delhi 110007, India\n"
        "6 School of Business, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India\n"
        "* Corresponding author: shahrukh.saleem@vit.ac.in\n"
        "ORCIDs: S. Saleem (0000-0003-2949-6188), A. Madbouly (0000-0002-7981-4191), U. Husain (0000-0002-8502-8488), "
        "R. Soorat (0000-0001-7875-9197), Priyanka (0009-0008-1520-0706), A. Rahman (0000-0002-1561-561X)"
    )
    aff_run = aff_p.add_run(aff_text)
    aff_run.font.name = "Calibri"
    aff_run.font.size = Pt(9.0)
    aff_run.font.italic = True
    aff_run.font.color.rgb = RGBColor(0x55, 0x55, 0x55)

    # Abstract Box
    abs_heading = doc.add_paragraph()
    abs_heading.paragraph_format.space_before = Pt(10)
    abs_heading.paragraph_format.space_after = Pt(2)
    h_run = abs_heading.add_run("ABSTRACT")
    h_run.font.bold = True
    h_run.font.size = Pt(11)
    h_run.font.color.rgb = RGBColor(0x1B, 0x36, 0x5D)

    abs_text = (
        "Recent advances in quantum computing have stimulated interest in quantum machine learning (QML) for financial "
        "market prediction. Yet the central empirical question---whether quantum kernel methods provide statistically or "
        "economically meaningful improvements over strong classical baselines under realistic conditions---remains unanswered. "
        "We address this through a large-scale, leakage-resistant study of next-day directional movement for the S&P 500 ETF (SPY) "
        "over ten years (2014-2023, 2,515 trading days). An 18-dimensional causal feature set is evaluated across a 12-fold "
        "chronological rolling walk-forward framework (1,500 out-of-sample days), benchmarking a second-order Pauli ZZ-feature map "
        "Quantum Kernel SVM (QSVM) and a Hybrid Quantum-Classical classifier against five tuned classical models including SVM-RBF.\n\n"
        "Our principal findings are negative but scientifically informative. The QSVM achieves 51.00% out-of-sample directional "
        "accuracy (95% CI: [48.60%, 53.47%]), trailing SVM-RBF (54.67%), raw returns (53.80%), and Logistic Regression (53.13%). "
        "The critical Diebold-Mariano comparison between QSVM and SVM-RBF yields DM = -0.053 (p = 0.958): no evidence the quantum "
        "kernel outperforms the matched classical nonlinear kernel. The nominal advantage over Logistic Regression (DM = 2.030, p = 0.042) "
        "is eliminated after Holm-Bonferroni multiple-testing correction (p_adj = 0.212). In economic backtesting at 5 bps, the QSVM "
        "generates a Sharpe ratio of 0.23 (CAGR 4.72%), well below passive Buy-and-Hold (Sharpe 0.57) and SVM-RBF (Sharpe 0.54). "
        "Transaction-cost sensitivity shows QSVM becomes economically non-viable above 10 bps owing to high turnover (217 trades vs. "
        "7 for SVM-RBF). An extended six-configuration ablation confirms the quantum deficit persists on identical PCA-compressed "
        "inputs: Delta_Q = -2.40 pp accuracy, -0.27 Sharpe. We provide this rigorously controlled negative benchmark to guide future "
        "quantum finance research toward turnover-aware quantum learning objectives."
    )
    add_body_paragraph(doc, abs_text)

    kw_p = doc.add_paragraph()
    kw_p.paragraph_format.space_after = Pt(12)
    kw_run = kw_p.add_run("Keywords: ")
    kw_run.bold = True
    kw_p.add_run("Quantum Machine Learning, Quantitative Finance, Technical Indicators, Financial Market Prediction, Walk-Forward Validation, Quantum Kernel Methods, Economic Backtesting, Diebold-Mariano Test.\n")
    jel_run = kw_p.add_run("JEL Classification: ")
    jel_run.bold = True
    kw_p.add_run("C53, C58, G11, G14, G17.")

    doc.add_page_break()

    # Section 1
    add_styled_heading(doc, "1. Introduction", 1)
    add_body_paragraph(doc, 
        "Predicting the future trajectory of financial asset prices represents one of the foundational, yet enduringly elusive, "
        "challenges in empirical asset pricing and quantitative finance (Fama, 1970; Campbell & Shiller, 1988; Lo & MacKinlay, 1988). "
        "While the Efficient Market Hypothesis (EMH) posits that asset prices fully reflect all available information, extensive econometric "
        "literature has documented persistent, if subtle, time-varying predictability arising from market microstructure frictions, time-varying "
        "risk premia, behavioral heuristics, and non-linear interactions across technical market indicators (Brock et al., 1992; Sullivan et al., 1999; "
        "Neely et al., 2014; Moskowitz et al., 2012). Over the last two decades, machine learning has transitioned from an auxiliary heuristic "
        "into a dominant paradigm for quantitative modeling, capturing complex interactions beyond linear regression capabilities (Gu et al., 2020; "
        "Feng et al., 2020; Sezer et al., 2020; Chen & Guestrin, 2016)."
    )
    add_body_paragraph(doc,
        "Simultaneously, quantum computing has emerged as a potentially transformative computational paradigm. Quantum machine learning (QML) "
        "theoretically promises computational advantages in high-dimensional linear algebra, kernel evaluation, and optimization (Biamonte et al., 2017; "
        "Harrow et al., 2009; Lloyd et al., 2014; Rebentrost et al., 2014). In finance, substantial research has investigated quantum algorithms for "
        "portfolio optimization, derivative pricing via quantum amplitude estimation, and financial distribution loading (Orus et al., 2019; "
        "Egger et al., 2020; Woerner & Egger, 2019; Stamatopoulos et al., 2020; Chakrabarti et al., 2021). More recently, parameterized quantum circuits "
        "and quantum kernel methods have been proposed as non-linear classifiers for financial time series (Havlicek et al., 2019; Schuld & Killoran, 2019; "
        "Huang et al., 2021)."
    )
    add_body_paragraph(doc,
        "However, a critical methodological disconnect exists between theoretical quantum algorithm design and rigorous quantitative finance. "
        "Many published quantum finance studies evaluate models on brief historical periods (e.g., a few months to a couple of years), utilize static "
        "in-sample/out-of-sample partitions vulnerable to regime bias, omit transaction costs, ignore turnover dynamics, or omit formal econometric "
        "hypothesis testing against competitive classical baselines. Consequently, the central question remains open: Does quantum-enhanced "
        "representation of financial technical indicators provide statistically significant and economically meaningful predictive improvements "
        "over strong classical baselines under rigorous out-of-sample and walk-forward evaluation?"
    )

    insert_figure(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\figures\png\Fig01_research_workflow.png",
                  "End-to-end research workflow spanning data acquisition, causal feature engineering, rolling walk-forward evaluation, quantum simulation, and econometric/economic auditing.", 1)

    insert_figure(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\figures\png\Fig02_hybrid_quantum_classical_architecture.png",
                  "Hybrid quantum-classical prediction architecture illustrating classical feature compression, second-order Pauli ZZ-feature map kernel evaluation, and dual-track decision logic.", 2)

    # Section 2
    add_styled_heading(doc, "2. Related Work and Literature Review", 1)
    add_styled_heading(doc, "2.1 Financial Market Predictability and Empirical Asset Pricing", 2)
    add_body_paragraph(doc,
        "Empirical asset pricing has evolved from classical portfolio theory (Markowitz, 1952; Sharpe, 1964) and continuous-time option pricing "
        "frameworks (Black & Scholes, 1973; Merton, 1973; Cox et al., 1979) to dynamic term structure models (Vasicek, 1977; Cox et al., 1985; "
        "Hull & White, 1990; Heath et al., 1992; Heston, 1993; Longstaff & Schwartz, 2001). Concurrently, statistical physics and econophysics "
        "perspectives have illuminated universal scaling laws, non-Gaussian heavy tails, and order-flow clustering in financial markets "
        "(Mantegna & Stanley, 1999; Plerou et al., 1999; Laloux et al., 1999; Gabaix et al., 2003; Challet et al., 2001; Cont & Bouchaud, 2000)."
    )
    add_body_paragraph(doc,
        "The predictability of asset returns has generated extensive debate in financial economics. Foundational studies established the weak and "
        "semi-strong forms of market efficiency (Fama, 1970; Fama & French, 1993, 2015; Ross, 1976; Roll, 1977; Lucas, 1978). However, empirical "
        "evidence has documented significant deviations from random walk dynamics (Lo & MacKinlay, 1988; Bouchaud & Potters, 2004; Bouchaud et al., 2000; "
        "Farmer et al., 2004; Biais et al., 2005). Brock et al. (1992) demonstrated that simple moving average and trading range "
        "breakout rules possess predictive ability on the Dow Jones Industrial Average. Sullivan et al. (1999) and White (2000) introduced bootstrap "
        "reality checks to evaluate whether technical trading rules survive data snooping, finding that while early historical performance was robust, "
        "excess returns have attenuated over time as markets computerized. Neely et al. (2014) showed that technical indicators provide substantial "
        "predictive power for the equity risk premium. In high-frequency and microstructure settings, order flow and volatility dynamics exhibit "
        "long memory and non-linear feedback (Cont, 2001; Engle, 1982; Bollerslev, 1986; Corsi, 2009; Patton, 2006; Andersen et al., 2003, 2007)."
    )

    add_styled_heading(doc, "2.2 Machine Learning in Empirical Asset Pricing", 2)
    add_body_paragraph(doc,
        "The integration of non-linear machine learning into empirical asset pricing has surged over the past decade. In a landmark study, "
        "Gu et al. (2020) conducted a comprehensive comparative analysis of machine learning methods for predicting the cross-section of individual stock returns, "
        "demonstrating that shallow neural networks and gradient boosted decision trees substantially outperform standard linear econometric models by "
        "capturing non-linear interactions. Bianchi et al. (2021) extended this framework to bond risk premia, showing that machine learning models "
        "extract economic value by conditioning on macro factors and yield curve shape. Feng et al. (2020) developed deep neural network asset pricing models "
        "incorporating no-arbitrage constraints. Earlier foundational work applied Random Forests, Support Vector Machines, and Recurrent Neural Networks to "
        "directional market forecasting (Krauss et al., 2017; Fischer & Krauss, 2018; Sezer et al., 2020; Heaton et al., 2017). However, scholars have "
        "repeatedly emphasized the pervasive risks of backtest overfitting and pseudo-mathematical optimization in quantitative finance (Bailey et al., 2017; "
        "Harvey et al., 2016; Welch & Goyal, 2008; Rapach et al., 2010)."
    )

    add_styled_heading(doc, "2.3 Quantum Machine Learning and Quantum Finance", 2)
    add_body_paragraph(doc,
        "Quantum machine learning leverages quantum state spaces to compute linear models in feature Hilbert spaces that correspond to complex non-linear "
        "kernels in classical input space (Biamonte et al., 2017; Schuld et al., 2015; Schuld & Killoran, 2019). Havlicek et al. (2019) experimentally "
        "demonstrated supervised learning on a physical quantum processor using quantum-enhanced feature spaces, introducing the second-order Pauli "
        "ZZ-feature map. Huang et al. (2021) analyzed the power of data in quantum machine learning, establishing theoretical conditions under which quantum "
        "kernels can achieve learning advantages over classical models. Cerezo et al. (2021) provided a comprehensive review of variational quantum "
        "algorithms, highlighting optimization challenges such as barren plateaus in deep parameterized circuits (McClean et al., 2018; Hubregtsen et al., 2021)."
    )
    add_body_paragraph(doc,
        "In quantitative finance, quantum algorithms have been proposed across three primary domains: portfolio optimization, derivative pricing, and market "
        "forecasting (Orus et al., 2019; Herman et al., 2023; Egger et al., 2020; Bova et al., 2021). For derivative pricing and risk analysis, quantum amplitude "
        "estimation provides a theoretical quadratic speed-up over classical Monte Carlo methods (Rebentrost et al., 2018b; Woerner & Egger, 2019; "
        "Stamatopoulos et al., 2020; Chakrabarti et al., 2021). For portfolio optimization, quantum annealers and the Quantum Approximate Optimization "
        "Algorithm (QAOA) have been explored on combinatorial selection problems (Mugel et al., 2022; Venturelli & Kondratyev, 2019; Rebentrost et al., 2018a). "
        "Generative quantum modelling for financial distribution loading has been demonstrated by Zoufal et al. (2019) and Abbas et al. (2021). However, "
        "critical appraisals of quantum machine learning by Bowles et al. (2024) and McClean et al. (2018) emphasize that empirical claims of practical quantum "
        "advantage must withstand rigorous benchmarking against competitive classical methods. This study bridges this critical literature gap."
    )

    # Section 3
    add_styled_heading(doc, "3. Methodology and Experimental Design", 1)
    insert_csv_table(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\tables\Table01_dataset_characteristics.csv",
                     "Summary of empirical dataset characteristics for the SPDR S&P 500 ETF Trust (SPY).", 1)

    insert_csv_table(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\tables\Table02_technical_indicators.csv",
                     "Causal technical indicator engineering specifications.", 2)

    insert_figure(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\figures\png\Fig04_feature_correlation_matrix.png",
                  "Correlation matrix across the 18 causal technical indicators, illustrating orthogonal feature clusters spanning trend, momentum, volatility, and volume.", 4)

    insert_csv_table(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\tables\Table03_model_configurations.csv",
                     "Evaluated classical and quantum model architectures and feature dimensions.", 3)

    insert_figure(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\figures\png\Fig05_quantum_feature_map_circuit.png",
                  "Quantum circuit architecture for the parameterized second-order Pauli ZZ-feature map.", 5)

    insert_csv_table(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\tables\Table04_quantum_circuit_configurations.csv",
                     "Quantum circuit resource specifications and gate configurations.", 4)

    insert_csv_table(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\tables\Table05_hyperparameters.csv",
                     "Hyperparameter optimization protocol and search ranges.", 5)

    insert_figure(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\figures\png\Fig03_walkforward_methodology.png",
                  "Chronological walk-forward validation framework across 12 rolling folds.", 3)

    # Section 4
    add_styled_heading(doc, "4. Empirical Results", 1)
    add_body_paragraph(doc,
        "Table 6 and Figure 6 summarize out-of-sample directional prediction metrics across all 1,500 test days. Classical SVM-RBF achieves "
        "the highest overall directional accuracy at 54.67% (95% CI: [52.13%, 57.27%]), followed by linear Logistic Regression at 53.13% "
        "(95% CI: [50.60%, 55.67%]). The Quantum Kernel QSVM obtains 51.00% accuracy (95% CI: [48.60%, 53.47%]), surpassing Gradient Boosting (49.33%) "
        "and Random Forest (50.40%). The Hybrid Quantum-Classical classifier achieves 52.60% (95% CI: [50.07%, 55.13%]), bridging classical "
        "linear stability and quantum non-linear expressiveness."
    )

    insert_csv_table(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\tables\Table06_predictive_performance.csv",
                     "Out-of-sample predictive performance metrics across 12 rolling walk-forward folds (1,500 trading days).", 6)

    insert_figure(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\figures\png\Fig06_predictive_performance.png",
                  "Out-of-sample directional accuracy with 95% stationary bootstrap confidence intervals across candidate models.", 6)

    insert_figure(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\figures\png\Fig07_roc_pr_curves.png",
                  "Receiver Operating Characteristic (ROC) and Precision-Recall (PR) curves across models.", 7)

    insert_figure(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\figures\png\Fig08_walkforward_performance.png",
                  "Out-of-sample fold-by-fold accuracy trajectories across the 12 walk-forward rolling test windows (2018-2024).", 8)

    insert_figure(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\figures\png\Fig09_error_distribution.png",
                  "Out-of-sample prediction error distributions (Brier score loss densities) across candidate models.", 9)

    add_styled_heading(doc, "4.2 Econometric Hypothesis Testing (Diebold-Mariano Tests)", 2)
    add_body_paragraph(doc,
        "Table 7 presents pairwise Diebold-Mariano test statistics and asymptotic p-values across all models. "
        "To rigorously address multiple-testing concerns, Table 7b reports extended DM comparisons with Holm-Bonferroni "
        "family-wise error rate corrections. Under raw p-values, the Quantum Kernel QSVM shows nominal forecast-loss "
        "reduction over Logistic Regression (DM = 2.030, p = 0.0423) and Gradient Boosting (DM = 5.097, p < 10^-6). "
        "However, against SVM-RBF, the comparison yields DM = -0.0532 (p = 0.9576), indicating no statistical advantage. "
        "Crucially, after Holm-Bonferroni correction, the nominal advantage over Logistic Regression fails to reach significance "
        "(p_adj = 0.2117), confirming that quantum kernel predictions are statistically indistinguishable from strong classical models."
    )

    insert_csv_table(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\tables\Table07_statistical_significance.csv",
                     "Pairwise Diebold-Mariano test statistics and p-values for out-of-sample predictive superiority.", 7)

    insert_csv_table(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\tables\Table07b_dm_extended_holm.csv",
                     "Extended Diebold-Mariano tests with Holm-Bonferroni multiple testing correction.", "7b")

    add_styled_heading(doc, "4.3 Economic Backtesting and Transaction-Cost Sensitivity", 2)
    add_body_paragraph(doc,
        "Tables 8, 8b, and the Transaction-Cost Sensitivity Matrix (Table TC) detail economic trading performance. "
        "At 5 bps costs, QSVM achieves a Sharpe ratio of 0.23 (CAGR 4.72%), outperforming Gradient Boosting (0.06) "
        "and Random Forest (0.03), but trailing low-turnover SVM-RBF (0.54) and passive Buy-and-Hold (0.57, CAGR 12.10%). "
        "Sensitivity analysis reveals that QSVM incurs 217 trades (36.5 annual turnover), causing net CAGR to fall negative "
        "(-0.83% at 20 bps, -11.76% at 50 bps), whereas SVM-RBF (1.18 turnover) maintains positive Sharpe across all friction levels."
    )

    insert_csv_table(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\tables\Table08_economic_performance_5bps.csv",
                     "Economic backtesting performance metrics under 5 bps transaction costs.", 8)

    insert_csv_table(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\tables\Table08b_economic_performance_10bps.csv",
                     "Economic backtesting performance metrics under 10 bps transaction costs.", "8b")

    insert_csv_table(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\tables\Table_TC_sensitivity.csv",
                     "Transaction-cost sensitivity analysis across cost levels (0 to 50 bps).", "8c")

    insert_figure(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\figures\png\Fig10_cumulative_returns.png",
                  "Cumulative equity curves (log scale) across trading strategies under 5 bps transaction costs.", 10)

    insert_figure(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\figures\png\Fig11_drawdown_curves.png",
                  "Historical drawdown trajectories across candidate trading strategies (2018-2024).", 11)

    insert_figure(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\figures\png\Fig12_sharpe_sortino.png",
                  "Annualized Sharpe and Sortino ratios under 5 bps transaction costs across all models.", 12)

    insert_figure(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\figures\png\Fig_TC_sensitivity.png",
                  "Transaction-cost sensitivity: Net CAGR and Sharpe ratio degradation across friction levels (0 to 50 bps).", "12b")

    # Section 4.4 Ablation, Regimes, Resources
    add_styled_heading(doc, "4.4 Extended Component Ablation Study", 2)
    add_body_paragraph(doc,
        "The component ablation analysis is presented in two complementary views. Table 9 provides the initial five-configuration baseline comparison, "
        "while Table 9b and Figure 13 provide the extended six-configuration analysis that explicitly isolates classical PCA compression and quantum-kernel contributions. "
        "Holding input dimensionality fixed at 4 principal components, comparing Config E (QSVM) directly to Config D (SVM-RBF on identical PCs), "
        "the quantum contribution is negative: Delta_Q(Accuracy) = -2.40 pp, Delta_Q(Brier) = +0.0003, and Delta_Q(Sharpe) = -0.2680. "
        "This rigorously demonstrates that the quantum kernel underperforms the classical RBF kernel on identical compressed representations."
    )

    insert_csv_table(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\tables\Table09_ablation_study.csv",
                     "Component ablation study across feature sets and model configurations.", 9)

    insert_csv_table(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\tables\Table09b_ablation_extended.csv",
                     "Extended ablation matrix isolating PCA and quantum contributions (Delta_Q).", "9b")

    insert_figure(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\figures\png\Fig13_ablation_analysis.png",
                  "Ablation analysis comparing directional accuracy across model configurations and feature sets.", 13)

    add_styled_heading(doc, "4.5 Market Regime Sensitivity Analysis", 2)
    insert_csv_table(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\tables\Table10_market_regime_analysis.csv",
                     "Out-of-sample directional accuracy segmented across distinct macroeconomic and market volatility regimes.", 10)

    insert_figure(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\figures\png\Fig14_regime_performance.png",
                  "Directional accuracy segmented across Bull, Bear, Low Volatility, High Volatility, and Crisis market regimes.", 14)

    add_styled_heading(doc, "4.6 Computational Complexity and Resource Analysis", 2)
    insert_csv_table(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\tables\Table11_computational_cost.csv",
                     "Quantum circuit resource analysis and gate counts for statevector simulation.", 11)

    insert_figure(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\figures\png\Fig15_quantum_resources.png",
                  "Quantum circuit depth and gate count scaling as a function of qubit register dimension.", 15)

    insert_csv_table(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\tables\Table12_reproducibility_info.csv",
                     "Computational environment, library versions, and execution parameters.", 12)

    # Section 4.7 Hypothesis Audit
    add_styled_heading(doc, "4.7 Formal Hypothesis Audit", 2)
    add_body_paragraph(doc,
        "Table 13 presents the formal audit of all five pre-specified research hypotheses. None of the four core hypotheses "
        "(H1, H2, H3, H4) are supported, while market regime robustness (H5) is partially supported."
    )
    insert_csv_table(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\tables\Table_hypothesis_audit.csv",
                     "Formal Hypothesis Audit: Verdict and Supporting Evidence for All Five Research Hypotheses.", 13)

    insert_csv_table(doc, r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\tables\Table_literature_comparison.csv",
                     "Comparative Literature Survey: Methodological Characteristics of Representative QML Finance Studies.", 14)

    # Section 5 & 6 Discussion & Conclusion
    add_styled_heading(doc, "5. Discussion", 1)
    add_body_paragraph(doc,
        "The empirical findings provide an honest, definitive resolution to the five hypotheses. First, regarding H1 and H2, "
        "the Quantum Kernel QSVM does not demonstrate superiority over classical SVM-RBF (51.00% vs. 54.67%), and DM testing "
        "yields DM = -0.053 (p = 0.958). The nominal advantage over Logistic Regression evaporates once multiple-testing adjustments "
        "are applied. Second, regarding H3 and H4, economic backtesting highlights the primacy of market frictions: high turnover "
        "destroys the economic viability of active quantum strategies above 10 bps. On matched PCA inputs, the quantum kernel yields "
        "a negative incremental contribution (Delta_Q = -2.40 pp accuracy, -0.268 Sharpe). "
        "These results demonstrate that future quantum finance research must integrate turnover-penalized loss functions rather than "
        "relying solely on unconstrained statistical classifiers."
    )
    add_body_paragraph(doc,
        "Second, addressing H3 and H4, economic backtesting highlights the critical impact of transaction frictions. Because financial markets "
        "have low signal-to-noise ratios, models that trade frequently suffer severe turnover drag. While the Quantum Kernel generates positive "
        "Sharpe ratio (0.23) and outclasses Gradient Boosting and Random Forest, its active turnover (36.2x annually) prevents it from matching "
        "passive Buy-and-Hold. The ablation study confirms that technical indicator engineering provides the core baseline predictability, "
        "while the quantum kernel provides non-linear regularization."
    )

    add_styled_heading(doc, "6. Conclusion", 1)
    add_body_paragraph(doc,
        "This study presented an extensive, leakage-resistant empirical investigation into quantum-enhanced financial market prediction. "
        "Using 10 years of S&P 500 ETF data, 18 causal technical indicators, and a 12-fold walk-forward validation framework, we conducted "
        "rigorous statistical hypothesis testing, economic backtesting under transaction costs, and controlled component ablation. "
        "Our findings provide a realistic benchmark for quantum finance, confirming that while quantum kernels exhibit valid non-linear "
        "expressiveness, market frictions dominate trading performance in practical settings."
    )

    # Declarations
    add_styled_heading(doc, "Declarations", 1)
    add_styled_heading(doc, "Disclosure Statement / Conflict of Interest", 3)
    add_body_paragraph(doc, "The authors report there are no competing financial or non-financial interests to declare.")
    add_styled_heading(doc, "Funding Statement", 3)
    add_body_paragraph(doc, "This research received no external grant or corporate funding.")
    add_styled_heading(doc, "Author Contributions (CRediT Taxonomy)", 3)
    add_body_paragraph(doc, 
        "Shahrukh Saleem: Conceptualization, Methodology, Supervision, Formal Analysis, Writing - Original Draft, Project Administration.\n"
        "Araby Madbouly: Methodology, Formal Analysis, Validation, Writing - Review & Editing.\n"
        "Uvesh Husain: Data Curation, Validation, Statistical Econometric Analysis, Writing - Review & Editing.\n"
        "Ram Soorat: Software (Python & Qiskit), Quantum Circuit Design, Computational Experiments, Visualization.\n"
        "Priyanka: Quantum Kernel Methods, Theoretical Formulation, Formal Analysis, Writing - Review & Editing.\n"
        "Afzalur Rahman: Economic Backtesting, Risk Analysis, Validation, Writing - Review & Editing."
    )
    add_styled_heading(doc, "Data Availability Statement", 3)
    add_body_paragraph(doc, "All historical market data (SPY and QQQ) are publicly available via Yahoo Finance and preserved in the data/ directory.")
    add_styled_heading(doc, "Code Availability Statement", 3)
    add_body_paragraph(doc, "Deterministic replication code for Python, Qiskit, and MATLAB is available on GitHub under the MIT License at: https://github.com/iafs-research/quantum-finance-market-prediction.")
    add_styled_heading(doc, "AI-Assisted Technologies Disclosure", 3)
    add_body_paragraph(doc, 
        "During the preparation of this manuscript, the authors utilized AI-assisted computational technologies "
        "to assist with pipeline orchestration, script refactoring, preliminary grammatical polishing, and formatting compliance with journal guidelines. "
        "All empirical hypotheses, theoretical models, data preprocessing protocols, experimental executions, econometric evaluations, and scientific interpretations "
        "were conceived, designed, critically evaluated, verified, and approved solely by the human authors, who assume full responsibility for the content, accuracy, "
        "and scientific integrity of this publication."
    )

    # References Section
    doc.add_page_break()
    add_styled_heading(doc, "References", 1)
    
    # Read references.bib and parse entries
    import re
    bib_path = r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\manuscript\references.bib"
    with open(bib_path, "r", encoding="utf-8") as f:
        bib_text = f.read()

    entries = re.findall(r'@(\w+)\{([^,]+),\s*(.*?)\n\}', bib_text, re.DOTALL)
    ref_list = []
    for entry_type, key, body in entries:
        fields = {}
        for line in body.split("\n"):
            line = line.strip()
            if "=" in line:
                parts = line.split("=", 1)
                f_name = parts[0].strip().lower()
                f_val = parts[1].strip().rstrip(",").strip("{}").strip('"')
                fields[f_name] = f_val
        
        author = fields.get("author", "Unknown Author")
        year = fields.get("year", "n.d.")
        title = fields.get("title", "").replace("{", "").replace("}", "").rstrip(".").strip()
        journal = fields.get("journal", fields.get("booktitle", "")).replace("{", "").replace("}", "").strip()
        volume = fields.get("volume", "")
        number = fields.get("number", "")
        pages = fields.get("pages", "").replace("--", "–")
        doi = fields.get("doi", "")
        url = fields.get("url", fields.get("howpublished", ""))

        author_clean = author.replace("{", "").replace("}", "").strip()

        citation_str = f"{author_clean} ({year}). {title}. "
        if journal:
            citation_str += f"{journal}"
            if volume:
                citation_str += f", {volume}"
                if number:
                    citation_str += f"({number})"
            if pages:
                citation_str += f", {pages}"
            citation_str += ". "

        link_url = ""
        link_text = ""
        if doi:
            link_url = f"https://doi.org/{doi}"
            link_text = f"https://doi.org/{doi}"
        elif url:
            clean_url = url.replace("\\url{", "").replace("}", "").replace("\\", "").strip()
            if clean_url.startswith("http"):
                link_url = clean_url
                link_text = clean_url

        first_auth_surname = author_clean.split(" and ")[0].split(",")[0].split(" ")[-1]
        ref_list.append((first_auth_surname, year, citation_str, link_url, link_text))

    # Sort alphabetically by first author surname
    ref_list.sort(key=lambda x: (x[0].lower(), x[1]))

    for _, _, ref_str, link_url, link_text in ref_list:
        rp = doc.add_paragraph()
        rp.paragraph_format.line_spacing = 1.15
        rp.paragraph_format.space_after = Pt(4)
        rp.paragraph_format.left_indent = Inches(0.5)
        rp.paragraph_format.first_line_indent = Inches(-0.5)
        r_run = rp.add_run(ref_str)
        r_run.font.name = "Calibri"
        r_run.font.size = Pt(9.5)
        r_run.font.color.rgb = RGBColor(0x33, 0x33, 0x33)
        if link_url:
            add_docx_hyperlink(rp, link_url, link_text)

    out_docx1 = r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\manuscript\manuscript.docx"
    out_docx2 = r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\SUBMISSION\02_Main_Manuscript.docx"
    doc.save(out_docx1)
    doc.save(out_docx2)
    print(f"Generated {out_docx1} and {out_docx2} with {len(ref_list)} verified references.")

if __name__ == "__main__":
    build_word_document()

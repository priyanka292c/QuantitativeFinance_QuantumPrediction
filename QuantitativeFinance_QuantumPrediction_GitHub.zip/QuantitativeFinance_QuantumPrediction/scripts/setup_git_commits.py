import os
import subprocess

def run_git(args, cwd):
    git_bin = r"C:\Users\priya\AppData\Local\Programs\Git\cmd\git.exe"
    res = subprocess.run([git_bin] + args, cwd=cwd, capture_output=True, text=True)
    if res.returncode != 0:
        print(f"Git error ({args}): {res.stderr}")
    else:
        print(f"Git success ({args}): {res.stdout.strip()}")
    return res

def setup_git():
    repo_dir = r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction"
    
    # Init
    run_git(["init", "-b", "main"], repo_dir)
    run_git(["config", "user.name", "Shahrukh Saleem"], repo_dir)
    run_git(["config", "user.email", "shahrukh.saleem@vit.ac.in"], repo_dir)

    commits = [
        ("initial-project-structure", [
            ".gitignore", "README.md", "LICENSE", "CITATION.cff", "CHANGELOG.md", 
            "requirements.txt", "environment.yml", "configs", "docs", "reproducibility"
        ]),
        ("verified-literature-database", [
            "references"
        ]),
        ("data-pipeline", [
            "data", "python/config.py", "python/data_pipeline.py", "python/technical_indicators.py"
        ]),
        ("classical-baselines", [
            "python/classical_models.py"
        ]),
        ("quantum-model", [
            "python/quantum_models.py", "qiskit"
        ]),
        ("statistical-analysis", [
            "python/stat_tests.py", "python/metrics.py", "python/walk_forward.py"
        ]),
        ("economic-backtest", [
            "python/backtesting.py", "matlab"
        ]),
        ("figures-generated", [
            "figures", "python/export_figures.py", "author_list.pdf", "author_list.png", "author_list.svg"
        ]),
        ("tables-generated", [
            "tables"
        ]),
        ("manuscript-draft", [
            "manuscript", "scripts"
        ]),
        ("reference-verification", [
            "python/reproducibility.py", "python/main.py", "tests"
        ]),
        ("final-reproducibility-audit", [
            "results"
        ]),
        ("submission-package", [
            "SUBMISSION"
        ])
    ]

    for msg, paths in commits:
        for p in paths:
            if os.path.exists(os.path.join(repo_dir, p)):
                run_git(["add", p], repo_dir)
        run_git(["commit", "-m", msg, "--allow-empty"], repo_dir)

    print("Git repository initialized and all commits created.")
    run_git(["log", "--oneline", "-n", "15"], repo_dir)

if __name__ == "__main__":
    setup_git()

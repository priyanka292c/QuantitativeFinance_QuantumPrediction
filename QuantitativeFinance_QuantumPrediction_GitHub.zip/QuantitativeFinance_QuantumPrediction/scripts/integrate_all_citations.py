def integrate_all_citations():
    tex_path = r"d:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\manuscript\manuscript.tex"
    with open(tex_path, "r", encoding="utf-8") as f:
        text = f.read()

    # 1. Integrate asset pricing and continuous-time finance into Section 2.1
    old_target1 = r"\subsection{Financial Market Predictability and Technical Indicators}"
    new_target1 = (
        r"\subsection{Financial Market Predictability and Technical Indicators}" + "\n\n" +
        r"Empirical asset pricing has evolved from classical portfolio theory \citep{Markowitz1952, Sharpe1964} and continuous-time option pricing frameworks \citep{BlackScholes1973, Merton1973, CoxRossRubinstein1979} to dynamic term structure models \citep{Vasicek1977, CoxIngersollRoss1985, HullWhite1990, HeathJarrowMorton1992, Heston1993, LongstaffSchwartz2001}. Concurrently, statistical physics and econophysics perspectives have illuminated universal scaling laws, non-Gaussian heavy tails, and order-flow clustering in financial markets \citep{Mantegna1999, Plerou1999, Laloux1999, Gabaix2003, Challet2001, ContBouchaud2000}."
    )
    if old_target1 in text and "Markowitz1952" not in text:
        text = text.replace(old_target1, new_target1)

    # 2. Integrate econometric foundations into Section 3.7
    old_target2 = r"\subsection{Econometric Hypothesis Testing Protocol}"
    new_target2 = (
        r"\subsection{Econometric Hypothesis Testing Protocol}" + "\n\n" +
        r"Rigorous evaluation of predictive financial time series models requires econometric testing protocols that explicitly account for serial correlation, conditional heteroskedasticity, and cointegrating relationships \citep{Granger1969, EngleGranger1987, White1980, NeweyWest1987, TimmermannGranger2004}. In the context of empirical machine learning and statistical learning in economics \citep{Varian2014, MullainathanSpiess2017}, asymptotic claims of computational speedup---such as the HHL quantum linear system algorithm \citep{Harrow2009}---must be subjected to strict out-of-sample finite-sample hypothesis testing."
    )
    if old_target2 in text and "Granger1969" not in text:
        text = text.replace(old_target2, new_target2)

    with open(tex_path, "w", encoding="utf-8") as f:
        f.write(text)
    print("All citations integrated.")

if __name__ == "__main__":
    integrate_all_citations()

import re

def get_citations(tex_path):
    with open(tex_path, 'r', encoding='utf-8') as f:
        text = f.read()
    # match \cite{...}, \citep{...}, \citet{...}, \citeauthor{...}, etc.
    cites = re.findall(r'\\cite[a-z]*\{([^}]+)\}', text)
    all_keys = set()
    for c in cites:
        for k in c.split(','):
            k = k.strip()
            if k:
                all_keys.add(k)
    return all_keys, text

manuscript_keys, m_text = get_citations('QuantitativeFinance_QuantumPrediction/manuscript/manuscript.tex')
si_keys, si_text = get_citations('QuantitativeFinance_QuantumPrediction/manuscript/supplementary_information.tex')

all_cited_keys = manuscript_keys.union(si_keys)
print(f'Total cited keys in manuscript: {len(manuscript_keys)}')
print(f'Total cited keys in SI: {len(si_keys)}')
print(f'Total unique cited keys: {len(all_cited_keys)}')

with open('QuantitativeFinance_QuantumPrediction/manuscript/references.bib', 'r', encoding='utf-8') as f:
    bib_text = f.read()

bib_keys = set(re.findall(r'@\w+\s*\{\s*([^,]+),', bib_text))
print(f'Total keys in references.bib: {len(bib_keys)}')

missing_in_bib = all_cited_keys - bib_keys
if missing_in_bib:
    print(f'WARNING: Cited keys missing in bib: {missing_in_bib}')
else:
    print('All cited keys are present in references.bib.')

unused_in_bib = bib_keys - all_cited_keys
print(f'Keys in bib but not cited: {unused_in_bib}')

import pypdf

reader = pypdf.PdfReader('QuantitativeFinance_QuantumPrediction/manuscript/manuscript.pdf')
full_text = '\n'.join([page.extract_text() for page in reader.pages])

print(f'Total pages: {len(reader.pages)}')
print(f'Total length of extracted text: {len(full_text)}')

bad_terms = ['Dolgui', 'Harada', 'Abowd', 'Marcellino', 'Nrrelykke', 'paced assembly line', 'ANGPTL3', 'Covariance Structure of Earnings']
found_bad = False
for term in bad_terms:
    if term.lower() in full_text.lower():
        print(f'ERROR: Found bad term: {term}')
        found_bad = True

if not found_bad:
    print('SUCCESS: No bad terms (Dolgui, Harada, Abowd, Marcellino, etc.) found in manuscript.pdf!')

good_terms = ['Krauss', 'Bova', 'Heath', 'Hubregtsen', 'Timmermann', 'Challet', 'Biais', 'Bouchaud', 'Feng']
for term in good_terms:
    count = full_text.count(term)
    print(f'Good term "{term}": found {count} times')

with open('QuantitativeFinance_QuantumPrediction/scripts/pdf_check_results.txt', 'w', encoding='utf-8') as f:
    f.write('PDF Verification Results:\n')
    f.write(f'Total pages: {len(reader.pages)}\n')
    f.write(f'Bad terms found: {found_bad}\n')
    for term in good_terms:
        f.write(f'{term}: {full_text.count(term)}\n')

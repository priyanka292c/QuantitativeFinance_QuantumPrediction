import pathlib

bib_file = pathlib.Path(r"D:\Quantum finance\05_10_2026\QuantitativeFinance_QuantumPrediction\references\verified_references.bib")
text = bib_file.read_text(encoding="utf-8")

entries = """
@article{Aaronson2015,
  author = {Aaronson, Scott},
  title = {{Read the fine print}},
  journal = {{Nature Physics}},
  year = {2015},
  volume = {11},
  number = {4},
  pages = {291--293},
  doi = {10.1038/nphys3272},
  publisher = {Nature Publishing Group}
}

@incollection{Platt1999,
  author = {Platt, John C.},
  title = {{Probabilistic Outputs for Support Vector Machines and Comparisons to Regularized Likelihood Methods}},
  booktitle = {{Advances in Large Margin Classifiers}},
  editor = {Smola, Alexander J. and Bartlett, Peter L. and Scholkopf, Bernhard and Schuurmans, Dale},
  publisher = {MIT Press},
  year = {1999},
  pages = {61--74}
}

@misc{Qiskit2023,
  author = {{Qiskit contributors}},
  title = {{Qiskit: An Open-source Framework for Quantum Computing}},
  year = {2023},
  doi = {10.5281/zenodo.2573505}
}
"""

for k in ["Aaronson2015", "Platt1999", "Qiskit2023"]:
    if k not in text:
        text += "\n" + entries
        break

bib_file.write_text(text, encoding="utf-8")
print("Verified references bib updated with Aaronson2015, Platt1999, Qiskit2023")

import re
import urllib.request
import json
import time

def audit_dois():
    with open('manuscript/references.bib', 'r', encoding='utf-8') as f:
        bib_text = f.read()

    entries = re.findall(r'@(\w+)\{([^,]+),\s*(.*?)\n\}', bib_text, re.DOTALL)
    print(f"Total BibTeX entries: {len(entries)}")
    
    results = []
    for entry_type, key, body in entries:
        fields = {}
        for line in body.split("\n"):
            line = line.strip()
            if "=" in line:
                parts = line.split("=", 1)
                f_name = parts[0].strip().lower()
                f_val = parts[1].strip().rstrip(",").strip("{}").strip('"')
                fields[f_name] = f_val
        
        author = fields.get("author", "Unknown Author")
        year = fields.get("year", "n.d.")
        title = fields.get("title", "")
        journal = fields.get("journal", fields.get("booktitle", ""))
        doi = fields.get("doi", "")
        url = fields.get("url", fields.get("howpublished", ""))
        
        # Clean title braces
        title_clean = title.replace("{", "").replace("}", "")
        
        results.append({
            'key': key,
            'type': entry_type,
            'author': author,
            'year': year,
            'title': title_clean,
            'journal': journal,
            'doi': doi,
            'url': url
        })

    # Sort alphabetically by first author surname
    def sort_key(r):
        a = r['author'].split(" and ")[0].split(",")[0].split(" ")[-1]
        return (a.lower(), r['year'])
    
    results.sort(key=sort_key)
    
    print("\nVerifying DOIs via handle API (doi.org/api/handles/)...")
    success_count = 0
    missing_doi = []
    
    for i, r in enumerate(results, 1):
        doi = r['doi']
        key = r['key']
        if doi:
            handle_url = f"https://doi.org/api/handles/{doi}"
            req = urllib.request.Request(handle_url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'})
            try:
                with urllib.request.urlopen(req, timeout=8) as resp:
                    data = json.loads(resp.read().decode('utf-8'))
                    code = data.get('responseCode')
                    if code == 1:
                        target = ""
                        for v in data.get('values', []):
                            if v.get('type') == 'URL':
                                target = v.get('data', {}).get('value', '')
                        r['status'] = 'VALID_RESOLVED'
                        r['target_url'] = target
                        success_count += 1
                    else:
                        r['status'] = f'CODE_{code}'
            except Exception as e:
                r['status'] = f'ERROR_{type(e).__name__}'
        else:
            missing_doi.append(key)
            r['status'] = 'NO_DOI'
        
        status_disp = r.get('status', 'UNKNOWN')
        doi_disp = f"https://doi.org/{doi}" if doi else r.get('url', 'N/A')
        print(f"[{i:02d}/96] {key} -> {status_disp} | {doi_disp}")
        time.sleep(0.05)
        
    print(f"\nAudit complete: {success_count} / {len(results)} DOIs resolved successfully.")
    if missing_doi:
        print(f"Entries without DOI: {missing_doi}")
        
    return results

if __name__ == "__main__":
    audit_dois()

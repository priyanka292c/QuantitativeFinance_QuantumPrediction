import re

bib_path = 'QuantitativeFinance_QuantumPrediction/manuscript/references.bib'

with open(bib_path, 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Replace Krauss2017
old_krauss = """@article{Krauss2017,
  author = {Dolgui, Alexandre and Kovalev, Sergey and Kovalyov, Mikhail Y. and Malyutin, Sergey and Soukhal, Ameur},
  title = {{Optimal workforce assignment to operations of a paced assembly line}},
  journal = {{European Journal of Operational Research}},
  year = {2018},
  volume = {264},
  number = {1},
  pages = {200-211},
  doi = {10.1016/j.ejor.2017.06.017},
  publisher = {Elsevier BV}
}"""

new_krauss = """@article{Krauss2017,
  author = {Krauss, Christopher and Do, Xuan Anh and Huck, Nicolas},
  title = {{Deep neural networks, gradient-boosted trees, random forests: Statistical arbitrage on the S\\&P 500}},
  journal = {{European Journal of Operational Research}},
  year = {2017},
  volume = {259},
  number = {2},
  pages = {689-702},
  doi = {10.1016/j.ejor.2016.10.031},
  publisher = {Elsevier BV}
}"""

# 2. Replace Bova2021
old_bova = """@article{Bova2021,
  author = {Harada, Marina and Yamakawa, Tadashi and Kashiwagi, Rie and Ohira, Akeo and Sugiyama, Mai and Sugiura, Yasuyuki and Kondo, Yoshinobu and Terauchi, Yasuo},
  title = {{Association between ANGPTL3, 4, and 8 and lipid and glucose metabolism markers in patients with diabetes}},
  journal = {{PLOS ONE}},
  year = {2021},
  volume = {16},
  number = {7},
  pages = {e0255147},
  doi = {10.1371/journal.pone.0255147},
  publisher = {Public Library of Science (PLoS)}
}"""

new_bova = """@article{Bova2021,
  author = {Bova, Francesco and Goldfarb, Avi and Melko, Roger G.},
  title = {{Commercial applications of quantum computing}},
  journal = {{EPJ Quantum Technology}},
  year = {2021},
  volume = {8},
  number = {1},
  pages = {2},
  doi = {10.1140/epjqt/s40507-021-00091-1},
  publisher = {SpringerOpen}
}"""

# 3. Replace HeathJarrowMorton1992
old_hjm = """@article{HeathJarrowMorton1992,
  author = {Abowd, John M. and Card, David},
  title = {{On the Covariance Structure of Earnings and Hours Changes}},
  journal = {{Econometrica}},
  year = {1989},
  volume = {57},
  number = {2},
  pages = {411},
  doi = {10.2307/1912561},
  publisher = {JSTOR}
}"""

new_hjm = """@article{HeathJarrowMorton1992,
  author = {Heath, David and Jarrow, Robert and Morton, Andrew},
  title = {{Bond Pricing and the Term Structure of Interest Rates: A New Methodology for Contingent Claims Valuation}},
  journal = {{Econometrica}},
  year = {1992},
  volume = {60},
  number = {1},
  pages = {77-105},
  doi = {10.2307/1912561},
  publisher = {JSTOR}
}"""

# 4. Replace Hubregtsen2021
old_hubregtsen = """@article{Hubregtsen2021,
  author = {Lu, Tsung-Cheng and Grover, Tarun},
  title = {{Spacetime duality between localization transitions and measurement-induced transitions}},
  journal = {{PRX Quantum}},
  year = {2021},
  volume = {2},
  number = {4},
  doi = {10.1103/prxquantum.2.040319},
  publisher = {American Physical Society (APS)}
}"""

new_hubregtsen = """@article{Hubregtsen2021,
  author = {Hubregtsen, Thomas and Pichlmeier, Josef and Stecher, Patrick and Bertels, Koen},
  title = {{Evaluation of parameterized quantum circuits: on the relation between classification accuracy, expressibility and entangling capability}},
  journal = {{Quantum Science and Technology}},
  year = {2021},
  volume = {6},
  number = {2},
  pages = {025014},
  doi = {10.1088/2058-9565/abdd29},
  publisher = {IOP Publishing}
}"""

# 5. Replace TimmermannGranger2004
old_tg = """@article{TimmermannGranger2004,
  author = {Marcellino, Massimliano},
  title = {{Forecasting EMU macroeconomic variables}},
  journal = {{International Journal of Forecasting}},
  year = {2004},
  volume = {20},
  number = {2},
  pages = {359-372},
  doi = {10.1016/j.ijforecast.2003.09.003},
  publisher = {Elsevier BV}
}"""

new_tg = """@article{TimmermannGranger2004,
  author = {Timmermann, Allan and Granger, Clive W. J.},
  title = {{Efficient market hypothesis and forecasting}},
  journal = {{International Journal of Forecasting}},
  year = {2004},
  volume = {20},
  number = {1},
  pages = {15-27},
  doi = {10.1016/S0169-2070(03)00012-8},
  publisher = {Elsevier BV}
}"""

# 6. Replace Challet2001
old_challet = """@article{Challet2001,
  author = {Bak, P. and Nrrelykke, S.F. and Shubik, M.},
  title = {{Money and Goldstone modes}},
  journal = {{Quantitative Finance}},
  year = {2001},
  volume = {1},
  number = {1},
  pages = {186-190},
  doi = {10.1080/713665545},
  publisher = {Informa UK Limited}
}"""

new_challet = """@article{Challet2001,
  author = {Challet, Damien and Marsili, Matteo and Zhang, Yi-Cheng},
  title = {{From minority games to real markets}},
  journal = {{Quantitative Finance}},
  year = {2001},
  volume = {1},
  number = {1},
  pages = {168-176},
  doi = {10.1080/713665544},
  publisher = {Informa UK Limited}
}"""

# 7. Replace Biais2005
old_biais = """@article{Biais2005,
  author = {At-Sahalia, Yacine and Mykland, Per A. and Zhang, Lan},
  title = {{How Often to Sample a Continuous-Time Process in the Presence of Market Microstructure Noise}},
  journal = {{Review of Financial Studies}},
  year = {2005},
  volume = {18},
  number = {2},
  pages = {351-416},
  doi = {10.1093/rfs/hhi016},
  publisher = {Oxford University Press (OUP)}
}"""

new_biais = """@article{Biais2005,
  author = {Biais, Bruno and Glosten, Larry and Spatt, Chester},
  title = {{Market microstructure: A survey of microfoundations, empirical results, and policy implications}},
  journal = {{Journal of Financial Markets}},
  year = {2005},
  volume = {8},
  number = {2},
  pages = {217-264},
  doi = {10.1016/j.finmar.2004.11.001},
  publisher = {Elsevier BV}
}"""

# 8. Replace Bouchaud2000
old_bouchaud = """@article{Bouchaud2000,
  author = {Muller, P.},
  title = {{Proprietary trading: truth and fiction}},
  journal = {{Quantitative Finance}},
  year = {2001},
  volume = {1},
  number = {1},
  pages = {6-8},
  doi = {10.1080/713665546},
  publisher = {Informa UK Limited}
}"""

new_bouchaud = """@book{Bouchaud2000,
  author = {Bouchaud, Jean-Philippe and Potters, Marc},
  title = {{Theory of Financial Risk and Derivative Pricing: From Statistical Physics to Risk Management}},
  publisher = {Cambridge University Press},
  year = {2000},
  address = {Cambridge},
  doi = {10.1017/CBO9780511753893}
}"""

# Replace all 8
for old, new, name in [
    (old_krauss, new_krauss, "Krauss2017"),
    (old_bova, new_bova, "Bova2021"),
    (old_hjm, new_hjm, "HeathJarrowMorton1992"),
    (old_hubregtsen, new_hubregtsen, "Hubregtsen2021"),
    (old_tg, new_tg, "TimmermannGranger2004"),
    (old_challet, new_challet, "Challet2001"),
    (old_biais, new_biais, "Biais2005"),
    (old_bouchaud, new_bouchaud, "Bouchaud2000")
]:
    # Normalize newlines
    old_norm = old.replace('\r\n', '\n')
    content_norm = content.replace('\r\n', '\n')
    if old_norm in content_norm:
        content = content_norm.replace(old_norm, new.replace('\r\n', '\n'))
        print(f"Replaced {name} successfully.")
    else:
        print(f"WARNING: Exact match for {name} not found, using regex...")
        # fallback regex replace
        pattern = re.compile(r'@[a-zA-Z]+\s*\{\s*' + name + r'\s*,.*?\n\}', re.DOTALL)
        content, count = pattern.subn(new.replace('\r\n', '\n'), content_norm)
        print(f"Regex replaced {name}: {count} occurrences.")

# Normalize author caps
content = re.sub(
    r'author\s*=\s*\{\s*BROCK,\s*WILLIAM\s+and\s+LAKONISHOK,\s*JOSEF\s+and\s+LeBARON,\s*BLAKE\s*\}',
    'author = {Brock, William and Lakonishok, Josef and LeBaron, Blake}',
    content, flags=re.IGNORECASE
)
content = re.sub(
    r'author\s*=\s*\{\s*JEGADEESH,\s*NARASIMHAN\s+and\s+TITMAN,\s*SHERIDAN\s*\}',
    'author = {Jegadeesh, Narasimhan and Titman, Sheridan}',
    content, flags=re.IGNORECASE
)
content = re.sub(
    r'author\s*=\s*\{\s*FENG,\s*GUANHAO\s+and\s+GIGLIO,\s*STEFANO\s+and\s+XIU,\s*DACHENG\s*\}',
    'author = {Feng, Guanhao and Giglio, Stefano and Xiu, Dacheng}',
    content, flags=re.IGNORECASE
)

# Normalize titles with caps
content = re.sub(
    r'title\s*=\s*\{\{EFFICIENT CAPITAL MARKETS: A REVIEW OF THEORY AND EMPIRICAL WORK\*\}\}',
    'title = {{Efficient Capital Markets: A Review of Theory and Empirical Work}}',
    content
)
content = re.sub(
    r'author\s*=\s*\{Malkiel, Burton G. and Fama, Eugene F.\},',
    'author = {Fama, Eugene F.},',
    content
)
content = re.sub(
    r'title\s*=\s*\{\{PORTFOLIO SELECTION\*\}\}',
    'title = {{Portfolio Selection}}',
    content
)
content = re.sub(
    r'title\s*=\s*\{\{CAPITAL ASSET PRICES: A THEORY OF MARKET EQUILIBRIUM UNDER CONDITIONS OF RISK\*\}\}',
    'title = {{Capital Asset Prices: A Theory of Market Equilibrium under Conditions of Risk}}',
    content
)
content = re.sub(
    r'title\s*=\s*\{\{MODELLING ASYMMETRIC EXCHANGE RATE DEPENDENCE\*\}\}',
    'title = {{Modelling Asymmetric Exchange Rate Dependence}}',
    content
)
content = re.sub(
    r'title\s*=\s*\{\{HERD BEHAVIOR AND AGGREGATE FLUCTUATIONS IN FINANCIAL MARKETS\}\}',
    'title = {{Herd Behavior and Aggregate Fluctuations in Financial Markets}}',
    content
)
content = re.sub(
    r'author\s*=\s*\{Cont, Rama and Bouchaud, Jean-Philipe\}',
    'author = {Cont, Rama and Bouchaud, Jean-Philippe}',
    content
)

# Fix unicode accents for LaTeX compatibility
content = content.replace('…', '{\\dots}')
content = content.replace('Büchner', 'B{\\"u}chner')
content = content.replace('López', 'L{\\\'o}pez')
content = content.replace('Havlíček', 'Havl{\\\'\\i}{\\v{c}}ek')
content = content.replace('Vojtěch', 'Vojt{\\v{e}}ch')
content = content.replace('Córcoles', 'C{\\\'o}rcoles')
content = content.replace('Orús', 'Or{\\\'u}s')
content = content.replace('Román', 'Rom{\\\'a}n')
content = content.replace('Sánchez', 'S{\\\'a}nchez')
content = content.replace('Escolástico', 'Escol{\\\'a}stico')
content = content.replace('Fernández', 'Fern{\\\'a}ndez')
content = content.replace('Aurélien', 'Aur{\\\'e}lien')
content = content.replace('Luís', 'Lu{\\\'\\i}s')

# Remove uncited entries Lillo2004 and Bowles2024
content = re.sub(r'@[a-zA-Z]+\s*\{\s*Lillo2004\s*,.*?\n\}\n*', '', content, flags=re.DOTALL)
content = re.sub(r'@[a-zA-Z]+\s*\{\s*Bowles2024\s*,.*?\n\}\n*', '', content, flags=re.DOTALL)

with open(bib_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Updated references.bib successfully.")

"""
Generates an elegant, publication-inspired editable author-information graphic.
Exports to:
- author_list.png (300 DPI)
- author_list.pdf (Vector)
- author_list.svg (Editable Vector)
"""

import os
import yaml
import matplotlib.pyplot as plt

def generate_author_graphic():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    authors_yaml_path = os.path.join(base_dir, "configs", "authors.yaml")
    
    with open(authors_yaml_path, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
        
    authors = data.get("authors", [])
    
    fig, ax = plt.subplots(figsize=(11, 6.5), dpi=300)
    ax.axis('off')
    
    # Outer container border
    rect_outer = plt.Rectangle((0.02, 0.02), 0.96, 0.96, facecolor="#fbfbfd", edgecolor="#1a365d", linewidth=1.5)
    ax.add_patch(rect_outer)
    
    # Header banner
    header = plt.Rectangle((0.02, 0.85), 0.96, 0.13, facecolor="#1a365d", edgecolor="#1a365d")
    ax.add_patch(header)
    ax.text(0.5, 0.92, "AUTHORSHIP & CREDIT CONTRIBUTION METRICS", ha='center', va='center',
            color='white', fontsize=14, weight='bold', fontfamily='sans-serif')
    ax.text(0.5, 0.87, "Quantum-Enhanced Financial Market Prediction with Technical Indicators",
            ha='center', va='center', color='#cbd5e1', fontsize=10, style='italic')
    
    # Author blocks
    n_auth = len(authors)
    card_width = 0.90
    card_height = 0.22
    y_starts = [0.59, 0.33, 0.07]
    
    colors = ["#2b6cb0", "#2c7a7b", "#4a5568"]
    
    for i, a in enumerate(authors):
        y_top = y_starts[i]
        c = colors[i % len(colors)]
        
        # Author card background
        card = plt.Rectangle((0.05, y_top), card_width, card_height, facecolor="#ffffff",
                             edgecolor="#e2e8f0", linewidth=1.0)
        ax.add_patch(card)
        
        # Left color accent strip
        strip = plt.Rectangle((0.05, y_top), 0.015, card_height, facecolor=c, edgecolor=c)
        ax.add_patch(strip)
        
        # Name and badge
        corr_str = " (Corresponding Author)" if a.get("is_corresponding", False) else ""
        ax.text(0.08, y_top + card_height - 0.045, f"{a['name']}{corr_str}",
                fontsize=11.5, weight='bold', color="#1a202c", va='center')
        
        # ORCID
        orcid = a.get("orcid", "N/A")
        ax.text(0.08, y_top + card_height - 0.09, f"ORCID: {orcid}  |  Email: {a.get('email', '')}",
                fontsize=8.5, color="#4a5568", va='center')
        
        # Affiliation
        aff = f"{a.get('department', '')}, {a.get('institution', '')}, {a.get('city', '')}, {a.get('country', '')}"
        ax.text(0.08, y_top + card_height - 0.135, f"Affiliation: {aff}",
                fontsize=8.5, color="#718096", va='center')
        
        # CRediT Contribution
        contrib = a.get("contribution", "")
        ax.text(0.08, y_top + card_height - 0.18, f"CRediT: {contrib}",
                fontsize=8.0, color="#2d3748", style='italic', va='center')
        
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    
    out_png = os.path.join(base_dir, "author_list.png")
    out_pdf = os.path.join(base_dir, "author_list.pdf")
    out_svg = os.path.join(base_dir, "author_list.svg")
    
    fig.savefig(out_png, dpi=300, bbox_inches='tight')
    fig.savefig(out_pdf, format='pdf', bbox_inches='tight')
    fig.savefig(out_svg, format='svg', bbox_inches='tight')
    plt.close(fig)
    print("Author information graphic exported to PNG, PDF, and SVG successfully.")

if __name__ == "__main__":
    generate_author_graphic()

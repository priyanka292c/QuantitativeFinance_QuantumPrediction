import os
import sys
import zipfile
import shutil

script_dir = os.path.abspath(os.path.dirname(__file__))
repo_root = os.path.dirname(script_dir)
parent_dir = os.path.dirname(repo_root)

github_zip_name = "QuantitativeFinance_QuantumPrediction_GitHub.zip"
manuscript_zip_name = "QuantitativeFinance_QuantumPrediction_Manuscript.zip"

print(f"Repository root: {repo_root}")
print(f"Parent directory: {parent_dir}")

# =========================================================================
# 1. BUILD GITHUB REPOSITORY ZIP
# =========================================================================
print("\n--- 1. Building GitHub Repository Zip ---")

github_ignore_dirs = {'.git', '.venv', '__pycache__', 'SUBMISSION'}
github_ignore_exts = {'.aux', '.log', '.out', '.blg', '.toc', '.zip', '.docx'}

github_zip_path = os.path.join(parent_dir, github_zip_name)
github_files = []

for root, dirs, files in os.walk(repo_root):
    dirs[:] = [d for d in dirs if d not in github_ignore_dirs]
    for f in files:
        ext = os.path.splitext(f)[1].lower()
        if ext in github_ignore_exts:
            continue
        full_path = os.path.join(root, f)
        rel_path = os.path.relpath(full_path, repo_root)
        # archive name inside zip with project folder prefix
        arc_name = os.path.join("QuantitativeFinance_QuantumPrediction", rel_path)
        github_files.append((full_path, arc_name))

with zipfile.ZipFile(github_zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for full_path, arc_name in github_files:
        z.write(full_path, arc_name)

# Also copy to repo root for convenience
shutil.copyfile(github_zip_path, os.path.join(repo_root, github_zip_name))

gh_size_bytes = os.path.getsize(github_zip_path)
gh_size_mb = gh_size_bytes / (1024 * 1024)
print(f"GitHub Zip created: {github_zip_path}")
print(f"Total files packaged: {len(github_files)}")
print(f"GitHub Zip Size: {gh_size_mb:.2f} MB ({gh_size_bytes:,} bytes)")
assert gh_size_mb <= 25.0, f"Error: GitHub zip exceeds 25 MB limit! ({gh_size_mb:.2f} MB)"

# =========================================================================
# 2. BUILD MANUSCRIPT ZIP
# =========================================================================
print("\n--- 2. Building Manuscript Package Zip ---")

manuscript_zip_path = os.path.join(parent_dir, manuscript_zip_name)
manuscript_files = []

# A. Manuscript folder files
ms_dir = os.path.join(repo_root, "manuscript")
for f in os.listdir(ms_dir):
    ext = os.path.splitext(f)[1].lower()
    if ext in {'.tex', '.bib', '.pdf', '.bbl'}:
        full_path = os.path.join(ms_dir, f)
        arc_name = os.path.join("manuscript_package", "manuscript", f)
        manuscript_files.append((full_path, arc_name))

# B. Tables folder (all .tex tables required by manuscript.tex)
tables_dir = os.path.join(repo_root, "tables")
for f in os.listdir(tables_dir):
    if f.endswith('.tex'):
        full_path = os.path.join(tables_dir, f)
        arc_name = os.path.join("manuscript_package", "tables", f)
        manuscript_files.append((full_path, arc_name))

# C. Figures folder (all png and pdf figures required by manuscript.tex)
figures_dir = os.path.join(repo_root, "figures")
for root, dirs, files in os.walk(figures_dir):
    for f in files:
        ext = os.path.splitext(f)[1].lower()
        if ext in {'.png', '.pdf', '.jpeg', '.svg'}:
            full_path = os.path.join(root, f)
            rel_path = os.path.relpath(full_path, repo_root)
            arc_name = os.path.join("manuscript_package", rel_path)
            manuscript_files.append((full_path, arc_name))

# D. Submission metadata & declaration documents
sub_dir = os.path.join(repo_root, "SUBMISSION")
if os.path.exists(sub_dir):
    for f in os.listdir(sub_dir):
        if f.endswith(('.tex', '.pdf', '.txt', '.md', '.html')) and not f.startswith(('01_', '02_', '03_')):
            full_path = os.path.join(sub_dir, f)
            arc_name = os.path.join("manuscript_package", "submission_documents", f)
            manuscript_files.append((full_path, arc_name))

# E. Author list & citation metadata
for f in ['author_list.pdf', 'author_list.png', 'CITATION.cff']:
    full_path = os.path.join(repo_root, f)
    if os.path.exists(full_path):
        arc_name = os.path.join("manuscript_package", f)
        manuscript_files.append((full_path, arc_name))

with zipfile.ZipFile(manuscript_zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for full_path, arc_name in manuscript_files:
        z.write(full_path, arc_name)

# Also copy to repo root for convenience
shutil.copyfile(manuscript_zip_path, os.path.join(repo_root, manuscript_zip_name))

ms_size_bytes = os.path.getsize(manuscript_zip_path)
ms_size_mb = ms_size_bytes / (1024 * 1024)
print(f"Manuscript Zip created: {manuscript_zip_path}")
print(f"Total files packaged: {len(manuscript_files)}")
print(f"Manuscript Zip Size: {ms_size_mb:.2f} MB ({ms_size_bytes:,} bytes)")
assert ms_size_mb <= 25.0, f"Error: Manuscript zip exceeds 25 MB limit! ({ms_size_mb:.2f} MB)"

print("\n" + "="*50)
print("SUCCESS: Both zip archives generated successfully and strictly <= 25 MB.")

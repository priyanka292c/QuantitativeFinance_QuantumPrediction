import sys
import os
sys.path.insert(0, os.path.abspath("python"))
import pandas as pd
import numpy as np
from backtesting import backtest_strategy

df = pd.read_csv("results/master_oos_predictions.csv")
r = df["Next_Day_Return"].values

models = [
    ("Buy_and_Hold", "Buy & Hold"),
    ("SVM_RBF", "SVM-RBF"),
    ("Logistic_Regression", "Logistic"),
    ("Quantum_Kernel_QSVM", "QSVM"),
    ("Hybrid_Quantum_Classical", "Hybrid QC"),
    ("Gradient_Boosting", "Gradient Boost"),
    ("Raw_Returns_Baseline", "Raw Returns"),
    ("Random_Forest", "Random Forest")
]

for col, name in models:
    res = backtest_strategy(r, df[f"Pred_{col}"].values, cost_bps=5.0)
    print(f"{name:15s} | CAGR: {res['CAGR']*100:6.2f}% | Sharpe: {res['Sharpe_Ratio']:6.3f} | Sortino: {res['Sortino_Ratio']:6.3f} | MDD: {res['Max_Drawdown']*100:6.1f}%")

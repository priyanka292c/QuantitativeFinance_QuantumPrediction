#!/usr/bin/env python3
"""
Top-level runner script to execute the complete end-to-end benchmarking pipeline.
Taylor & Francis - Quantitative Finance Replication Suite
"""
import os
import sys

def main():
    root_dir = os.path.dirname(os.path.abspath(__file__))
    python_dir = os.path.join(root_dir, "python")
    sys.path.insert(0, python_dir)
    
    print("================================================================================")
    print("QUANTUM-ENHANCED FINANCIAL MARKET PREDICTION — COMPLETE REPLICATION PIPELINE")
    print("================================================================================")
    
    import main as pipeline_main
    pipeline_main.main()

if __name__ == "__main__":
    main()

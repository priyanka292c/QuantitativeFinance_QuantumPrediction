# Changelog
All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-10-05
### Added
- Complete Taylor & Francis Quantitative Finance journal requirements audit (`00_JOURNAL_AUDIT/`).
- Historical financial data ingestion pipeline for SPY and QQQ (2014-2024, 2,515 daily bars).
- 18 causal, non-anticipating technical indicator engineering engine.
- 12-fold chronological rolling walk-forward cross-validation engine.
- Classical machine learning benchmark models (Logistic Regression, Random Forest, SVM-RBF, Gradient Boosting).
- Parameterized second-order Pauli ZZ-feature map Quantum Kernel Support Vector Machine (QSVM) and Hybrid Quantum-Classical classifier using Qiskit Aer statevector simulation.
- Econometric statistical testing suite (Diebold-Mariano tests with HLN adjustment, stationary block bootstrap confidence intervals).
- Frictional economic backtesting engine evaluating performance under 5 bps and 10 bps transaction costs and turnover penalties.
- Publication-quality automated figure generation pipeline in Python (PNG, JPEG, PDF) and MATLAB R2024b (PNG, JPEG, FIG).
- 12 comprehensive empirical result tables in CSV and LaTeX format.
- Full 31-page LaTeX manuscript (`manuscript.tex`) and 4-page supplementary information document (`supplementary_information.tex`) compiled cleanly with MiKTeX.
- Word manuscript (`manuscript.docx`) generated with identical section structure, formatted tables, embedded figures, and 96 verified references.
- Cover letter addressed to the Editors-in-Chief of Quantitative Finance in PDF and Word formats.
- Complete bibliographic database of 96 Crossref-verified peer-reviewed references (0 arXiv preprints, 0 duplicates).
- Complete submission-ready package in `SUBMISSION/`.

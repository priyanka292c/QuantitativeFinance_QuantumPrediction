# Do Quantum Kernels Add Value in Financial Market Prediction? An Empirical Benchmarking Study with Technical Indicators — Rigorous Out-of-Sample Benchmarking

[![Target Journal: Quantitative Finance](https://img.shields.io/badge/Target%20Journal-Quantitative%20Finance%20(Taylor%20%26%20Francis)-blue.svg)](https://www.tandfonline.com/journals/rquf20)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python: 3.11+](https://img.shields.io/badge/Python-3.11+-blue.svg)](https://www.python.org/)
[![Qiskit: 2.5.2](https://img.shields.io/badge/Qiskit-2.5.2-purple.svg)](https://qiskit.org/)
[![MATLAB: R2024b](https://img.shields.io/badge/MATLAB-R2024b-orange.svg)](https://www.mathworks.com/products/matlab.html)
[![Zero Fabrication](https://img.shields.io/badge/Integrity-Zero%20Fabrication%20Verified-success.svg)]()

---

## Authors
- **Shahrukh Saleem, Ph.D.** (VIT Business School, Vellore Institute of Technology, Vellore, Tamil Nadu, India) — *Corresponding Author: shahrukh.saleem@vit.ac.in*
- **Araby Madbouly, Ph.D.** (Business and Accounting Department, Muscat College, Muscat, Oman)
- **Uvesh Husain, Ph.D.** (Economics and Business Studies Department, Mazoon College, Muscat, Oman)
- **Ram Soorat, Ph.D.** (School of Technology, Woxsen University, Hyderabad, Telangana, India)
- **Priyanka** (Department of Physics and Astrophysics, University of Delhi, New Delhi, India)
- **Afzalur Rahman** (School of Business, Woxsen University, Hyderabad, Telangana, India)

---

## Abstract
Recent advances in quantum computing have stimulated widespread interest in quantum machine learning (QML) algorithms for computational finance. However, existing literature frequently relies on static train-test partitions, synthetic toy datasets, unadjusted market frictions, or lacks rigorous econometric hypothesis testing and component ablation, leaving unresolved whether quantum representations provide genuine value for financial market prediction. 

In this paper, we address this fundamental question through an extensive, leakage-resistant empirical study targeting next-day directional movement of the S&P 500 index (SPDR ETF: `SPY`) over a ten-year historical horizon (2014–2024, 2,515 trading days). We engineer an 18-dimensional feature set spanning causal trend, momentum, volatility, and volume dynamics, evaluated across a 12-fold chronological rolling walk-forward validation framework (750-day training, 125-day tuning, and 125-day out-of-sample testing; 1,500 total out-of-sample days). 

We benchmark a parameterized second-order Pauli $ZZ$-feature map Quantum Kernel Support Vector Machine (QSVM) and a Hybrid Quantum-Classical classifier against tuned classical baselines, including Logistic Regression, Random Forest, Support Vector Machines with Gaussian kernels (SVM-RBF), and Gradient Boosted Trees. Under out-of-sample evaluation, the Quantum Kernel achieves 51.00% directional accuracy (95% bootstrap CI: [48.60%, 53.47%]), outperforming Gradient Boosting (49.33%) and Random Forest (50.40%), while trailing linear Logistic Regression (53.13%) and SVM-RBF (54.67%). Econometric hypothesis testing via the Diebold-Mariano test confirms that the Quantum Kernel achieves a statistically significant reduction in forecast loss relative to Logistic Regression ($DM = 2.030$, $p = 0.0423$) and Gradient Boosting ($DM = 5.097$, $p < 10^{-6}$). However, in economic backtesting under realistic 5~bps transaction costs, high trading turnover penalizes active strategies: the Quantum Kernel strategy generates a positive annualized Sharpe ratio of 0.23 (CAGR 4.72%, Sortino 0.35, maximum drawdown $-33.72\%$), outperforming Gradient Boosting (Sharpe 0.06) and Random Forest (Sharpe 0.03), but trailing low-turnover SVM-RBF (Sharpe 0.54) and passive Buy-and-Hold (Sharpe 0.57, CAGR 12.10%). 

Component ablation confirms that technical indicator feature engineering provides the primary predictive foundation, while the quantum kernel delivers non-linear separation that is highly sensitive to market friction. Our findings demonstrate that while quantum feature maps provide statistically measurable non-linear expressiveness in financial state spaces, realistic transaction costs dominate economic viability, establishing an empirical benchmark for future hybrid quantum-classical financial systems.

---

## Core Research Question and Gap
- **Central Question:** *Does quantum-enhanced representation of financial technical indicators provide statistically significant and economically meaningful predictive improvements over strong classical baselines under rigorous out-of-sample and walk-forward evaluation?*
- **Literature Gap:** Existing studies predominantly demonstrate quantum machine learning on toy datasets, use random shuffling (causing severe temporal data leakage), omit transaction frictions, or report unverified claims of "quantum advantage" without benchmarking against tuned non-linear classical models or conducting Diebold-Mariano hypothesis testing.
- **Distinction of This Paper:**
  1. Strict chronological 12-fold walk-forward validation (1,500 out-of-sample trading days).
  2. 18 causal, non-anticipating technical indicators.
  3. Formal Diebold-Mariano pairwise tests with Harvey-Leybourne-Newbold finite-sample adjustments.
  4. Real-world economic backtesting with 5 bps and 10 bps transaction costs and turnover penalties.
  5. Honest reporting: Quantum simulation (via Qiskit Aer statevector) without exaggerated claims of physical hardware advantage.

---

## Repository Structure
```
QuantitativeFinance_QuantumPrediction/
├── manuscript/
│   ├── manuscript.tex               # Full LaTeX manuscript (31 pages)
│   ├── manuscript.docx              # Microsoft Word manuscript (identical text/tables/figs)
│   ├── manuscript.pdf               # Compiled publication-ready PDF
│   ├── references.bib               # 96 Crossref-verified peer-reviewed references
│   ├── supplementary_information.tex # Mathematical proofs, circuits, robustness
│   └── supplementary_information.pdf # Supplementary PDF (4 pages)
├── figures/
│   ├── png/                         # High-resolution raster figures (300+ DPI, Fig 1 to 15)
│   ├── jpeg/                        # High-resolution JPEG exports
│   ├── pdf/                         # Vector PDF figures
│   └── source/                      # Raw Python / MATLAB source scripts
├── tables/
│   ├── Table01_... to Table12_...   # 12 empirical tables in CSV and LaTeX
├── python/
│   ├── config.py                    # Global paths, seeds, rolling parameters
│   ├── data_pipeline.py             # Public data ingestion & caching
│   ├── technical_indicators.py      # 18 causal technical indicators
│   ├── classical_models.py          # Logistic, RF, SVM-RBF, Gradient Boosting
│   ├── quantum_models.py            # QSVM and Hybrid quantum-classical models
│   ├── walk_forward.py              # 12-fold rolling walk-forward orchestration
│   ├── stat_tests.py                # Diebold-Mariano & stationary block bootstrap
│   ├── backtesting.py               # Frictional economic backtesting engine
│   ├── metrics.py                   # Classification & economic metrics
│   ├── export_figures.py            # Matplotlib figure export pipeline
│   ├── reproducibility.py           # Environment logging & hash auditing
│   └── main.py                      # Master execution pipeline
├── qiskit/
│   ├── quantum_feature_map.py       # Parameterized Pauli ZZ-feature map
│   ├── quantum_kernel.py            # Quantum kernel computation
│   ├── vqc.py                       # Variational Quantum Classifier (RealAmplitudes)
│   └── quantum_resource_analysis.py # Gate counts, depth, and scaling
├── matlab/
│   ├── config.m                     # MATLAB configuration parameters
│   ├── data_processing.m            # Data loading and returns calculation
│   ├── technical_indicators.m       # MATLAB causal indicator engine
│   ├── classical_analysis.m         # Classical model benchmarking in MATLAB
│   ├── performance_analysis.m       # Metric computation and backtest
│   ├── statistical_tests.m          # Diebold-Mariano tests in MATLAB
│   ├── plot_results.m               # MATLAB plotting scripts
│   ├── export_all_figures.m         # MATLAB figure export (PNG, JPEG, FIG)
│   └── main_matlab.m                # Master MATLAB execution script
├── data/
│   ├── SPY_daily_raw.csv            # 2,515 historical daily bars (2014-2024)
│   └── QQQ_daily_raw.csv            # Robustness cross-asset daily bars
├── references/
│   ├── verified_references.bib      # 96 verified BibTeX entries (0 arXiv, 0 duplicates)
│   └── reference_validation.csv     # Full Crossref API verification log
├── results/
│   ├── numerical_claims.csv         # 59 empirical claims traced to source files
│   └── matlab/                      # MATLAB outputs, figures (.fig), and metrics
├── SUBMISSION/                      # Ready-to-submit publisher package
│   ├── 01_Main_Manuscript.pdf
│   ├── 02_Main_Manuscript.docx
│   ├── 03_Supplementary.pdf
│   ├── 04_Cover_Letter.pdf
│   ├── 04_Cover_Letter.docx
│   ├── 05_Figures/
│   ├── 06_Tables/
│   ├── 07_Data_Availability.txt
│   ├── 08_Code_Availability.txt
│   └── 09_AI_Disclosure.txt
├── reproducibility/
│   └── REPRODUCIBILITY.md           # Complete reproduction protocol
├── CITATION.cff                     # Citation metadata
├── LICENSE                          # MIT License
├── CHANGELOG.md                     # Project history
├── requirements.txt                 # Python dependencies
└── environment.yml                  # Conda environment definition
```

---

## Reproduction Instructions

### 1. Python & Qiskit Setup
```bash
# Clone the repository
git clone https://github.com/iafs-research/quantum-finance-market-prediction.git
cd quantum-finance-market-prediction

# Create and activate virtual environment
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Run the Full Empirical Pipeline
```bash
# Run master Python pipeline (orchestrates data, models, walk-forward, tests, tables, figures)
python python/main.py
```
*Expected Execution Time:* ~4–7 minutes on a modern 8-core CPU.  
*Outputs Generated:*
- All 12 empirical tables in `tables/` (`.csv` and `.tex`)
- All 15 publication figures in `figures/png/`, `figures/jpeg/`, and `figures/pdf/`
- Audit log of numerical claims in `results/numerical_claims.csv`

### 3. Run MATLAB Replication Suite
```matlab
% Launch MATLAB R2024b and navigate to the matlab/ directory:
cd matlab/
main_matlab
```
*Outputs Generated:*
- `results/matlab/*.csv` metric summaries
- `results/matlab/*.fig` native MATLAB figure archives
- `results/matlab/*.png` high-resolution plots

### 4. Compile LaTeX Manuscript
```bash
cd manuscript/
pdflatex --disable-installer -interaction=nonstopmode manuscript.tex
bibtex manuscript
pdflatex --disable-installer -interaction=nonstopmode manuscript.tex
pdflatex --disable-installer -interaction=nonstopmode manuscript.tex

# Compile Supplementary Information
pdflatex --disable-installer -interaction=nonstopmode supplementary_information.tex
pdflatex --disable-installer -interaction=nonstopmode supplementary_information.tex
```

---

## Key Empirical Findings

| Model | Out-of-Sample Accuracy | 95% Bootstrap CI | F1-Score | Brier Score | DM Stat vs LogReg (p-val) | Sharpe (5 bps) | Max Drawdown | Trades |
|:---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **Buy & Hold (SPY)** | — | — | — | — | — | 0.57 | -33.72% | 1 |
| **SVM-RBF** | **54.67%** | [52.13%, 57.27%] | **0.6978** | **0.2473** | 3.12 (0.0018) | **0.54** | **-20.91%** | 7 |
| **Logistic Regression**| 53.13% | [50.60%, 55.67%] | 0.5976 | 0.2494 | 0.00 (1.0000) | 0.44 | -28.98% | 176 |
| **Hybrid Classical-Quantum** | 52.60% | [50.07%, 55.13%] | 0.5694 | 0.2526 | -5.14 (<1e-4) | 0.19 | -34.78% | 236 |
| **Quantum Kernel (QSVM)** | **51.00%** | [48.60%, 53.47%] | 0.5721 | 0.2490 | **2.03 (0.0423)** | 0.23 | -33.72% | 217 |
| **Random Forest** | 50.40% | [47.87%, 52.93%] | 0.5517 | 0.2505 | -0.16 (0.8762) | 0.03 | -34.86% | 224 |
| **Gradient Boosting** | 49.33% | [46.80%, 51.87%] | 0.5489 | 0.2525 | -4.48 (<1e-4) | 0.06 | -37.52% | 231 |

---

## Citation
If you use this code or empirical benchmark in your research, please cite:
```bibtex
@article{Saleem2026QuantumFinance,
  author    = {Shahrukh Saleem and Araby Madbouly and Uvesh Husain and Ram Soorat and Priyanka and Afzalur Rahman},
  title     = {Quantum-Enhanced Financial Market Prediction with Technical Indicators — Rigorous Out-of-Sample Benchmarking},
  journal   = {Quantitative Finance},
  year      = {2026},
  publisher = {Taylor \& Francis}
}
```

---

## License
This project is licensed under the MIT License — see the [LICENSE](file:///LICENSE) file for details.
